package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.cw.balukibazaar.Adapter.ViewAddToCardAdapter;
import com.cw.balukibazaar.Adapter.ViewShopBundleOrderAdapter;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;

public class YourOrderActivity extends AppCompatActivity {

    ImageView iv_back;
    Button btn_confirm;
    Context context;
    SessionManager sessionManager;
    TextView txt_itemcount,txt_price,txt_disprice,txt_totalprice;
    RecyclerView recycleritem;
    LinearLayoutManager HorizontalLayout;
    private ViewAddToCardAdapter thingAdapter;
    String discount_id,seller_id;
    Double totaldiscountprice;
    Double totalprice=0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_order);
        InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                seller_id = intent.getStringExtra("seller_id");
                discount_id = intent.getStringExtra("discount_id");
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        dataset();
        Click();
    }

    private void dataset() {
        txt_itemcount.setText(sessionManager.getProductList().size()+" Items");


        for (int i=0;i<sessionManager.getProductList().size();i++)
        {
            totalprice = totalprice+Double.parseDouble(sessionManager.getProductList().get(i).getPrice());
        }
        txt_price.setText("€ "+totalprice);
        txt_disprice.setText(sessionManager.getProductList().get(0).getDisPercent()+"%");
         totaldiscountprice = totalprice-(totalprice / 100) * Double.parseDouble(sessionManager.getProductList().get(0).getDisPercent());
        txt_totalprice.setText("€ "+totaldiscountprice);

        HorizontalLayout = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        recycleritem.setLayoutManager(HorizontalLayout);
        recycleritem.setHasFixedSize(true);
        thingAdapter = new ViewAddToCardAdapter(context,sessionManager.getProductList());
        recycleritem.setAdapter(thingAdapter);

    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("add order data >>>>>>>>>"+totalprice+totaldiscountprice+seller_id+discount_id);
                Intent intent = new Intent(context,CheckOutActivity.class);
                intent.putExtra("seller_id",seller_id);
                intent.putExtra("discount_id",discount_id);
                intent.putExtra("totaldiscountamt",totaldiscountprice+"");
                intent.putExtra("totalamt",totalprice+"");
                startActivity(intent);
            }
        });
    }

    private void InitView() {
        context = YourOrderActivity.this;
        sessionManager = new SessionManager(context);
        iv_back = findViewById(R.id.iv_back);
        btn_confirm = findViewById(R.id.btn_confirm);
        txt_itemcount = findViewById(R.id.txt_itemcount);
        recycleritem = findViewById(R.id.recycleritem);
        txt_price = findViewById(R.id.txt_price);
        txt_disprice = findViewById(R.id.txt_disprice);
        txt_totalprice = findViewById(R.id.txt_totalprice);
    }
}