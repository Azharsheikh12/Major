package com.cw.balukibazaar.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.InboxAdapter;
import com.cw.balukibazaar.Adapter.MySliderAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.ProductDetailData;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.ModelClass.ViewChatDetailData;
import com.cw.balukibazaar.ModelClass.ViewChatDetailResponse;
import com.cw.balukibazaar.ModelClass.ViewChatListResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessageActivity extends AppCompatActivity {

    ImageView iv_back,img_chat_send;
    ProductDetailData productDetailData;
    RoundRectCornerImageView img_product;
    TextView txt_itemname,txt_itemprice;
    Context context;
    RecyclerView rec_messages_list;
    MyChatAdapter MyListAdapter;
   public SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    EditText edt_chat;
    String s_chatmsg,chat_id;
    LinearLayout layout_chat;
    Button btn_makeoffer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        InitView();
        Click();
        try {
            Intent intent = getIntent();
            if (intent!=null){
                productDetailData = (ProductDetailData) intent.getSerializableExtra("productdata");
                chat_id = intent.getStringExtra("chat_id");


                Picasso.get().load(Allurls.ImageURL+productDetailData.getImages().get(0).getPath()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(img_product);
                txt_itemname.setText(productDetailData.getName());
                txt_itemprice.setText("€ "+productDetailData.getPrice());
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        if(Utils.isInternetConnected(context)) {

            try {
                sendPostViewChatList();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        img_chat_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               s_chatmsg = edt_chat.getText().toString().trim();
               if (s_chatmsg.equals("")){
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_enter_message));
               }
               else {
                   if(Utils.isInternetConnected(context)) {

                       try {
                           sendPostSendMessage(sessionManager.getSavedUserid(),productDetailData.getSellerdata().getId(),s_chatmsg,"0");
                       } catch (JSONException e) {
                           e.printStackTrace();
                       }
                   }
                   else {
                       CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                   }
               }
            }
        });

        btn_makeoffer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MakeOfferDialog(context);
            }
        });
    }

    private void InitView() {
        context = MessageActivity.this;
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        iv_back = findViewById(R.id.iv_back);
        img_product = findViewById(R.id.img_product);
        txt_itemname = findViewById(R.id.txt_itemname);
        txt_itemprice = findViewById(R.id.txt_itemprice);
        rec_messages_list = findViewById(R.id.rec_messages_list);
        edt_chat = findViewById(R.id.edt_chat);
        img_chat_send = findViewById(R.id.img_chat_send);
        layout_chat = findViewById(R.id.layout_chat);
        btn_makeoffer = findViewById(R.id.btn_makeoffer);
    }

    public void sendPostSendMessage(String senderid,String recieverid,String msg,String productid) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.sendchatmessage(senderid,recieverid,msg,productid).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        edt_chat.setText("");
                        if(Utils.isInternetConnected(context)) {

                            try {
                                sendPostViewChatList();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                        }
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostViewChatList() throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.viewchatdetail(chat_id,sessionManager.getSavedUserid(),productDetailData.getSellerdata().getId()).enqueue(new Callback<ViewChatDetailResponse>() {
            @Override
            public void onResponse(Call<ViewChatDetailResponse> call, Response<ViewChatDetailResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        if (response.body().getData().size()==0){
                            layout_chat.setVisibility(View.GONE);
                        }
                        else {
                            layout_chat.setVisibility(View.VISIBLE);
                        }

                        MyListAdapter = new MyChatAdapter(context,response.body().getData());
                        rec_messages_list.setHasFixedSize(true);
                        rec_messages_list.setLayoutManager(new LinearLayoutManager(context));
                        rec_messages_list.setAdapter(MyListAdapter);
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewChatDetailResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public class MyChatAdapter extends RecyclerView.Adapter<MyChatAdapter.ViewHolder> {
        private List<ViewChatDetailData> mySliderLists;
        private LayoutInflater mInflater;
        Context context;

        public MyChatAdapter(Context context, List<ViewChatDetailData> mySliderLists) {
            this.mInflater = LayoutInflater.from(context);
            this.mySliderLists = mySliderLists;
            this.context=context;
        }

        @NonNull
        @Override
        public MyChatAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = mInflater.inflate(R.layout.row_chat_single, parent, false);

//        ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(context));

            return new MyChatAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyChatAdapter.ViewHolder holder, final int position) {
            final ViewChatDetailData ob= mySliderLists.get(position);

            if (ob.getType().equals("chat"))
            {
                holder.message_text_layoutr.setText(ob.getMsg());
                holder.message_text_layouts.setText(ob.getMsg());
                holder.offermessage_text_layoutr.setVisibility(View.GONE);
                holder.offermessage_text_layouts.setVisibility(View.GONE);
            }
            else if (ob.getType().equals("offer")){
                holder.offermessage_text_layoutr.setVisibility(View.VISIBLE);
                holder.offermessage_text_layouts.setVisibility(View.VISIBLE);
                holder.message_text_layoutr.setText("€ "+ob.getMsg());
                holder.message_text_layouts.setText("€ "+ob.getMsg());
            }


            if (ob.getSenderId().equals(sessionManager.getSavedUserid())){
                holder.layout_sender.setVisibility(View.VISIBLE);
                holder.layout_reciver.setVisibility(View.GONE);
            }
            else {
                holder.layout_sender.setVisibility(View.GONE);
                holder.layout_reciver.setVisibility(View.VISIBLE);
            }

        }

        @Override
        public int getItemCount() {
            return mySliderLists.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{
            LinearLayout layout_reciver,layout_sender;
            TextView message_text_layoutr,message_text_layouts,offermessage_text_layouts,offermessage_text_layoutr;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                layout_reciver = itemView.findViewById(R.id.layout_reciver);
                layout_sender = itemView.findViewById(R.id.layout_sender);
                offermessage_text_layouts = itemView.findViewById(R.id.offermessage_text_layouts);
                offermessage_text_layoutr = itemView.findViewById(R.id.offermessage_text_layoutr);
                message_text_layoutr = itemView.findViewById(R.id.message_text_layoutr);
                message_text_layouts = itemView.findViewById(R.id.message_text_layouts);
            }
        }
    }

    public void MakeOfferDialog(final Context context)
    {
        final Dialog dialog = new Dialog(context);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_makeoffer);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        EditText edt_makeoffer = dialog.findViewById(R.id.edt_makeoffer);
        AppCompatButton bt_close = dialog.findViewById(R.id.bt_close);

      bt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              String s_makeoffer = edt_makeoffer.getText().toString().trim();
              if (s_makeoffer.isEmpty())
              {
                  edt_makeoffer.setError(context.getResources().getString(R.string.Please_enter_offer_price));
              }
              else {
                  if(Utils.isInternetConnected(context)) {

                      try {
                          sendPostSendMessage(sessionManager.getSavedUserid(),productDetailData.getSellerdata().getId(),s_makeoffer,productDetailData.getId());
                      } catch (JSONException e) {
                          e.printStackTrace();
                      }
                  }
                  else {
                      CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                  }
              }
                dialog.dismiss();

            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }


}