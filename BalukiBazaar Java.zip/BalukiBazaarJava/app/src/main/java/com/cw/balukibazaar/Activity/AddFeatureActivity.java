package com.cw.balukibazaar.Activity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.ViewShopBundleAdapter;
import com.cw.balukibazaar.Adapter.ViewShopFeatureAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.ProductFeaturesData;
import com.cw.balukibazaar.Interface.ShopBundleData;
import com.cw.balukibazaar.ModelClass.ViewFeatureInfoData;
import com.cw.balukibazaar.ModelClass.ViewProfileResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddFeatureActivity extends AppCompatActivity {
    ArrayList<ViewFeatureInfoData> datalist;
    private List<ViewProfileShop> adddataListMain;
    String user_id,seller_id;
    ImageView img_back;
    Context context;
    TextView txt_itemcount,txt_totalprice,txt_payment;
    private JsonPlaceHolderApi mAPIService;
    RecyclerView recyclerView;
    private ViewShopFeatureAdapter latestAdapter;
    String itemcount="";
    Double itemprice =0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_feature);
        InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                datalist = (ArrayList<ViewFeatureInfoData>) intent.getSerializableExtra("infodata");
                user_id = intent.getStringExtra("user_id");
                seller_id = intent.getStringExtra("seller_id");
                if(Utils.isInternetConnected(context)) {

                    try {
                        sendPost(user_id,seller_id);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        Click();
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        txt_payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("item count >>>>>>>>>>"+itemcount);
                if (itemcount.equals("") || itemcount.equals("0"))
                {
                    CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select_product));
                }
                else {
                    Intent intent = new Intent(context,FeaturePaymentActivity.class);
                    intent.putExtra("featuredata", (Serializable) adddataListMain);
                    startActivity(intent);
                }
            }
        });

    }

    private void InitView() {
        context = AddFeatureActivity.this;
        mAPIService = ApiUtils.getAPIService();
        img_back = findViewById(R.id.img_back);
        recyclerView = findViewById(R.id.recyclerView);
        txt_itemcount = findViewById(R.id.txt_itemcount);
        txt_totalprice = findViewById(R.id.txt_totalprice);
        txt_payment = findViewById(R.id.txt_payment);
    }
    public void sendPost(String user_id,String seller_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.getprofiledata(user_id,seller_id).enqueue(new Callback<ViewProfileResponse>() {
            @Override
            public void onResponse(Call<ViewProfileResponse> call, Response<ViewProfileResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        for (int i=0;i<response.body().getData().getShop().size();i++)
                        {
                            ViewProfileShop viewProfileShop = new ViewProfileShop();
                            viewProfileShop.setSelected(false);
                        }
                        recyclerView.setLayoutManager(new GridLayoutManager(context, 2, GridLayoutManager.VERTICAL, false));
                        recyclerView.setHasFixedSize(true);
                        latestAdapter = new ViewShopFeatureAdapter(context,response.body().getData().getShop(),response.body().getData(), new ProductFeaturesData() {
                            @Override
                            public void getproductfeaturesdata(Integer item_count, String product_ids, double itemprice, List<ViewProfileShop> adddataList) {
                                itemcount = item_count+"";
                                txt_itemcount.setText(item_count+" Items");
                                adddataListMain = adddataList;

                            Double x = 0.0;

                                if (item_count<Integer.parseInt(datalist.get(datalist.size()-1).getQuantity())){
                                   x = ((item_count/Integer.parseInt(datalist.get(datalist.size()-1).getQuantity()))*Double.parseDouble(datalist.get(datalist.size()-1).getRate())+(item_count%Integer.parseInt(datalist.get(datalist.size()-1).getQuantity()))*Double.parseDouble(datalist.get(datalist.size()-1).getRate()));
                                   System.out.println("x value >>>>>>>>>"+x);
                                   x = x/2;
                            }
                                else
                                {
                                    x = ((item_count/Integer.parseInt(datalist.get(datalist.size()-1).getQuantity()))*Double.parseDouble(datalist.get(datalist.size()-1).getRate())+(item_count%Integer.parseInt(datalist.get(datalist.size()-1).getQuantity()))*Double.parseDouble(datalist.get(datalist.size()-1).getRate()));
                                    System.out.println("x value >>>>>>>>>"+x);
                                }
                            txt_totalprice.setText(x+"");
                            }
                        });

                        recyclerView.setAdapter(latestAdapter);

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<ViewProfileResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }
}