package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.MonthNameMain;
import com.cw.balukibazaar.R;

import java.util.ArrayList;


public class MyWalletAdapter extends RecyclerView.Adapter<MyWalletAdapter.ViewHolder> {
    Context context;
    ArrayList<MonthNameMain> monthNameMains;
    MysubListAdapter adaptersubcon;

    public MyWalletAdapter(Context context, ArrayList<MonthNameMain> monthNameMains) {
        this.context = context;
        this.monthNameMains = monthNameMains;

    }

    @NonNull
    @Override
    public MyWalletAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.custome_creditlist_row, parent, false);
        ViewHolder viewHolder = new MyWalletAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyWalletAdapter.ViewHolder holder, int position) {

        try {
           // List<GetWalletTransaction> data = eventMainModelClasses.get(position).getTransaction();
            holder.txt_monname.setText(monthNameMains.get(position).getMonthname());

            boolean status = monthNameMains.get(position).isclick;

            if (status) {
                holder.nonlistview.setVisibility(View.VISIBLE);
                holder.img_arrow.setBackground(context.getResources().getDrawable(R.drawable.ic_up_arrow_black));
            } else {
                holder.nonlistview.setVisibility(View.GONE);
                holder.img_arrow.setBackground(context.getResources().getDrawable(R.drawable.ic_down_arrow_black));

            }

            holder.img_arrow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean status = monthNameMains.get(position).isclick;
                    if (status) {
//                            holder.nonlistview.setVisibility(View.VISIBLE);
//                            holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_up_arrow_black));
                        monthNameMains.get(position).setIsclick(false);
                        notifyDataSetChanged();
                    } else {
//                            holder.nonlistview.setVisibility(View.GONE);
//                            holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_down_arrow_black));
                        monthNameMains.get(position).setIsclick(true);
                        notifyDataSetChanged();
                    }


                }
            });


            adaptersubcon = new MysubListAdapter(context,monthNameMains.get(position).getContestList());
            holder.nonlistview.setHasFixedSize(true);
            holder.nonlistview.setLayoutManager(new LinearLayoutManager(context));
            holder.nonlistview.setAdapter(adaptersubcon);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RecyclerView nonlistview;
        ImageView img_arrow;
        TextView txt_monname,txt_status;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            nonlistview = itemView.findViewById(R.id.nonlistview);
            img_arrow = itemView.findViewById(R.id.img_arrow);
            txt_monname = (TextView) itemView.findViewById(R.id.txt_monname);
            txt_status = (TextView) itemView.findViewById(R.id.txt_status);
        }
    }
}
