package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.LoginResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    ImageView iv_back;
    TextView tv_forgot_pass,btn_login,tv_signup;
    Activity activity;
    EditText edt_email,edt_password;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        InitView();
        System.out.println("Firebase token>>>>>>>>>> "+ FirebaseInstanceId.getInstance().getToken());
        sessionManager.setSavedFcmtoken(FirebaseInstanceId.getInstance().getToken());

        //Device Id
        String m_androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        System.out.println("Device Id >>>>>>>>>> "+ m_androidId);
        sessionManager.setSavedDeviceid(m_androidId);
        Click();
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        tv_forgot_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity,ForgotpasswordActivity.class);
                startActivity(intent);
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email,password;
                email = edt_email.getText().toString().trim();
                password = edt_password.getText().toString().trim();
                if (email.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,getString(R.string.Please_enter_email_address));
                }
                else if (!isValidEmail(email))
                {
                    CustomAlertdialog.createDialog(activity,getString(R.string.Please_enter_valid_email));
                }
                else if (password.isEmpty()){
                    CustomAlertdialog.createDialog(activity,getString(R.string.Please_enter_password));
                }
                else if (password.length()<6)
                {
                    CustomAlertdialog.createDialog(activity,getString(R.string.Password_size_is_small_at_least_6_minimum));
                }
                else {
                    if(Utils.isInternetConnected(activity)) {

                        try {
                            sendPost(email, password);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                    }
                }
            }
        });
        tv_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity,SignupActivity.class);
                startActivity(intent);
            }
        });
    }
    private boolean isValidEmail(CharSequence email) {
        if (!TextUtils.isEmpty(email)) {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
        return false;
    }
    private void InitView() {
        activity = LoginActivity.this;
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(activity);
        iv_back = findViewById(R.id.iv_back);
        tv_forgot_pass = findViewById(R.id.tv_forgot_pass);
        btn_login = findViewById(R.id.btn_login);
        tv_signup = findViewById(R.id.tv_signup);
        edt_email = findViewById(R.id.edt_email);
        edt_password = findViewById(R.id.edt_password);
    }
    public void sendPost(String email, String password) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);


        mAPIService.login(email,sessionManager.getSavedStringFcmtoken(),password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        String User_id = response.body().getData().getId();

                        sessionManager.setSavedUserid(User_id);
                        sessionManager.setUserLoggedIn(true);
                        sessionManager.setSavedUserName(response.body().getData().getSellername());


                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(activity, DashboardActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("about","0");
                        startActivity(intent);
                        finish();

                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", "Unable to submit post to API.");
            }
        });
    }
}