package com.cw.balukibazaar.Interface;

public interface SizeFilter {
    void getSizeid(String cateid);
}
