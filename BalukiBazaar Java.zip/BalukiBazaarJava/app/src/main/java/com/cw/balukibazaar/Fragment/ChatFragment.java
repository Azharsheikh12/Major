package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.InboxAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.ThingsModel;
import com.cw.balukibazaar.ModelClass.ViewChatListResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatFragment extends Fragment {

    RecyclerView recyclerView;
    InboxAdapter MyListAdapter;
    Context context;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    String user_id;
    ImageView img_notification;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_chat, container, false);
        InitView(v);
        Click();

        if (sessionManager.isUserLogin())
        {
            user_id = sessionManager.getSavedUserid();
            if(Utils.isInternetConnected(context)) {

                try {
                    sendPost(user_id);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
            }
        }
        else {
            user_id = "0";
            if(Utils.isInternetConnected(context)) {

                try {
                    sendPost(user_id);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
            }
        }
        return v;
    }

    private void Click() {
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }

    private void InitView(View v) {
        context = getActivity();
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(context);
        recyclerView = v.findViewById(R.id.recyclerView);
        img_notification = v.findViewById(R.id.img_notification);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }


    public void sendPost(String user_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.viewchatdata(user_id).enqueue(new Callback<ViewChatListResponse>() {
            @Override
            public void onResponse(Call<ViewChatListResponse> call, Response<ViewChatListResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        MyListAdapter = new InboxAdapter(context,response.body().getData());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(new LinearLayoutManager(context));
                        recyclerView.setAdapter(MyListAdapter);


                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewChatListResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

}