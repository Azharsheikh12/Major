package com.cw.balukibazaar.Interface;

public interface ShippingStatus {
    void getshippingstatus(String shipping_id, String action);

}
