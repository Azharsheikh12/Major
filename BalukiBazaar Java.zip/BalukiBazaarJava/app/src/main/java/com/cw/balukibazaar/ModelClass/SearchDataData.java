
package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SearchDataData implements Serializable {

    @SerializedName("featured")
    @Expose
    private List<SearchDataFeatured> featured = null;
    @SerializedName("others")
    @Expose
    private List<SearchDataOther> others = null;

    public List<SearchDataFeatured> getFeatured() {
        return featured;
    }

    public void setFeatured(List<SearchDataFeatured> featured) {
        this.featured = featured;
    }

    public List<SearchDataOther> getOthers() {
        return others;
    }

    public void setOthers(List<SearchDataOther> others) {
        this.others = others;
    }

}
