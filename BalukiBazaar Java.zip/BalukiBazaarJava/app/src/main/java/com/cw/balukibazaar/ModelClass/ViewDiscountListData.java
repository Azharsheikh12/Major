package com.cw.balukibazaar.ModelClass;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class ViewDiscountListData implements Serializable {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("no_of_item")
    @Expose
    private String noOfItem;
    @SerializedName("discount_per")
    @Expose
    private String discountPer;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNoOfItem() {
        return noOfItem;
    }

    public void setNoOfItem(String noOfItem) {
        this.noOfItem = noOfItem;
    }

    public String getDiscountPer() {
        return discountPer;
    }

    public void setDiscountPer(String discountPer) {
        this.discountPer = discountPer;
    }
}
