package com.cw.balukibazaar.Interface;

public interface BrandFilter {
    void getBrandid(String cateid);
}
