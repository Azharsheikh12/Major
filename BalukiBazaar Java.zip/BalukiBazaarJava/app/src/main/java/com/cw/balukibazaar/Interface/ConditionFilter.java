package com.cw.balukibazaar.Interface;

public interface ConditionFilter {
    void getConditionid(String cateid);
}
