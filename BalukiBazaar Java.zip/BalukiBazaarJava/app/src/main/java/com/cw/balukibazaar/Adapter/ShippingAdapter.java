package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.ShippingStatus;
import com.cw.balukibazaar.ModelClass.ShippingData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ShippingAdapter extends RecyclerView.Adapter<ShippingAdapter.ViewHolder> {
    private List<ShippingData> data;
    private Context context;
    ShippingStatus status;
    String action;

    public ShippingAdapter(Context context, List<ShippingData> data, ShippingStatus status) {
        this.context = context;
        this.data = data;
        this.status = status;

    }

    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_shipping, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

        ShippingData listdata = data.get(position);
        viewHolder.tv_shippingname.setText(listdata.getCarrierName());
        viewHolder.tv_service.setText(listdata.getService());
        Picasso.get().load(Allurls.ImageURL + listdata.getLogo())
                .error(R.drawable.progress_animation)
                .placeholder(R.drawable.img_shipping)
                .into(viewHolder.iv_logo);

        if (listdata.getStatus().equals("0")) {
            viewHolder.sw_status.setChecked(false);
            action ="ON";
        } else {
            viewHolder.sw_status.setChecked(true);
            action ="OFF";
        }

        viewHolder.sw_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                status.getshippingstatus(listdata.getId(),action);
            }
        });
    }

    // Return the size arraylist
    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_shippingname, tv_service, tv_price;
        public LinearLayout ll_main;
        public ImageView iv_logo;
        SwitchCompat sw_status;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);


            tv_shippingname = itemLayoutView.findViewById(R.id.tv_shippingname);
            tv_service = itemLayoutView.findViewById(R.id.tv_service);
            sw_status = itemLayoutView.findViewById(R.id.sw_status);
            iv_logo = itemLayoutView.findViewById(R.id.iv_logo);


        }

    }


}

