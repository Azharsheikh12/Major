package com.cw.balukibazaar.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Adapter.PurchaseItemSoldDetailsAdapter;
import com.cw.balukibazaar.ModelClass.MyOrderData;
import com.cw.balukibazaar.R;


public class PurchasedItemsFragment extends Fragment {
    String totalamt,discountamt;
    TextView tv_item,txt_shipamt;
    ImageView iv_back,img_notification;
    RecyclerView rv_items;
    Context context;
    PurchaseItemSoldDetailsAdapter adapter;
    MyOrderData soldData;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_purchased_items_details, container, false);
        InitView(v);
        click();
        try {

            soldData = (MyOrderData) getArguments().getSerializable("data");
            totalamt = getArguments().getString("totalamt");
            discountamt = getArguments().getString("discountamt");

            tv_item.setText("€ "+totalamt);
            txt_shipamt.setText("€ +"+discountamt+" envio");

            rv_items.setHasFixedSize(true);
            rv_items.setLayoutManager(new LinearLayoutManager(context));
            adapter = new PurchaseItemSoldDetailsAdapter(context,soldData.getDetail());
            rv_items.setAdapter(adapter);

        }catch (Exception e)
        {
            e.printStackTrace();
        }



        return v;
    }

    private void click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    private void InitView(View v) {
        context = getActivity();
        iv_back = v.findViewById(R.id.iv_back);
        tv_item = v.findViewById(R.id.tv_item);
        txt_shipamt = v.findViewById(R.id.txt_shipamt);
        rv_items = v.findViewById(R.id.rv_items);
        img_notification = v.findViewById(R.id.img_notification);
    }
}