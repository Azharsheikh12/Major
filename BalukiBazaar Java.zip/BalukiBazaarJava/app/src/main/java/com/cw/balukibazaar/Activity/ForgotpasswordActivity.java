package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.LoginResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgotpasswordActivity extends AppCompatActivity {

    ImageView iv_back;
    Context activity;
    TextView btn_send_mail;
    EditText edt_email;
    String s_email;
    private JsonPlaceHolderApi mAPIService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotpassword);
        InitView();
        Click();
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        btn_send_mail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                s_email = edt_email.getText().toString().trim();
                if (s_email.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,getResources().getString(R.string.Please_enter_email_address));
                }
                else if (!isValidEmail(s_email))
                {
                    CustomAlertdialog.createDialog(activity,getString(R.string.Please_enter_valid_email));
                }
                else {
                    if(Utils.isInternetConnected(activity)) {

                        try {
                            sendPost(s_email);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                    }
                }
            }
        });
    }
    private boolean isValidEmail(CharSequence email) {
        if (!TextUtils.isEmpty(email)) {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
        return false;
    }
    private void InitView() {
        activity = ForgotpasswordActivity.this;
        mAPIService = ApiUtils.getAPIService();
        iv_back = findViewById(R.id.iv_back);
        btn_send_mail = findViewById(R.id.btn_send_mail);
        edt_email = findViewById(R.id.edt_email);
    }
    public void sendPost(String email) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);
        mAPIService.forgotpassword(email).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        edt_email.setText("");
                     finish();
                     Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

}