package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.cw.balukibazaar.Adapter.ViewCategoryAdapter;
import com.cw.balukibazaar.Adapter.ViewShopBundleOrderAdapter;
import com.cw.balukibazaar.Adapter.ViewThingsWeLoveAdapter;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;

import java.io.Serializable;
import java.util.List;

public class ShopBundleOrderActivity extends AppCompatActivity {
    LinearLayoutManager HorizontalLayout;
    ImageView img_back;
    TextView txt_itemcount,txt_disprice,txt_totalprice,txt_itemsprice;
    RecyclerView recyclerView;
    Button btn_confirm;
    String totalproce,totaldiscount,itemcount,seller_id,discount_id;
    public List<ViewProfileShop> transferShopDataListMain;
    private ViewShopBundleOrderAdapter thingAdapter;
    Context context;
    Double completetotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_bundle_order);
        InitView();
        Click();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                transferShopDataListMain = (List<ViewProfileShop>) intent.getSerializableExtra("shopdata");
                totalproce = intent.getStringExtra("totalproce");
                totaldiscount = intent.getStringExtra("totaldiscount");
                itemcount = intent.getStringExtra("itemcount");
                seller_id = intent.getStringExtra("seller_id");
                discount_id = intent.getStringExtra("discount_id");

                txt_itemsprice.setText(totalproce);
                txt_disprice.setText(totaldiscount);
                completetotal = Double.parseDouble(totalproce)-Double.parseDouble(totaldiscount);
                txt_totalprice.setText(completetotal+"");
                txt_itemcount.setText(itemcount+" Items");

                HorizontalLayout = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
                recyclerView.setLayoutManager(HorizontalLayout);
                recyclerView.setHasFixedSize(true);
                thingAdapter = new ViewShopBundleOrderAdapter(context,transferShopDataListMain);
                recyclerView.setAdapter(thingAdapter);

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("completetotal >>>>>>>>>"+completetotal);

                Intent intent = new Intent(context,ShopBundlePaymentActivity.class);
                intent.putExtra("shopdata", (Serializable) transferShopDataListMain);
                intent.putExtra("totalamt", completetotal);
                intent.putExtra("totaldiscountamt",totaldiscount );
                intent.putExtra("seller_id",seller_id );
                intent.putExtra("discount_id",discount_id );
                startActivity(intent);
            }
        });
    }

    private void InitView() {
        context = ShopBundleOrderActivity.this;
        img_back = findViewById(R.id.img_back);
        txt_itemcount = findViewById(R.id.txt_itemcount);
        recyclerView = findViewById(R.id.recyclerView);
        txt_disprice = findViewById(R.id.txt_disprice);
        txt_totalprice = findViewById(R.id.txt_totalprice);
        btn_confirm = findViewById(R.id.btn_confirm);
        txt_itemsprice = findViewById(R.id.txt_itemsprice);

    }
}