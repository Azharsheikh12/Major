package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.ViewProfileData;
import com.cw.balukibazaar.ModelClass.ViewProfileReview;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ViewReviewAdapter extends RecyclerView.Adapter<ViewReviewAdapter.ViewHolder> {
    List<ViewProfileReview> review;
    private Context context;
    ViewProfileData viewProfileData;

    public ViewReviewAdapter(Context context, List<ViewProfileReview> review) {
//        this.stList = students;
        this.context = context;
        this.review = review;

    }
    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_reviews, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.txt_desc.setText(review.get(position).getReview());
        holder.txt_sellname.setText(review.get(position).getUsername());
        holder.txt_proname.setText(review.get(position).getProductname());
        holder.rb_count.setRating(Float.parseFloat(review.get(position).getRating()));
        Picasso.get().load(Allurls.ImageURL+review.get(position).getProductImg()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(holder.img_produ);

    }

    @Override
    public int getItemCount() {
//        return 0;
        return review.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_sellname,txt_desc,txt_proname;
        CircleImageView img_produ;
        RatingBar rb_count;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_sellname = itemLayoutView.findViewById(R.id.txt_sellname);
            txt_desc = itemLayoutView.findViewById(R.id.txt_desc);
            txt_proname = itemLayoutView.findViewById(R.id.txt_proname);
            rb_count = itemLayoutView.findViewById(R.id.rb_count);
            img_produ = itemLayoutView.findViewById(R.id.img_produ);

        }

    }

    public List<ViewProfileReview> getStudentist() {
        return review;
    }
}

