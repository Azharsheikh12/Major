package com.cw.balukibazaar.Interface;

public interface MainFilter {
    void getMainid(String cateid,String sizeid,String colorid,String brandid,String minprice,String maxprice,String conditionid);
}
