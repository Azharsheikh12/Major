package com.cw.balukibazaar.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Adapter.ViewallFavouriteAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.favourate.FavouriteResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MyFavouritesFragment extends Fragment {

    RecyclerView recyclerViewThings;
    Context context;
    ViewallFavouriteAdapter mAdapter;
    ImageView iv_back;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_notification;
    Fragment fragment = null;
    String user_id;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_my_favourites, container, false);

        InitView(v);
        Click();

        if (Utils.isInternetConnected(context)) {
            favouritelist();
        } else {
            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
        }

        return v;
    }

    private void Click() {

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    private void InitView(View v) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        iv_back = v.findViewById(R.id.iv_back);
        recyclerViewThings = v.findViewById(R.id.recyclerViewThings);
        img_notification = v.findViewById(R.id.img_notification);

        user_id = sessionManager.getSavedUserid();
       /* recyclerViewThings.setHasFixedSize(true);
        recyclerViewThings.setLayoutManager(new GridLayoutManager(context,3));
        mAdapter = new ViewallFavouriteAdapter(context);
        recyclerViewThings.setAdapter(mAdapter);*/
    }

    public void favouritelist() {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.favouritelist(sessionManager.getSavedUserid()).enqueue(new Callback<FavouriteResponse>() {
            @Override
            public void onResponse(Call<FavouriteResponse> call, Response<FavouriteResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status == true) {
                        recyclerViewThings.setVisibility(View.VISIBLE);
                        recyclerViewThings.setHasFixedSize(true);
                        recyclerViewThings.setLayoutManager(new GridLayoutManager(context, 3));
                        mAdapter = new ViewallFavouriteAdapter(context, response.body().getData(), new RemoveFavourite() {
                            @Override
                            public void getproduct_id(String product_id) {
                                sendPostFav(product_id);
                            }
                        });
                        recyclerViewThings.setAdapter(mAdapter);

                    } else {
                        recyclerViewThings.setVisibility(View.GONE);
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<FavouriteResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
            }

        });
    }
    public void sendPostFav(String product_id) {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.addremovefavourite(user_id, product_id).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if (Utils.isInternetConnected(context)) {

                            favouritelist();
                        } else {
                            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "" + t.getMessage());
            }
        });
    }
}