package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.HomeCategory;
import com.cw.balukibazaar.R;

import java.util.List;

public class ViewCategoryAdapter extends RecyclerView.Adapter<ViewCategoryAdapter.ViewHolder> {
    private List<HomeCategory> stList;
    private Context context;

    public ViewCategoryAdapter(Context context, List<HomeCategory> students) {
        this.stList = students;
        this.context = context;

    }
    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_categories_item, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        viewHolder.txt_title.setText(stList.get(position).getName());

    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_title;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_title = itemLayoutView.findViewById(R.id.title);

        }

    }

    public List<HomeCategory> getStudentist() {
        return stList;
    }
}

