package com.cw.balukibazaar.Interface;

public interface CategoryFilter {
    void getCateegoryid(String cateid);
}
