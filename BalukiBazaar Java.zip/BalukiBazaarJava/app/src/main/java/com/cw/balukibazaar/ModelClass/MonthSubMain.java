package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;

public class MonthSubMain implements Serializable {
    public String title;
    public String proname;
    public String proprice;
    public String date;

    public MonthSubMain(String title, String proname, String proprice, String date) {
        this.title = title;
        this.proname = proname;
        this.proprice = proprice;
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }

    public String getProprice() {
        return proprice;
    }

    public void setProprice(String proprice) {
        this.proprice = proprice;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
