package com.cw.balukibazaar.Interface;

public interface ColorFilter {
    void getColorid(String cateid);
}
