package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.AddReviewResponse;
import com.cw.balukibazaar.ModelClass.LoginResponse;
import com.cw.balukibazaar.ModelClass.MyOrderDetail;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddReviewActivity extends AppCompatActivity {

    ImageView img_back;
    MyOrderDetail soldData;
    EditText edt_review;
    RatingBar ratingBar;
    TextView btn_review;
    String s_msg,s_rating,pro_id;
    Context context;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_review);
        InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                soldData = (MyOrderDetail) intent.getSerializableExtra("data");
                pro_id = soldData.getProductId();

            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        Click();


    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_msg = edt_review.getText().toString().trim();
                s_rating = String.valueOf(ratingBar.getRating());
                if (s_msg.isEmpty())
                {
                    CustomAlertdialog.createDialog(context,"Please enter review !");
                }
                else if (s_rating.isEmpty())
                {
                    CustomAlertdialog.createDialog(context,"Please give rating !");
                }
                else {
                    if(Utils.isInternetConnected(context)) {

                        try {
                            sendPost(s_msg, s_rating);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                    }
                }
            }
        });
    }

    private void InitView() {
        context = AddReviewActivity.this;
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(context);
        img_back = findViewById(R.id.img_back);
        edt_review = findViewById(R.id.edt_review);
        ratingBar = findViewById(R.id.ratingBar);
        btn_review = findViewById(R.id.btn_review);
    }

    public void sendPost(String msg, String rating) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.addreviewdata(sessionManager.getSavedUserid(),pro_id,rating,msg).enqueue(new Callback<AddReviewResponse>() {
            @Override
            public void onResponse(Call<AddReviewResponse> call, Response<AddReviewResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful())
                {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(context, DashboardActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("about","0");
                        startActivity(intent);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<AddReviewResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage().toString());
            }
        });
    }

}