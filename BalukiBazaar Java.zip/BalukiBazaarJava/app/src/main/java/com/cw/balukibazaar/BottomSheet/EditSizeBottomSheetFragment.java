package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.GlobalSizeData;
import com.cw.balukibazaar.ModelClass.ProductDetailSize;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.List;


public class EditSizeBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    ImageView iv_close,iv_back;
    TextView btn_submit;
    RecyclerView recycler_size;
    List<GlobalSizeData> categoriesList;
    List<ProductDetailSize> getsizeList;
    CategorySubAdapter MyListAdapter;
    Context context;
    SessionManager sessionManager;
    ArrayList<String> size_list  =new ArrayList();
    LinearLayout rl_main;
    public EditSizeBottomSheetFragment(Context context, List<GlobalSizeData> list, List<ProductDetailSize> sizeList) {
        this.context = context;
        this.categoriesList = list;
        this.getsizeList = sizeList;
    }


    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_size, container, false);
        findIds(view);
        if(sessionManager.getSizeList()!=null)
        {
            if(sessionManager.getSizeList().size() >0){
                size_list= sessionManager.getSizeList();
            }
        }
        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_size.setHasFixedSize(true);
        recycler_size.setLayoutManager(new LinearLayoutManager(context));
        recycler_size.setAdapter(MyListAdapter);
        return view;

    }

    public void findIds(View v) {
        sessionManager= new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_size = v.findViewById(R.id.recycler_size);
        btn_submit = v.findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(this);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                size_list = new ArrayList();
                sessionManager.saveSizeList(size_list);
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                size_list = new ArrayList();
                sessionManager.saveSizeList(size_list);
                dismissAllowingStateLoss();
                break;
            case R.id.btn_submit:
                size_list = new ArrayList();
                sessionManager.saveSizeList(size_list);
                dismissAllowingStateLoss();
                break;
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<GlobalSizeData> eventMainModelClasses;
        private Context context;
        public CategorySubAdapter(Context context, List<GlobalSizeData> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_size_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final GlobalSizeData myListData = eventMainModelClasses.get(position);

            holder.txt_title.setText(categoriesList.get(position).getName());
            for (int i=0;i<getsizeList.size();i++)
            {
                if (getsizeList.get(i).getSizeId().equals(categoriesList.get(position).getId()))
                {
                    holder.cb_size.setChecked(true);
                    size_list.add(getsizeList.get(i).getSizeId());
                    sessionManager.saveSizeList(size_list);
                }
                else {
                    holder.cb_size.setChecked(false);
                }
            }


          /*  if(size_list!=null){
                if(size_list.equals(myListData.getId()))
                holder.cb_size.setChecked(true);
            }*/
            holder.cb_size.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        if(!size_list.equals(myListData.getId())){
                            size_list.add(eventMainModelClasses.get(position).getId());
                            sessionManager.saveSizeList(size_list);
                            Log.e("SizeBottomSheet"," isChecked111 "+size_list.size());
                            Log.e("SizeBottomSheet"," isChecked111 SM "+sessionManager.getSizeList().size());
                        }

                    }else{
                        if(size_list.equals(myListData.getId())){
                            size_list.remove(size_list.indexOf(myListData.getId()));
                            sessionManager.saveSizeList(size_list);
                            Log.e("SizeBottomSheet"," isChecked000 "+size_list.size());
                            Log.e("SizeBottomSheet"," isChecked000 SM "+sessionManager.getSizeList().size());
                        }
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {

            TextView txt_title;
            RelativeLayout re_size;
            CheckBox cb_size;
            public ViewHolder(View itemView) {
                super(itemView);

                txt_title = itemView.findViewById(R.id.txt_title);
                re_size = itemView.findViewById(R.id.re_size);
                cb_size = itemView.findViewById(R.id.cb_size);
            }
        }
    }


}