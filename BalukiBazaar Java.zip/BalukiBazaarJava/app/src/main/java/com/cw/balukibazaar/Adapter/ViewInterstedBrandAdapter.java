package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.ColorFilter;
import com.cw.balukibazaar.ModelClass.GlobalBrandData;
import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.ModelClass.HomeCategory;
import com.cw.balukibazaar.ModelClass.ViewInterestedData;
import com.cw.balukibazaar.R;

import java.util.ArrayList;
import java.util.List;

public class ViewInterstedBrandAdapter extends RecyclerView.Adapter<ViewInterstedBrandAdapter.ViewHolder> {
    private List<GlobalBrandData> stList;
    private Context context;
    ColorFilter colorFilter;
    ArrayList<String> color_list =new  ArrayList();
    List<ViewInterestedData> viewInterestedData;
    public ViewInterstedBrandAdapter(Context context, List<GlobalBrandData> students, ColorFilter colorFilter, List<ViewInterestedData> viewInterestedData) {
        this.stList = students;
        this.context = context;
        this.colorFilter = colorFilter;
        this.viewInterestedData = viewInterestedData;

    }
    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_condition_single, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position)
    {
        final GlobalBrandData myListData = stList.get(position);
        viewHolder.txt_title.setText(stList.get(position).getName());
        for (int i=0;i<viewInterestedData.size();i++)
        {
            if (viewInterestedData.get(i).getInterestId().equals(stList.get(position).getId()))
            {
                viewHolder.cb_condition.setChecked(true);
                color_list.add(viewInterestedData.get(i).getInterestId());
            }
            else {
                viewHolder.cb_condition.setChecked(false);
            }
        }
        viewHolder.cb_condition.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    if(!color_list.equals(myListData.getId())){
                        color_list.add(myListData.getId());
                        String colorid ="";
                        for (int i=0;i<color_list.size();i++){
                            colorid +=color_list.get(i)+",";
                        }
                        colorFilter.getColorid(colorid);
                    }

                }else{
                    color_list.remove(myListData.getId());
//                        color_list.remove(color_list.indexOf(myListData.getId()));
                    String colorid ="";
                    for (int i=0;i<color_list.size();i++){
                        colorid +=color_list.get(i)+",";
                    }
                    colorFilter.getColorid(colorid);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_title;
        public CheckBox cb_condition;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_title = itemLayoutView.findViewById(R.id.txt_title);
            cb_condition = itemLayoutView.findViewById(R.id.cb_condition);
        }
    }

    public List<GlobalBrandData> getStudentist() {
        return stList;
    }
}

