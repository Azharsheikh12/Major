package com.cw.balukibazaar.Interface;

public interface ShopBundleShappingData {
    void getShopbundleshappingdata(String shapping_id,String shappingamt);
}
