package com.cw.balukibazaar.Interface;

public interface RemoveFavourite {
    void getproduct_id(String product_id);
}
