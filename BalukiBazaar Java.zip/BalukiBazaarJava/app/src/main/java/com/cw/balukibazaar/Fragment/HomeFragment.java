package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.ViewCategoryAdapter;
import com.cw.balukibazaar.Adapter.ViewLatestAdapter;
import com.cw.balukibazaar.Adapter.ViewThingsWeLoveAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.HomeCategory;
import com.cw.balukibazaar.ModelClass.HomeLatest;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.HomeThingswelove;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    ImageView img_bell;
    Fragment fragment = null;
    RecyclerView rec_cate,rec_things_welove,recyclerViewLatest;
    private ViewCategoryAdapter cateAdapter;
    private ViewThingsWeLoveAdapter thingAdapter;
    private ViewLatestAdapter latestAdapter;
    LinearLayoutManager HorizontalLayout;
    LinearLayout ll_see_more;
    TextView tv_name,txt_thinsellall;
    Activity activity;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    String user_id;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_home, container, false);
        InitView(v);
        Click();

        if (sessionManager.isUserLogin())
        {
            tv_name.setText(sessionManager.getSavedUserName());
            user_id = sessionManager.getSavedUserid();
        }
        else {
            tv_name.setText(getResources().getString(R.string.Welcome_user));
            user_id = "0";
        }


        if(Utils.isInternetConnected(activity)) {

            try {
                sendPost(user_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }

        return v;
    }

    private void LatestAdapterSetup(List<HomeLatest> latest) {
        System.out.println("latest list size >>>>>>>>>"+latest.size());
        int size = latest.size();

        if (size>18)
        {
            System.out.println("latest under list size >>>>>>>>>"+latest.size());
            ll_see_more.setVisibility(View.VISIBLE);
            recyclerViewLatest.setLayoutManager(new GridLayoutManager(getActivity(), 2, GridLayoutManager.HORIZONTAL, false));
            recyclerViewLatest.setHasFixedSize(true);
            latestAdapter = new ViewLatestAdapter(getActivity(),latest,18);
            recyclerViewLatest.setNestedScrollingEnabled(false);
            recyclerViewLatest.setAdapter(latestAdapter);
        }
        else
            {
            ll_see_more.setVisibility(View.GONE);
            recyclerViewLatest.setLayoutManager(new GridLayoutManager(getActivity(), 2, GridLayoutManager.HORIZONTAL, false));
            recyclerViewLatest.setHasFixedSize(true);
            latestAdapter = new ViewLatestAdapter(getActivity(),latest,size);
                recyclerViewLatest.setNestedScrollingEnabled(false);
            recyclerViewLatest.setAdapter(latestAdapter);
        }


    }

    private void ThingsAdapterSetup(List<HomeThingswelove> thingswelove) {
       /* rec_things_welove.setLayoutManager(new GridLayoutManager(getActivity(),3));
        rec_things_welove.setHasFixedSize(true);
        thingAdapter = new ViewThingsWeLoveAdapter(getActivity(),thingswelove,size);
        rec_things_welove.setAdapter(thingAdapter);*/


        System.out.println("latest list size >>>>>>>>>"+thingswelove.size());
        int size = thingswelove.size();

        if (size>18)
        {
            System.out.println("latest under list size >>>>>>>>>"+thingswelove.size());
            rec_things_welove.setLayoutManager(new GridLayoutManager(getActivity(), 2, GridLayoutManager.HORIZONTAL, false));
            rec_things_welove.setHasFixedSize(true);
            thingAdapter = new ViewThingsWeLoveAdapter(getActivity(),thingswelove,18);
            rec_things_welove.setNestedScrollingEnabled(false);
            rec_things_welove.setAdapter(thingAdapter);
        }
        else
        {
            rec_things_welove.setLayoutManager(new GridLayoutManager(getActivity(), 2, GridLayoutManager.HORIZONTAL, false));
            rec_things_welove.setHasFixedSize(true);
            thingAdapter = new ViewThingsWeLoveAdapter(getActivity(),thingswelove,size);
            rec_things_welove.setNestedScrollingEnabled(false);
            rec_things_welove.setAdapter(thingAdapter);
        }


    }

    private void CategoryAdapterSetup(List<HomeCategory> category)
    {
        HorizontalLayout = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        rec_cate.setLayoutManager(HorizontalLayout);
        rec_cate.setHasFixedSize(true);
        cateAdapter = new ViewCategoryAdapter(getActivity(),category);
        rec_cate.setAdapter(cateAdapter);
    }

    private void Click() {
        img_bell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });

        txt_thinsellall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                fragment = new ThingsWeLoveSellAllFragment();
                loadFragment(fragment);
            }
        });

        ll_see_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new LatestListingsFragment();
                loadFragment(fragment);
            }
        });
    }

    private void InitView(View v) {
        activity = getActivity();
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(activity);
        img_bell = v.findViewById(R.id.img_bell);
        rec_cate = v.findViewById(R.id.rec_cate);
        rec_things_welove = v.findViewById(R.id.rec_things_welove);
        recyclerViewLatest = v.findViewById(R.id.recyclerViewLatest);
        tv_name = v.findViewById(R.id.tv_name);
        txt_thinsellall = v.findViewById(R.id.txt_thinsellall);
        ll_see_more = v.findViewById(R.id.ll_see_more);
    }

        private boolean loadFragment(Fragment fragment) {
            if (fragment != null) {

                getActivity().getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack("gghh")
                        .commit();
                return true;
            }
            return false;
        }

    public void sendPost(String user_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);


        mAPIService.gethomedata(user_id).enqueue(new Callback<HomeResponse>() {
            @Override
            public void onResponse(Call<HomeResponse> call, Response<HomeResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {


                        CategoryAdapterSetup(response.body().getData().getCategory());

                       /* int size = response.body().getData().getThingswelove().size();
                        if (size<6)
                        {
                            ThingsAdapterSetup(response.body().getData().getThingswelove(),size);
                        }
                        else {
                            ThingsAdapterSetup(response.body().getData().getThingswelove(),6);
                        }

*/
                        ThingsAdapterSetup(response.body().getData().getThingswelove());
                        LatestAdapterSetup(response.body().getData().getLatest());

                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<HomeResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }
}