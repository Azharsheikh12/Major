package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.DiscountListUpdateResponse;
import com.cw.balukibazaar.ModelClass.ViewDiscountListData;
import com.cw.balukibazaar.ModelClass.ViewDiscountListResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.cw.balukibazaar.Utils.CustomAlertdialog.createDialog;

public class DiscountFragment extends Fragment {

    ImageView iv_back,iv_notification;
    Activity activity;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    SwitchCompat swstatus;
    LinearLayout layout_discount;
    RecyclerView recycler_discount;
    private ViewBannerAdapter mAdapter;
    String discount_status;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_discount, container, false);
        InitView(v);
        Click();

        if(Utils.isInternetConnected(activity)) {

            try {
                sendPost();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }
        return v;
    }

    private void Click() {
        iv_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        swstatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (discount_status.equals("ON"))
                {
                    if(Utils.isInternetConnected(activity)) {

                        try {
                            sendPostupdatestatus("OFF");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getResources().getString(R.string.no_internet));
                    }
                }
                else {
                    if(Utils.isInternetConnected(activity)) {
                        try {
                            sendPostupdatestatus("ON");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                    }
                }
            }
        });
    }

    private void InitView(View v) {
        activity = getActivity();
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(activity);
        iv_back = v.findViewById(R.id.iv_back);
        iv_notification = v.findViewById(R.id.iv_notification);
//        img_edit1 = v.findViewById(R.id.img_edit1);
        swstatus = v.findViewById(R.id.swstatus);
        recycler_discount = v.findViewById(R.id.recycler_discount);
        layout_discount = v.findViewById(R.id.layout_discount);
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    public void sendPost() throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.getdiscountlist(sessionManager.getSavedUserid()).enqueue(new Callback<ViewDiscountListResponse>() {
            @Override
            public void onResponse(Call<ViewDiscountListResponse> call, Response<ViewDiscountListResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        discount_status = response.body().getDiscount();

                        if (discount_status.equals("ON"))
                        {
                            swstatus.setChecked(true);
                            layout_discount.setVisibility(View.VISIBLE);
                        }
                        else {

                            swstatus.setChecked(false);
                            layout_discount.setVisibility(View.GONE);
                        }
                        recycler_discount.setHasFixedSize(true);
                        recycler_discount.setLayoutManager(new LinearLayoutManager(activity));
                        mAdapter = new ViewBannerAdapter(activity, response.body().getData());
                        recycler_discount.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();

                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<ViewDiscountListResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", "Unable to submit post to API.");
            }
        });
    }

    public void sendPostupdatestatus(String disstatus) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.updatediscountstatus(sessionManager.getSavedUserid(),disstatus).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if(Utils.isInternetConnected(activity)) {

                            try {
                                sendPost();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                        }
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostupdatediscount(String disvalue,String itemid,String itemcount) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.updatediscountlist(sessionManager.getSavedUserid(),itemid,itemcount,disvalue).enqueue(new Callback<DiscountListUpdateResponse>() {
            @Override
            public void onResponse(Call<DiscountListUpdateResponse> call, Response<DiscountListUpdateResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if(Utils.isInternetConnected(activity)) {

                            try {
                                sendPost();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                        }
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<DiscountListUpdateResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public class ViewBannerAdapter extends RecyclerView.Adapter<ViewBannerAdapter.ViewHolder> {
        private List<ViewDiscountListData> stList;
        private Context context;

        public ViewBannerAdapter(Context context, List<ViewDiscountListData> students) {
            this.stList = students;
            this.context = context;

        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_discount, parent,false);

            ViewHolder viewHolder = new ViewHolder(itemLayoutView);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

            viewHolder.txt_name.setText(stList.get(position).getNoOfItem()+" items");
            viewHolder.txt_discount.setText(stList.get(position).getDiscountPer()+" %");

            viewHolder.img_edit1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    createDialogupdate(context,stList.get(position).getId(),stList.get(position).getDiscountPer(),stList.get(position).getNoOfItem());
                }
            });
        }
        @Override
        public int getItemCount() {
            return stList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {


            public TextView txt_name,txt_discount;
            public ImageView img_edit1;

            public ViewHolder(View itemLayoutView) {
                super(itemLayoutView);

                txt_name = itemLayoutView.findViewById(R.id.txt_name);
                txt_discount = itemLayoutView.findViewById(R.id.txt_discount);
                img_edit1 = itemLayoutView.findViewById(R.id.img_edit1);

            }

        }

        // method to access in activity after updating selection
        public List<ViewDiscountListData> getStudentist() {
            return stList;
        }

    }

    private void createDialogupdate(Context context, String id, String discountPer, String noOfItem) {
        final Dialog dialog = new Dialog(context);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_discount);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        TextView txt_submit = (TextView) dialog.findViewById(R.id.txt_submit);
        TextView txt_close = (TextView) dialog.findViewById(R.id.txt_close);
        RadioGroup radioGroup =  dialog.findViewById(R.id.radioGroup);
        txt_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                RadioButton   radioButton =dialog.findViewById(selectedId);

                String discount = radioButton.getText().toString().trim();
                String discountamt ="0";
                System.out.println("discount >>>>>>>>"+discount);
                if (discount.equals("-"))
                {
                    discountamt="0";
                }
                else if (discount.equals("5%"))
                {
                    discountamt="5";
                }
                else if (discount.equals("10%"))
                {
                    discountamt="10";
                }
                else if (discount.equals("15%"))
                {
                    discountamt="15";
                }
                else if (discount.equals("20%"))
                {
                    discountamt="20";
                }
                else if (discount.equals("25%"))
                {
                    discountamt = "25";
                }
                else if (discount.equals("30%"))
                {
                    discountamt = "30";
                }
                else if (discount.equals("40%"))
                {
                    discountamt = "40";
                }
                else if (discount.equals("50%"))
                {
                    discountamt="50";
                }

                if(Utils.isInternetConnected(context)) {

                    try {
                        sendPostupdatediscount(discountamt,id,noOfItem);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    CustomAlertdialog.createDialog(context,context.getString(R.string.no_internet));
                }

                dialog.dismiss();
            }
        });

        txt_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
}