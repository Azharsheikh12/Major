
package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HomeData implements Serializable {

    @SerializedName("category")
    @Expose
    private List<HomeCategory> category = null;
    @SerializedName("thingswelove")
    @Expose
    private List<HomeThingswelove> thingswelove = null;
    @SerializedName("latest")
    @Expose
    private List<HomeLatest> latest = null;

    public List<HomeCategory> getCategory() {
        return category;
    }

    public void setCategory(List<HomeCategory> category) {
        this.category = category;
    }

    public List<HomeThingswelove> getThingswelove() {
        return thingswelove;
    }

    public void setThingswelove(List<HomeThingswelove> thingswelove) {
        this.thingswelove = thingswelove;
    }

    public List<HomeLatest> getLatest() {
        return latest;
    }

    public void setLatest(List<HomeLatest> latest) {
        this.latest = latest;
    }

}
