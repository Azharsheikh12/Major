
package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.databind.ser.Serializers;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProductDetailData implements Serializable {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("user_id")
    @Expose
    private String userId;
    @SerializedName("category_id")
    @Expose
    private String categoryId;
    @SerializedName("brand_id")
    @Expose
    private String brandId;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("condition_id")
    @Expose
    private String conditionId;
    @SerializedName("price")
    @Expose
    private String price;
    @SerializedName("color")
    @Expose
    private List<ProductDetailColor> color = null;
    @SerializedName("size")
    @Expose
    private List<ProductDetailSize> size = null;
    @SerializedName("is_featured")
    @Expose
    private String isFeatured;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("is_favorite")
    @Expose
    private String is_favorite;

    @SerializedName("in_draft")
    @Expose
    private String inDraft;
    @SerializedName("created_on")
    @Expose
    private String createdOn;
    @SerializedName("categoryname")
    @Expose
    private String categoryname;
    @SerializedName("conditionname")
    @Expose
    private String conditionname;
    @SerializedName("likes")
    @Expose
    private String likes;
    @SerializedName("brandname")
    @Expose
    private String brandname;
    @SerializedName("dis_id")
    @Expose
    private String dis_id;

    @SerializedName("images")
    @Expose
    private List<ProductDetailImage> images = null;
    @SerializedName("sellerdata")
    @Expose
    private ProductDetailSellerdata sellerdata;
    @SerializedName("dis_percent")
    @Expose
    private String disPercent;
    @SerializedName("moreitems")
    @Expose
    private List<ProductDetailMoreitem> moreitems = null;
    @SerializedName("similaritems")
    @Expose
    private List<ProductDetailSimilaritem> similaritems = null;

    public String getDis_id() {
        return dis_id;
    }

    public void setDis_id(String dis_id) {
        this.dis_id = dis_id;
    }

    public String getIs_favorite() {
        return is_favorite;
    }

    public void setIs_favorite(String is_favorite) {
        this.is_favorite = is_favorite;
    }

    public String getConditionname() {
        return conditionname;
    }

    public void setConditionname(String conditionname) {
        this.conditionname = conditionname;
    }

    public String getLikes() {
        return likes;
    }

    public void setLikes(String likes) {
        this.likes = likes;
    }

    public String getBrandname() {
        return brandname;
    }

    public void setBrandname(String brandname) {
        this.brandname = brandname;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getBrandId() {
        return brandId;
    }

    public void setBrandId(String brandId) {
        this.brandId = brandId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getConditionId() {
        return conditionId;
    }

    public void setConditionId(String conditionId) {
        this.conditionId = conditionId;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public List<ProductDetailColor> getColor() {
        return color;
    }

    public void setColor(List<ProductDetailColor> color) {
        this.color = color;
    }

    public List<ProductDetailSize> getSize() {
        return size;
    }

    public void setSize(List<ProductDetailSize> size) {
        this.size = size;
    }

    public String getIsFeatured() {
        return isFeatured;
    }

    public void setIsFeatured(String isFeatured) {
        this.isFeatured = isFeatured;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getInDraft() {
        return inDraft;
    }

    public void setInDraft(String inDraft) {
        this.inDraft = inDraft;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getCategoryname() {
        return categoryname;
    }

    public void setCategoryname(String categoryname) {
        this.categoryname = categoryname;
    }

    public List<ProductDetailImage> getImages() {
        return images;
    }

    public void setImages(List<ProductDetailImage> images) {
        this.images = images;
    }

    public ProductDetailSellerdata getSellerdata() {
        return sellerdata;
    }

    public void setSellerdata(ProductDetailSellerdata sellerdata) {
        this.sellerdata = sellerdata;
    }

    public String getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(String disPercent) {
        this.disPercent = disPercent;
    }

    public List<ProductDetailMoreitem> getMoreitems() {
        return moreitems;
    }

    public void setMoreitems(List<ProductDetailMoreitem> moreitems) {
        this.moreitems = moreitems;
    }

    public List<ProductDetailSimilaritem> getSimilaritems() {
        return similaritems;
    }

    public void setSimilaritems(List<ProductDetailSimilaritem> similaritems) {
        this.similaritems = similaritems;
    }

}
