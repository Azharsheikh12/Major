package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.GlobalConditionData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;


public class EditConditionBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    ImageView iv_close,iv_back;
    RecyclerView recycler_size;
    List<GlobalConditionData> categoriesList;
    CategorySubAdapter MyListAdapter;
    Context context;
    SessionManager sessionManager;
    String condition_id,getCondition_id;
    RelativeLayout rl_main;
    public EditConditionBottomSheetFragment(Context context, List<GlobalConditionData> conditionList, String condition_id) {
        this.context = context;
        this.categoriesList = conditionList;
        this.getCondition_id = condition_id;
    }


    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_condition, container, false);
        findIds(view);
        if(sessionManager.getCondition() !=null){
            condition_id=sessionManager.getCondition();
        }
        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_size.setHasFixedSize(true);
        recycler_size.setLayoutManager(new LinearLayoutManager(context));
        recycler_size.setAdapter(MyListAdapter);
        return view;

    }

    public void findIds(View v) {
        sessionManager = new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_size = v.findViewById(R.id.recycler_brand);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                condition_id = "0";
                sessionManager.saveCondition(condition_id);
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                dismissAllowingStateLoss();
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<GlobalConditionData> eventMainModelClasses;
        private Context context;
        // RecyclerView recyclerView;
        public CategorySubAdapter(Context context, List<GlobalConditionData> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_condition_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final GlobalConditionData myListData = eventMainModelClasses.get(position);

            holder.txt_colorname.setText(myListData.getName());
            if (getCondition_id.equals(myListData.getId()))
            {
                holder.cb_condition.setChecked(true);
                sessionManager.saveCondition(getCondition_id);

            }
            else {
                holder.cb_condition.setChecked(false);
            }

            /*if(condition_id!=null){
                if(condition_id.equals(myListData.getId().toString()))
                    holder.cb_condition.setChecked(true);
                else
                    holder.cb_condition.setChecked(false);
            }*/
            holder.cb_condition.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
//                        sessionManager.saveCondition(myListData.getId());
                        getCondition_id=myListData.getId();
                        notifyDataSetChanged();
                    }
                }
            });
        }

        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {
            TextView txt_colorname;
            CheckBox cb_condition;
            public ViewHolder(View itemView) {
                super(itemView);

                txt_colorname = itemView.findViewById(R.id.txt_title);
                cb_condition = itemView.findViewById(R.id.cb_condition);
            }
        }
    }


}