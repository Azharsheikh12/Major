package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.cw.balukibazaar.Adapter.NotificationListAdapter;
import com.cw.balukibazaar.R;

import java.util.ArrayList;

public class NotificationFragment extends Fragment {

    ImageView img_back;
    Activity context;
    RecyclerView listevent;
    NotificationListAdapter MyListAdapter;
//    ArrayList<String> notificationArrayList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
    View v =  inflater.inflate(R.layout.fragment_notification, container, false);
    InitView(v);
    Click();

        MyListAdapter = new NotificationListAdapter(context);
        listevent.setHasFixedSize(true);
        listevent.setLayoutManager(new LinearLayoutManager(context));
        listevent.setAdapter(MyListAdapter);
    return v;
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                context.onBackPressed();
            }
        });
    }

    private void InitView(View v) {
        context = getActivity();
        img_back = v.findViewById(R.id.img_back);
        listevent = v.findViewById(R.id.listevent);
    }
}