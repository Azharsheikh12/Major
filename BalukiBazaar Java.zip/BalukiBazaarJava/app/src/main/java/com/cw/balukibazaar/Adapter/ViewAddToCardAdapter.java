package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.ProductDetailActivity;
import com.cw.balukibazaar.ModelClass.ProductDetailData;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ViewAddToCardAdapter extends RecyclerView.Adapter<ViewAddToCardAdapter.ViewHolder> {
    private List<ProductDetailData> stList;
    private Context context;

    public ViewAddToCardAdapter(Context context, List<ProductDetailData> students) {
        this.stList = students;
        this.context = context;

    }
    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_your_orders_item, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        Picasso.get().load(Allurls.ImageURL +stList.get(position).getImages().get(0).getPath()).error(R.drawable.progress_animation).placeholder( R.drawable.progress_animation ).into(viewHolder.iv_image);

        viewHolder.layout_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent  =new Intent(context, ProductDetailActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("pro_id",stList.get(position).getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
//        return size;
        return stList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_image;
        LinearLayout layout_product;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            iv_image = itemLayoutView.findViewById(R.id.iv_image);
            layout_product = itemLayoutView.findViewById(R.id.layout_product);
        }

    }

    public List<ProductDetailData> getStudentist() {
        return stList;
    }
}

