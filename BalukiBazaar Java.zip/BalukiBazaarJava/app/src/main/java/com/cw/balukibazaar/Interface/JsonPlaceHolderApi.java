package com.cw.balukibazaar.Interface;

import com.cw.balukibazaar.ModelClass.AddInterstedResponse;
import com.cw.balukibazaar.ModelClass.AddOrderParameter;
import com.cw.balukibazaar.ModelClass.AddOrderResponse;
import com.cw.balukibazaar.ModelClass.AddProductResponse;
import com.cw.balukibazaar.ModelClass.AddReviewResponse;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.DiscountListUpdateResponse;
import com.cw.balukibazaar.ModelClass.GlobalBrandResponse;
import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.ModelClass.GlobalCategoryResponse;
import com.cw.balukibazaar.ModelClass.GlobalColorResponse;
import com.cw.balukibazaar.ModelClass.GlobalConditionResponse;
import com.cw.balukibazaar.ModelClass.GlobalSizeResponse;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.LoginResponse;
import com.cw.balukibazaar.ModelClass.MyOrderResponse;
import com.cw.balukibazaar.ModelClass.MyWalletResponse;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.ModelClass.SearchDataResponse;
import com.cw.balukibazaar.ModelClass.ShippingResponse;
import com.cw.balukibazaar.ModelClass.ShippingStatusResponse;
import com.cw.balukibazaar.ModelClass.SignupResponse;
import com.cw.balukibazaar.ModelClass.SocialLoginResponse;
import com.cw.balukibazaar.ModelClass.ViewChatDetailResponse;
import com.cw.balukibazaar.ModelClass.ViewChatListResponse;
import com.cw.balukibazaar.ModelClass.ViewDiscountListResponse;
import com.cw.balukibazaar.ModelClass.ViewFeatureInfoResponse;
import com.cw.balukibazaar.ModelClass.ViewHelpAndPrivacyResponse;
import com.cw.balukibazaar.ModelClass.ViewInterestedDataResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileResponse;
import com.cw.balukibazaar.ModelClass.WalletPaymentResponse;
import com.cw.balukibazaar.ModelClass.editprofile.EditProfileResponse;
import com.cw.balukibazaar.ModelClass.favourate.FavouriteResponse;
import com.cw.balukibazaar.ModelClass.profileshow.ProfileShowResponse;

import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;

public interface JsonPlaceHolderApi {

    // For Demo Purpose
    /*
    @GET("property_list")
    Call<List<PropertListReponse>> getListproperty();

    @FormUrlEncoded
    @POST("signup")
    Call<SignupResponse> signup(@Field("user_id") String user_id, @Field("name") String name,
                                @Field("email") String email, @Field("mobile") String mobile,
                                @Field("property_ids") String property_ids,
                                @Field("block_unit_id") String block_unit_id,
                                @Field("password") String password);

     */
    @FormUrlEncoded
    @POST("login")
    Call<LoginResponse> login(@Field("email") String email,
                               @Field("fcm_token") String fcm_token,
                               @Field("password") String password);

    @FormUrlEncoded
    @POST("social_login")
    Call<SocialLoginResponse> sociallogin(@Field("oauth_id") String oauth_id,
                                          @Field("oauth_provider") String oauth_provider,
                                          @Field("device_type") String device_type,
                                          @Field("fcm_token") String fcm_token,
                                          @Field("name") String name,
                                          @Field("email") String email,
                                          @Field("phone") String phone,
                                          @Field("gender") String gender,
                                          @Field("image") String image);


    @FormUrlEncoded
    @POST("homepage")
    Call<HomeResponse> gethomedata(@Field("user_id") String user_id);


    @FormUrlEncoded
    @POST("productdetail")
    Call<ProductDetailResponse> getproductdetaildata(@Field("user_id") String user_id,
                                                     @Field("product_id") String product_id);

    @FormUrlEncoded
    @POST("product_img_delete")
    Call<Add_Remove_Fav_Response> removeproductimage(@Field("user_id") String user_id,
                                                     @Field("product_id") String product_id,
                                                     @Field("image_id") String image_id);
    @FormUrlEncoded
    @POST("showprofile")
    Call<ViewProfileResponse> getprofiledata(@Field("user_id") String user_id, @Field("seller_id") String seller_id);

    @FormUrlEncoded
    @POST("discount_list")
    Call<ViewDiscountListResponse> getdiscountlist(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("discount_onoff")
    Call<Add_Remove_Fav_Response> updatediscountstatus(@Field("user_id") String user_id,@Field("action") String action);


    @FormUrlEncoded
    @POST("update_discount")
    Call<DiscountListUpdateResponse> updatediscountlist(@Field("user_id") String user_id,
                                                        @Field("discount_id") String discount_id,
                                                        @Field("no_of_item") String no_of_item
                                                        ,@Field("percentage") String percentage);
    @FormUrlEncoded
    @POST("showprofile")
    Call<ProfileShowResponse> getprofile(@Field("user_id") String user_id, @Field("seller_id") String seller_id);

    @FormUrlEncoded
    @POST("add_remove_favorite")
    Call<Add_Remove_Fav_Response> addremovefavourite(@Field("user_id") String user_id,
                                                       @Field("product_id") String product_id);
    @Multipart
    @POST("profile_update")
    Call<EditProfileResponse> updateProfile(@PartMap Map<String, RequestBody> data, @Part MultipartBody.Part image);
    @FormUrlEncoded
    @POST("myfavorite")
    Call<FavouriteResponse> favouritelist(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("forgot_password")
    Call<Add_Remove_Fav_Response> forgotpassword(@Field("email") String email);

    @FormUrlEncoded
    @POST("register")
    Call<SignupResponse> signup(@Field("name") String name,@Field("email") String email,
                               @Field("fcm_token") String fcm_token,
                               @Field("password") String password,
                                @Field("sellername") String sellername);

    @FormUrlEncoded
    @POST("sizeslist")
    Call<GlobalSizeResponse> getsizelist(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("add_remove_follow")
    Call<Add_Remove_Fav_Response> addremovefollowuser(@Field("user_id") String user_id,
                                                      @Field("following_id") String following_id);

    @FormUrlEncoded
    @POST("brandlist")
    Call<GlobalBrandResponse> getbrandlist(@Field("user_id") String user_id);


    @FormUrlEncoded
    @POST("add_interest")
    Call<AddInterstedResponse> addinteresteddata(@Field("user_id") String user_id,
                                                 @Field("type") String type,
                                                 @Field("interest_id") String interest_id);

    @FormUrlEncoded
    @POST("conditionlist")
    Call<GlobalConditionResponse> getconditionlist(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("colorlist")
    Call<GlobalColorResponse> getcolorlist(@Field("user_id") String user_id);

    @GET("categorylist")
    Call<GlobalCategoryResponse> getcategorylist();

  /*  @POST("productadd")
    Call<AddProductResponse>add_product(@Body RequestBody file);*/

   /* @Multipart
    @POST("productadd")
    Call<AddProductResponse>add_product(@Body RequestBody file, @Part List<MultipartBody.Part> photos);
*/
    @Multipart
    @POST("productadd")
    Call<AddProductResponse>add_product(@PartMap Map<String, RequestBody> data, @Part List<MultipartBody.Part> photos);

    @FormUrlEncoded
    @POST("shippinglist")
    Call<ShippingResponse> shippinglist(@Field("user_id") String user_id,
                                        @Field("seller_id") String seller_id,
                                        @Field("action") String action);

    @FormUrlEncoded
    @POST("feature_plan")
    Call<ViewFeatureInfoResponse> viewfeatureplan(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("add_feature_product")
    Call<Add_Remove_Fav_Response> addfeatureproduct(@Field("user_id") String user_id,
                                        @Field("product_id") String product_id,
                                        @Field("payment_method") String payment_method);

    @POST("addorder")
    Call<AddOrderResponse> addorderproduct(@Body AddOrderParameter signupParameter);

    @FormUrlEncoded
    @POST("productlist")
    Call<SearchDataResponse> viewsearchdata(@Field("user_id") String user_id,
                                            @Field("searchkey") String searchkey);

    @FormUrlEncoded
    @POST("chatlist")
    Call<ViewChatListResponse> viewchatdata(@Field("user_id") String user_id);

    @FormUrlEncoded
    @POST("myorders")
    Call<MyOrderResponse> viewmyorderlist(@Field("user_id") String user_id,
                                          @Field("type") String type);

    @FormUrlEncoded
    @POST("chat")
    Call<Add_Remove_Fav_Response> sendchatmessage(@Field("sender_id") String sender_id,
                                                 @Field("receiver_id") String receiver_id,
                                                 @Field("msg") String msg,
                                                 @Field("product_id") String product_id);

    @FormUrlEncoded
    @POST("chatdata")
    Call<ViewChatDetailResponse> viewchatdetail(@Field("chat_id") String chat_id,
                                                @Field("sender_id") String sender_id,
                                                @Field("receiver_id") String receiver_id);

    @FormUrlEncoded
    @POST("help_privacy")
    Call<ViewHelpAndPrivacyResponse> viewhelpprivacydata(@Field("page") String page);


    @FormUrlEncoded
    @POST("reviewadd")
    Call<AddReviewResponse> addreviewdata(@Field("user_id") String user_id,
                                          @Field("product_id") String product_id,
                                          @Field("rating") String rating,
                                          @Field("review") String review);

    @FormUrlEncoded
    @POST("filter")
    Call<SearchDataResponse> filtersearchdata(@Field("user_id") String user_id,
                                            @Field("category_id") String category_id,
                                            @Field("brand") String brand,
                                              @Field("size") String size,
                                              @Field("color") String color,
                                              @Field("condition") String condition,
                                              @Field("min_price") String min_price,
                                              @Field("max_price") String max_price);


    @FormUrlEncoded
    @POST("makepaymentnew")
    Call<WalletPaymentResponse> walletpayment(@Field("user_id") String user_id,
                                                 @Field("order_id") String order_id,
                                                 @Field("source") String source,
                                                 @Field("payment_method") String payment_method);



    @FormUrlEncoded
    @POST("interested_list")
    Call<ViewInterestedDataResponse> viewintresteddata(@Field("user_id") String user_id,
                                                       @Field("type") String type);

    @FormUrlEncoded
    @POST("mywallet")
    Call<MyWalletResponse> viewwalletdata(@Field("user_id") String user_id);

    @Multipart
    @POST("filter")
    Call<SearchDataResponse> sortsearchdata( @PartMap Map<String, RequestBody> data);


    @FormUrlEncoded
    @POST("shipping_onoff")
    Call<ShippingStatusResponse> shippingonoff(@Field("user_id") String user_id,
                                               @Field("shipping_id") String shipping_id,
                                               @Field("action") String action);

}
