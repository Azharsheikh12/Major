package com.cw.balukibazaar.Interface;

public interface PriceFilter {
    void getprices(String minimum, String maximum);
}
