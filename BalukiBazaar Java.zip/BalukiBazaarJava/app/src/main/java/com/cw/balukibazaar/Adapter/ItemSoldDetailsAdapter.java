package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.ProductDetailActivity;
import com.cw.balukibazaar.Fragment.PurchasedItemDetailsFragment;
import com.cw.balukibazaar.Fragment.SoldItemDetailFragment;
import com.cw.balukibazaar.ModelClass.MyOrderDetail;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ItemSoldDetailsAdapter extends RecyclerView.Adapter<ItemSoldDetailsAdapter.ViewHolder> {
    private List<MyOrderDetail> data;
    private Context context;
    Fragment fragment;

    public ItemSoldDetailsAdapter(Context context, List<MyOrderDetail> detail) {
        this.context = context;
        this.data = detail;
    }

    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_items_sold_details, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemLayoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

        viewHolder.txt_pro_name.setText(data.get(position).getProductName());
        viewHolder.txt_pro_add.setText(data.get(position).getPrice());
        Picasso.get().load(Allurls.ImageURL+data.get(position).getImage()).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(viewHolder.iv_profile);

        viewHolder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("data", data.get(position));
                AppCompatActivity activity = (AppCompatActivity) context;
                SoldItemDetailFragment newFragment = new SoldItemDetailFragment();
                newFragment.setArguments(bundle);
                FragmentTransaction transaction =  activity.getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, newFragment);
                transaction.addToBackStack("add");
                transaction.commit();
            }
        });
    }

    // Return the size arraylist
    @Override
    public int getItemCount() {
//        return 10;
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_pro_add, txt_pro_name;
        public LinearLayout ll_main;
        public ImageView iv_profile;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_pro_add = itemLayoutView.findViewById(R.id.txt_pro_add);
            txt_pro_name = itemLayoutView.findViewById(R.id.txt_pro_name);
            iv_profile = itemLayoutView.findViewById(R.id.iv_profile);
            ll_main = itemLayoutView.findViewById(R.id.ll_main);


        }

    }


}

