package com.cw.balukibazaar.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MyDialogSliderAdapter extends RecyclerView.Adapter<MyDialogSliderAdapter.ViewHolder> {
    private List<ProductDetailImage> mySliderLists;
    private LayoutInflater mInflater;
    Context context;


    public MyDialogSliderAdapter(Context context, List<ProductDetailImage> mySliderLists) {

        this.mInflater = LayoutInflater.from(context);
        this.mySliderLists = mySliderLists;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.dialog_slider_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final ProductDetailImage ob = mySliderLists.get(position);

        String s_image = ob.getPath();

        Picasso.get().load(Allurls.ImageURL + s_image).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(holder.myimage);

    }

    @Override
    public int getItemCount() {
        return mySliderLists.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView myimage;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myimage = itemView.findViewById(R.id.myimage);
        }
    }
}

