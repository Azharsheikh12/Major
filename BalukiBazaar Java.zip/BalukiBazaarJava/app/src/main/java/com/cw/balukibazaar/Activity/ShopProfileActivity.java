package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.MyAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileData;
import com.cw.balukibazaar.ModelClass.ViewProfileResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.facebook.login.Login;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShopProfileActivity extends AppCompatActivity {

    TabLayout tabs;
    ViewPager view_pager;
    TextView tv_name,txt_username,txt_reviewcou,txt_address,txt_post,txt_follerers,txt_following,txt_follow;
    SessionManager sessionManager;
    LinearLayout layout_follow,layout_msg;
    ImageView img_back;
    String user_id,seller_id;
    Activity activity;
    private JsonPlaceHolderApi mAPIService;
    CircleImageView img_profile;
    RatingBar rb_count;
    ViewProfileData viewProfileData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_profile);
        InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                user_id = intent.getStringExtra("user_id");
                seller_id = intent.getStringExtra("seller_id");

                System.out.println("shop user id >>>>>>>>"+sessionManager.getSavedUserid());
                System.out.println("shop seller id >>>>>>>>"+seller_id);

                if (sessionManager.getSavedUserid().equals(seller_id))
                {
                    layout_msg.setVisibility(View.INVISIBLE);
                    layout_follow.setVisibility(View.INVISIBLE);
                }
                else {
                    layout_msg.setVisibility(View.VISIBLE);
                    layout_follow.setVisibility(View.VISIBLE);
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        if(Utils.isInternetConnected(activity)) {

            try {
                sendPost(user_id,seller_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }

        Click();

    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        view_pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabs));

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                view_pager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        txt_follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Utils.isInternetConnected(activity)) {

                    try {
                        sendPostAddFollow(user_id,seller_id);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                }
            }
        });
    }

    private void InitView() {
        activity = ShopProfileActivity.this;
        sessionManager = new SessionManager(activity);
        mAPIService = ApiUtils.getAPIService();
        tabs = findViewById(R.id.tabs);
        img_back = findViewById(R.id.img_back);
        view_pager = findViewById(R.id.view_pager);
        tv_name = findViewById(R.id.tv_name);
        txt_username = findViewById(R.id.txt_username);
        img_profile = findViewById(R.id.img_profile);
        rb_count = findViewById(R.id.rb_count);
        txt_reviewcou = findViewById(R.id.txt_reviewcou);
        txt_address = findViewById(R.id.txt_address);
        txt_post = findViewById(R.id.txt_post);
        txt_follerers = findViewById(R.id.txt_follerers);
        txt_following = findViewById(R.id.txt_following);
        txt_follow = findViewById(R.id.txt_follow);
        layout_follow = findViewById(R.id.layout_follow);
        layout_msg = findViewById(R.id.layout_msg);
    }

    public void sendPost(String user_id,String seller_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.getprofiledata(user_id,seller_id).enqueue(new Callback<ViewProfileResponse>() {
            @Override
            public void onResponse(Call<ViewProfileResponse> call, Response<ViewProfileResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        viewProfileData = response.body().getData();

                        Picasso.get().load(Allurls.ImageURL+response.body().getData().getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(img_profile);
                        txt_username.setText(response.body().getData().getName());
                        txt_reviewcou.setText(response.body().getData().getReviewcount()+" Reviews");
                        rb_count.setRating(Float.parseFloat(response.body().getData().getRating()));
                        txt_address.setText(response.body().getData().getStreet());
                        txt_post.setText(response.body().getData().getPosts());
                        txt_follerers.setText(response.body().getData().getFollowers());
                        txt_following.setText(response.body().getData().getFollowing());


                        tabs.addTab(tabs.newTab().setText(getResources().getString(R.string.shop)));
                        tabs.addTab(tabs.newTab().setText(getResources().getString(R.string.reviews)));
                        tabs.addTab(tabs.newTab().setText(getResources().getString(R.string.about)));
                        tabs.setTabGravity(TabLayout.GRAVITY_FILL);
                        final MyAdapter adapter = new MyAdapter(activity,getSupportFragmentManager(), tabs.getTabCount(),viewProfileData,seller_id,user_id);
                        view_pager.setAdapter(adapter);


                        if (response.body().getData().getIsFollow().equals("0"))
                        {
                            txt_follow.setText(getResources().getString(R.string.follow));
                            txt_follow.setBackground(getResources().getDrawable(R.drawable.shape_yellow));

                        }
                        else {
                            txt_follow.setText(getResources().getString(R.string.following));
                            txt_follow.setBackground(getResources().getDrawable(R.drawable.shape_gray_light));
                        }
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewProfileResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostAddFollow(String user_id,String seller_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.addremovefollowuser(user_id,seller_id).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                       /* txt_follow.setText(getResources().getString(R.string.following));
                        txt_follow.setBackground(getResources().getDrawable(R.drawable.shape_gray_light));*/
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

}