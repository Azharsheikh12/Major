package com.cw.balukibazaar.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.List;

public class MySliderAdapter extends RecyclerView.Adapter<MySliderAdapter.ViewHolder> {
    private List<ProductDetailImage> mySliderLists;
    private LayoutInflater mInflater;
    private ViewPager2 viewPager;
    Context context;
    int currentPage = 0;
    int NUM_PAGES ;
    MyDialogSliderAdapter adapter;

    public MySliderAdapter(Context context, List<ProductDetailImage> mySliderLists, ViewPager2 viewPager) {
        this.mInflater = LayoutInflater.from(context);
        this.mySliderLists = mySliderLists;
        this.viewPager = viewPager;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.slider_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final ProductDetailImage ob = mySliderLists.get(position);

        String s_image = ob.getPath();

        Picasso.get().load(Allurls.ImageURL+s_image).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(holder.myimage);


        holder.myimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("position >>>>>>>>"+position);
                createDialogImaegView(context,Allurls.ImageURL+s_image,mySliderLists,position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mySliderLists.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        RoundRectCornerImageView myimage;

              public ViewHolder(@NonNull View itemView) {
            super(itemView);
            myimage = itemView.findViewById(R.id.myimage);

        }
    }

    public void createDialogImaegView(Context context, String imageurl, List<ProductDetailImage> mySliderLists, int position)
    {
        final Dialog dialog = new Dialog(context);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_images);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;

        ViewPager2 viewPager = dialog.findViewById(R.id.dialog_viewPager);
        LinearLayout layout_cancel = dialog.findViewById(R.id.layout_cancel);

        SetSliderData(mySliderLists,viewPager,position);

        layout_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
    public void SetSliderData(List<ProductDetailImage> mySliderLists, ViewPager2 viewPager, int position)
    {
        try {

            System.out.println("dialog position >>>>>>>>"+position);
            adapter = new MyDialogSliderAdapter(context,mySliderLists);
            viewPager.setAdapter(adapter);
            viewPager.setCurrentItem(position);

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

