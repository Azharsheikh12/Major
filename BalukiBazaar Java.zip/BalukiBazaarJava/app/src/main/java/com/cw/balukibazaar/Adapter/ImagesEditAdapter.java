package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.UpdateProductActivity;
import com.cw.balukibazaar.Fragment.AddItemFragment;
import com.cw.balukibazaar.Interface.ProductImagesDelete;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ImagesEditAdapter extends RecyclerView.Adapter<ImagesEditAdapter.ViewHolder> {
    private List<ProductDetailImage> data;
    private Context context;
    ProductImagesDelete productImagesDelete;
    public ImagesEditAdapter(Context context, List<ProductDetailImage> students, ProductImagesDelete productImagesDelete) {
        this.data = students;
        this.context = context;
        this.productImagesDelete = productImagesDelete;

    }
    @Override
    public ImagesEditAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_single, parent, false);

        ImagesEditAdapter.ViewHolder viewHolder = new ImagesEditAdapter.ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ImagesEditAdapter.ViewHolder viewHolder, final int position) {

        Picasso.get().load(Allurls.ImageURL+data.get(position).getPath()).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(viewHolder.grid_image);

        viewHolder.imgcross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              /*  System.out.println("position >>>>>>>>>>>"+position);
                files.remove(position);
                System.out.println("web list >>>>>>>>>>>"+files);
//                        web.notifyAll();

                adapter = new AddItemFragment.ImagesAdapter(getActivity(), files);
                grid.setAdapter(adapter);
                adapter.notifyDataSetChanged();*/
              productImagesDelete.getProductImageId(data.get(position).getId());
            }
        });


    }
    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imgcross;
        public CircleImageView grid_image;

        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            imgcross = itemLayoutView.findViewById(R.id.imgcross);
            grid_image = itemLayoutView.findViewById(R.id.grid_image);
        }
    }
    public List<ProductDetailImage> getStudentist() {
        return data;
    }

}
