package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.MonthSubMain;
import com.cw.balukibazaar.R;

import java.util.ArrayList;


public class MysubListAdapter extends RecyclerView.Adapter<MysubListAdapter.ViewHolder> {
    /* List<GetWalletTransaction> eventMainModelClasses;*/
    ArrayList<MonthSubMain> submains;

    Context context;

    // RecyclerView recyclerView;
    public MysubListAdapter(Context context, ArrayList<MonthSubMain> submains) {
        this.context = context;
        this.submains = submains;
    }

    @Override
    public MysubListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.row_contestsublist_upcoimg, parent, false);
        MysubListAdapter.ViewHolder viewHolder = new MysubListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MysubListAdapter.ViewHolder holder, int position) {
        // GetWalletTransaction myListData = eventMainModelClasses.get(position);

        try {

            holder.txt_date.setText(submains.get(position).getDate());
//                holder.txt_proname.setText(eventMainModelClasses.get(position).getProname());
            holder.txt_title.setText(submains.get(position).getProname());
            holder.txt_proprice.setText("€ " + submains.get(position).getProprice());


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {

        return 5;
        //return eventMainModelClasses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_title, txt_proname, txt_proprice, txt_date;

        public ViewHolder(View itemView) {
            super(itemView);
            txt_title = (TextView) itemView.findViewById(R.id.txt_title);
            txt_proname = (TextView) itemView.findViewById(R.id.txt_proname);
            txt_proprice = (TextView) itemView.findViewById(R.id.txt_proprice);
            txt_date = (TextView) itemView.findViewById(R.id.txt_date);

        }
    }
}
