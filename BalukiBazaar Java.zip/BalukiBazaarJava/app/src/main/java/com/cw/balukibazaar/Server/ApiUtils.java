package com.cw.balukibazaar.Server;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;

public class ApiUtils {

    private ApiUtils() {}

    public static final String BASE_URL = Allurls.MainURL;

    public static JsonPlaceHolderApi getAPIService() {

        return RetrofitClient.getClient(BASE_URL).create(JsonPlaceHolderApi.class);
    }
}
