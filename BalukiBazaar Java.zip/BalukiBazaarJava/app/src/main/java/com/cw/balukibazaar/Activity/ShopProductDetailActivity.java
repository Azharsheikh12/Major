package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.MySliderAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShopProductDetailActivity extends AppCompatActivity {

    ImageView img_back,img_edit;
    String pro_id,user_id;
    Context context;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    CircleImageView img_seller;
    TextView txt_sellername,txt_likes,tv_iv_count,txt_itemname,tv_item_desc,tv_condition,txt_brand,txt_price,txt_size,txt_colorname;
    ViewPager2 viewPager;
    private static int currentPage = 0;
    private static int NUM_PAGES ;
    MySliderAdapter adapter;
    String seller_id;
    Button btn_listitem,btn_savedraf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_product_detail);
        InitView();
        Click();
        try {
            Intent intent  = getIntent();
            if (intent!=null)
            {
                pro_id = intent.getStringExtra("pro_id");
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        if (sessionManager.isUserLogin())
        {
            user_id = sessionManager.getSavedUserid();
        }
        else {
            user_id = "0";
        }

        if(Utils.isInternetConnected(context)) {

            try {
                sendPost(user_id,pro_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }

    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        img_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent  = new Intent(context,UpdateProductActivity.class);
                intent.putExtra("pro_id",pro_id);
                intent.putExtra("user_id",user_id);
                startActivity(intent);
            }
        });
    }

    private void InitView() {
        context = ShopProductDetailActivity.this;
        sessionManager = new SessionManager(context);
        img_back = findViewById(R.id.img_back);
        mAPIService = ApiUtils.getAPIService();
        img_seller = findViewById(R.id.img_seller);
        txt_sellername = findViewById(R.id.txt_sellername);
        viewPager = findViewById(R.id.viewPager);
        tv_iv_count = findViewById(R.id.tv_iv_count);
        txt_itemname = findViewById(R.id.txt_itemname);
        tv_item_desc = findViewById(R.id.tv_item_desc);
        tv_condition = findViewById(R.id.tv_condition);
        txt_brand = findViewById(R.id.txt_brand);
        txt_price = findViewById(R.id.txt_price);
        txt_size = findViewById(R.id.txt_size);
        txt_colorname = findViewById(R.id.txt_colorname);
        txt_likes = findViewById(R.id.txt_likes);
        img_edit = findViewById(R.id.img_edit);
        btn_listitem = findViewById(R.id.btn_listitem);
        btn_savedraf = findViewById(R.id.btn_savedraf);
        img_edit = findViewById(R.id.img_edit);
    }

    public void sendPost(String user_id,String pro_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.getproductdetaildata(user_id,pro_id).enqueue(new Callback<ProductDetailResponse>() {
            @Override
            public void onResponse(Call<ProductDetailResponse> call, Response<ProductDetailResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        seller_id = response.body().getData().getSellerdata().getId();
                        CheckSelleridandUserid(seller_id);

                        Picasso.get().load(Allurls.ImageURL+response.body().getData().getSellerdata().getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(img_seller);
                        txt_sellername.setText(response.body().getData().getSellerdata().getName());
                        SetSliderData(response.body().getData().getImages());
                        txt_itemname.setText(response.body().getData().getName());
                        tv_item_desc.setText(response.body().getData().getDescription());
                        tv_condition.setText(response.body().getData().getConditionname());
                        txt_brand.setText(response.body().getData().getBrandname());
                        txt_price.setText("€ "+response.body().getData().getPrice());

                        String size = "";
                        for (int i=0;i<response.body().getData().getSize().size();i++)
                        {
                            size = size+response.body().getData().getSize().get(i).getSize()+",";
                        }
                        txt_size.setText(RemoveLastStr(size));

                        String colorname ="";
                        for (int i=0;i<response.body().getData().getColor().size();i++)
                        {
                            colorname +=response.body().getData().getColor().get(i).getColor()+",";
                        }
                        txt_colorname.setText(RemoveLastStr(colorname));
                        txt_likes.setText(response.body().getData().getLikes());


                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProductDetailResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    private void CheckSelleridandUserid(String seller_id) {
        if (seller_id.equals(sessionManager.getSavedUserid()))
        {
            img_edit.setVisibility(View.VISIBLE);
        }
        else {
            img_edit.setVisibility(View.INVISIBLE);
        }
    }

    public String RemoveLastStr(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }
    public void SetSliderData(List<ProductDetailImage> images)
    {
        try {

//            NUM_PAGES = 3;
            NUM_PAGES = images.size();
            /*if(NUM_PAGES==1){
                tv_iv_count.setText("1/1");
            }*/
            viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
//                    setupCurrentIndicator(position);
                    Log.e("Selected_Page", String.valueOf(position));
                    tv_iv_count.setText("" + String.valueOf(position+1) + "/" + NUM_PAGES);

                }
            });
            final Handler handler = new Handler();
            final Runnable Update = new Runnable() {
                public void run() {
                    if (currentPage == NUM_PAGES) {
                        currentPage = 0;
                    }
                    viewPager.setCurrentItem(currentPage++, true);
                }
            };
            Timer swipeTimer = new Timer();
            swipeTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    handler.post(Update);
                }
            }, 3000, 3000);


            adapter=new MySliderAdapter(context,images,viewPager);
            viewPager.setAdapter(adapter);

        }catch (Exception e)
        {
            e.printStackTrace();
        }


    }

}