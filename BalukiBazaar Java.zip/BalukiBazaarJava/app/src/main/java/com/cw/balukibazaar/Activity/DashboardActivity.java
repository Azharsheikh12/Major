package com.cw.balukibazaar.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.cw.balukibazaar.Fragment.AddItemFragment;
import com.cw.balukibazaar.Fragment.ChatFragment;
import com.cw.balukibazaar.Fragment.EditProfileFragment;
import com.cw.balukibazaar.Fragment.HomeFragment;
import com.cw.balukibazaar.Fragment.ProfileFragment;
import com.cw.balukibazaar.Fragment.SearchFragment;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.BottomNavigationViewHelper;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;

public class DashboardActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    BottomNavigationView bottomNavigationView;
    Fragment fragment = null;
    ImageView iv_add;
    SessionManager sessionManager;
    String aboutvalue="0" ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        InitView();
        Click();

        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                aboutvalue = intent.getStringExtra("about");
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        if (aboutvalue.equals("1"))
        {
            fragment = new EditProfileFragment();
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
        }
        else {
            fragment = new HomeFragment();
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
        }


        bottomNavigationView.setBackground(null);
        bottomNavigationView.getMenu().getItem(2).setEnabled(false);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
        bottomNavigationView.setLabelVisibilityMode(LabelVisibilityMode.LABEL_VISIBILITY_LABELED);

    }

    private void Click() {
        iv_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sessionManager.isUserLogin())
                {
                    fragment = new AddItemFragment();
                    loadFragment(fragment);
                }
                else {
                    Intent intent = new Intent(DashboardActivity.this,FirstLoginActivity.class);
                    startActivity(intent);
                }

            }
        });


    }

    private void InitView() {
        sessionManager = new SessionManager(DashboardActivity.this);
        bottomNavigationView = findViewById(R.id.navigation);
        iv_add = findViewById(R.id.iv_add);
    }
    @SuppressLint("NewApi")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        int previousItem = bottomNavigationView.getSelectedItemId();

        System.out.println("previousItem >>>>>>>>"+previousItem);
        int id=item.getItemId();

        if (previousItem!=id)
        {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    fragment = new HomeFragment();
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.fragment_container, fragment)
                            .commit();
                    return true;

                case R.id.navigation_search:
                    fragment = new SearchFragment();
                    loadFragment(fragment);

                    break;

                case R.id.navigation_middle:

                    break;

                case R.id.navigation_inbox:
                    fragment = new ChatFragment();
                    loadFragment(fragment);

                    break;
                case R.id.navigation_profile:
                    fragment = new ProfileFragment();
                    loadFragment(fragment);

                    break;
            }
        }

        return true;
    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {

            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

}