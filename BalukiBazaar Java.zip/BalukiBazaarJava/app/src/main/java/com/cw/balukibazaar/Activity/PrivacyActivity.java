package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.ViewHelpAndPrivacyResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PrivacyActivity extends AppCompatActivity {

    ImageView img_back;
    TextView txt_privacy;
    Context activity;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy);
        InitView();
        Click();
        if(Utils.isInternetConnected(activity)) {
            try {
                sendPost();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void InitView() {
        activity = PrivacyActivity.this;
        sessionManager = new SessionManager(activity);
        mAPIService = ApiUtils.getAPIService();
        img_back = findViewById(R.id.img_back);
        txt_privacy = findViewById(R.id.txt_privacy);
    }
    public void sendPost() throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);
        mAPIService.viewhelpprivacydata("privacy").enqueue(new Callback<ViewHelpAndPrivacyResponse>() {
            @Override
            public void onResponse(Call<ViewHelpAndPrivacyResponse> call, Response<ViewHelpAndPrivacyResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        txt_privacy.setText(Html.fromHtml(response.body().getData()));
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewHelpAndPrivacyResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

}