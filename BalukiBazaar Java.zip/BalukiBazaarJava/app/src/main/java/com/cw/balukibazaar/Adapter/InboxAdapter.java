package com.cw.balukibazaar.Adapter;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;


import com.cw.balukibazaar.Activity.MessageActivity;
import com.cw.balukibazaar.ModelClass.ThingsModel;
import com.cw.balukibazaar.ModelClass.ViewChatListData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public  class InboxAdapter extends RecyclerView.Adapter<InboxAdapter.ViewHolder>{
    List<ViewChatListData> eventMainModelClasses;
    private Context context;
    // RecyclerView recyclerView;
    public InboxAdapter(Context context, List<ViewChatListData> listdata) {
        this.eventMainModelClasses = listdata;
        this.context = context;
    }
    @Override
    public InboxAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.list_item_inbox, parent, false);
//        View listItem= layoutInflater.inflate(R.layout.custome_notification_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(InboxAdapter.ViewHolder holder, int position) {
        final ViewChatListData myListData = eventMainModelClasses.get(position);

        try{

            Picasso.get().load(Allurls.ImageURL+myListData.getSellerprofile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(holder.img_user_profile);
            holder.txt_username.setText(myListData.getSellername());

            holder.lay_linear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Toast.makeText(context, "Chat details", Toast.LENGTH_SHORT).show();
                   /* Intent intent = new Intent(context, MessageActivity.class);
                    context.startActivity(intent);*/
                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public int getItemCount() {
        return eventMainModelClasses.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_username;
        LinearLayout lay_linear;
        CircleImageView img_user_profile;
        public ViewHolder(View itemView) {
            super(itemView);

            img_user_profile =itemView.findViewById(R.id.img_user_profile);
            txt_username = itemView.findViewById(R.id.txt_username);
            lay_linear = itemView.findViewById(R.id.lay_linear);

        }
    }
}
