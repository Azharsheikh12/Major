
package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ViewProfileData implements Serializable {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("sellername")
    @Expose
    private String sellername;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("phone")
    @Expose
    private String phone;
    @SerializedName("profile")
    @Expose
    private String profile;
    @SerializedName("country")
    @Expose
    private String country;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("street")
    @Expose
    private String street;
    @SerializedName("zipcode")
    @Expose
    private String zipcode;
    @SerializedName("about")
    @Expose
    private String about;
    @SerializedName("wallet")
    @Expose
    private String wallet;
    @SerializedName("discount")
    @Expose
    private String discount;
    @SerializedName("fcm_token")
    @Expose
    private String fcmToken;
    @SerializedName("email_notification")
    @Expose
    private String emailNotification;
    @SerializedName("app_notification")
    @Expose
    private String appNotification;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("forget_pass_status")
    @Expose
    private String forgetPassStatus;
    @SerializedName("created_on")
    @Expose
    private String createdOn;
    @SerializedName("is_follow")
    @Expose
    private String isFollow;
    @SerializedName("posts")
    @Expose
    private String posts;
    @SerializedName("following")
    @Expose
    private String following;
    @SerializedName("followers")
    @Expose
    private String followers;
    @SerializedName("reviewcount")
    @Expose
    private String reviewcount;
    @SerializedName("rating")
    @Expose
    private String rating;
    @SerializedName("shop")
    @Expose
    private List<ViewProfileShop> shop = null;
    @SerializedName("review")
    @Expose
    private List<ViewProfileReview> review = null;
    @SerializedName("dis_percent")
    @Expose
    private String disPercent;
    @SerializedName("dis_id")
    @Expose
    private String disId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSellername() {
        return sellername;
    }

    public void setSellername(String sellername) {
        this.sellername = sellername;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getAbout() {
        return about;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public String getWallet() {
        return wallet;
    }

    public void setWallet(String wallet) {
        this.wallet = wallet;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public String getEmailNotification() {
        return emailNotification;
    }

    public void setEmailNotification(String emailNotification) {
        this.emailNotification = emailNotification;
    }

    public String getAppNotification() {
        return appNotification;
    }

    public void setAppNotification(String appNotification) {
        this.appNotification = appNotification;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getForgetPassStatus() {
        return forgetPassStatus;
    }

    public void setForgetPassStatus(String forgetPassStatus) {
        this.forgetPassStatus = forgetPassStatus;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getIsFollow() {
        return isFollow;
    }

    public void setIsFollow(String isFollow) {
        this.isFollow = isFollow;
    }

    public String getPosts() {
        return posts;
    }

    public void setPosts(String posts) {
        this.posts = posts;
    }

    public String getFollowing() {
        return following;
    }

    public void setFollowing(String following) {
        this.following = following;
    }

    public String getFollowers() {
        return followers;
    }

    public void setFollowers(String followers) {
        this.followers = followers;
    }

    public String getReviewcount() {
        return reviewcount;
    }

    public void setReviewcount(String reviewcount) {
        this.reviewcount = reviewcount;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public List<ViewProfileShop> getShop() {
        return shop;
    }

    public void setShop(List<ViewProfileShop> shop) {
        this.shop = shop;
    }

    public List<ViewProfileReview> getReview() {
        return review;
    }

    public void setReview(List<ViewProfileReview> review) {
        this.review = review;
    }

    public String getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(String disPercent) {
        this.disPercent = disPercent;
    }

    public String getDisId() {
        return disId;
    }

    public void setDisId(String disId) {
        this.disId = disId;
    }
}
