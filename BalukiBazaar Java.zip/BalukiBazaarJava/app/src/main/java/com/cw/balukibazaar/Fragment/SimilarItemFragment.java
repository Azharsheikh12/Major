package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.cw.balukibazaar.Adapter.ViewLatestAdapter;
import com.cw.balukibazaar.Adapter.ViewMoreSellerAdapter;
import com.cw.balukibazaar.Adapter.ViewSimilaryItemAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.HomeDataWeLove;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SimilarItemFragment extends Fragment {

    int category_id;

    Activity activity;
    RecyclerView recyclerViewProducts;
    private ViewSimilaryItemAdapter latestAdapter;
    String user_id,pro_id;
    private JsonPlaceHolderApi mAPIService;
    public SimilarItemFragment(String user_id, String pro_id) {
        this.pro_id = pro_id;
        this.user_id = user_id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v= inflater.inflate(R.layout.fragment_similar_item, container, false);
       InitView(v);
       Click();
        if(Utils.isInternetConnected(activity)) {

            try {
                sendPost(user_id,pro_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }

      /*  thingsList = new ArrayList<>();
        for (int i=0;i<6;i++)
        {
            HomeDataWeLove homeDataWeLove = new HomeDataWeLove("Leather shoes","it is good products","Crosstores","25.00","yes","");
            thingsList.add(homeDataWeLove);
        }
        recyclerViewProducts.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recyclerViewProducts.setHasFixedSize(true);
        latestAdapter = new ViewLatestAdapter(getActivity(),thingsList);
        recyclerViewProducts.setAdapter(latestAdapter);*/
        return v;
    }

    private void Click() {
    }

    private void InitView(View v) {
        activity = getActivity();
        mAPIService = ApiUtils.getAPIService();
        recyclerViewProducts = v.findViewById(R.id.recyclerViewProducts);
    }
    public void sendPost(String user_id,String pro_id) throws JSONException {
//        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.getproductdetaildata(user_id,pro_id).enqueue(new Callback<ProductDetailResponse>() {
            @Override
            public void onResponse(Call<ProductDetailResponse> call, Response<ProductDetailResponse> response) {

//                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        recyclerViewProducts.setLayoutManager(new GridLayoutManager(getActivity(),2));
                        recyclerViewProducts.setHasFixedSize(true);
                        latestAdapter = new ViewSimilaryItemAdapter(getActivity(),response.body().getData().getSimilaritems());
                        recyclerViewProducts.setAdapter(latestAdapter);
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProductDetailResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }
}