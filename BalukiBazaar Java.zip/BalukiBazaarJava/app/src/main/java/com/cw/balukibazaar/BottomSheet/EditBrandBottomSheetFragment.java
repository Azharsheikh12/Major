package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.GlobalBrandData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.List;


public class EditBrandBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    ImageView iv_close,iv_back;
    EditText edt_search;
    RecyclerView recycler_category;
    List<GlobalBrandData> categoriesList;
    CategorySubAdapter MyListAdapter;
    Context context;
    SessionManager sessionManager;
    String brand_id,getBrand_id;

    RelativeLayout rl_main;
    public EditBrandBottomSheetFragment(Context context, List<GlobalBrandData> brandList, String brand_id) {
        this.categoriesList = brandList;
        this.getBrand_id = brand_id;
        this.context = context;
    }


    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_brand, container, false);
        findIds(view);
        if(sessionManager.getBrand() !=null){
            brand_id=sessionManager.getBrand();
        }
        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_category.setHasFixedSize(true);
        recycler_category.setLayoutManager(new LinearLayoutManager(context));
        recycler_category.setAdapter(MyListAdapter);

        edt_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        return view;

    }
    private void filter(String text) {
        List<GlobalBrandData> filteredList = new ArrayList<>();
        for (GlobalBrandData item : categoriesList) {
            if (item.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        MyListAdapter.filterList(filteredList);
    }
    public void findIds(View v) {
        sessionManager = new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_category = v.findViewById(R.id.recycler_brand);
        edt_search = v.findViewById(R.id.edt_search);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
//                brand_id = "0";
                sessionManager.saveBrand(brand_id);
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                sessionManager.saveBrand(brand_id);
                dismissAllowingStateLoss();
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<GlobalBrandData> eventMainModelClasses;
        private Context context;
        public CategorySubAdapter(Context context, List<GlobalBrandData> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_brand_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final GlobalBrandData myListData = eventMainModelClasses.get(position);

            holder.txt_title.setText(categoriesList.get(position).getName());

            if (getBrand_id.equals(myListData.getId()))
            {
                holder.cb_brand.setChecked(true);
                sessionManager.saveBrand(getBrand_id);
            }
            else {
                holder.cb_brand.setChecked(false);
            }

           /* if(brand_id!=null){
                if(brand_id.equals(myListData.getId().toString()))
                    holder.cb_brand.setChecked(true);
                else
                    holder.cb_brand.setChecked(false);
            }*/
           /* holder.cb_brand.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
//                        sessionManager.saveBrand(myListData.getId());
//                        holder.cb_brand.setChecked(true);
                        getBrand_id=myListData.getId();
                        notifyDataSetChanged();
                    }
                }
            });*/
            holder.cb_brand.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

//                    sessionManager.setSavedCateId(categoriesList.get(position).getId());
//                    Log.i("cate id >",""+sessionManager.getSavedCateId());
                    getBrand_id = myListData.getId();
                    dismissAllowingStateLoss();
                    notifyDataSetChanged();
                }
            });
        }


        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {

            TextView txt_title;
            CheckBox cb_brand;

            public ViewHolder(View itemView) {
                super(itemView);

                txt_title = itemView.findViewById(R.id.txt_title);
                cb_brand = itemView.findViewById(R.id.cb_brand);
            }
        }
        public void filterList(List<GlobalBrandData> filteredList) {
            eventMainModelClasses = filteredList;
            notifyDataSetChanged();
        }
    }


}