package com.cw.balukibazaar.Interface;

import com.cw.balukibazaar.ModelClass.ViewProfileShop;

import java.util.List;

public interface ShopBundleData  {
    void getshopbundledata(String item_count, String total_price, String totaldiscount_price, List<ViewProfileShop> transferShopDataList);
}
