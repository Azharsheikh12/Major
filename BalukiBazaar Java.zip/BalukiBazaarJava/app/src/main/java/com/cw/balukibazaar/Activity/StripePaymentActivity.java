package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.cooltechworks.creditcarddesign.CardEditActivity;
import com.cooltechworks.creditcarddesign.CreditCardUtils;
import com.cooltechworks.creditcarddesign.CreditCardView;
import com.cw.balukibazaar.R;

public class StripePaymentActivity extends AppCompatActivity {

    ImageView img_back;
//    CreditCardView cardview_credit;
    Context context;


    private LinearLayout cardContainer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stripe_payment);
        InitView();
        initialize();
        Click();
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void InitView() {
        context = StripePaymentActivity.this;
        img_back = findViewById(R.id.img_back);
//        cardview_credit = findViewById(R.id.cardview_credit);
    }

    private void initialize() {
        cardContainer = findViewById(R.id.card_container);

//        populate();
    }

//    private void populate() {
//        CreditCardView sampleCreditCardView = new CreditCardView(this);
//
//        String name = "Glarence Zhao";
//        String cvv = "420";
//        String expiry = "01/18";
//        String cardNumber = "4242424242424242";
//
//        sampleCreditCardView.setCVV(cvv);
//        sampleCreditCardView.setCardHolderName(name);
//        sampleCreditCardView.setCardExpiry(expiry);
//        sampleCreditCardView.setCardNumber(cardNumber);
//
//        cardContainer.addView(sampleCreditCardView);
//        int index = cardContainer.getChildCount() - 1;
//        addCardListener(index, sampleCreditCardView);
//
//    }




}