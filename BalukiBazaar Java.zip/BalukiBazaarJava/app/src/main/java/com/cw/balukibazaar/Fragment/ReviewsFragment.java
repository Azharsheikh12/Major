package com.cw.balukibazaar.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cw.balukibazaar.Adapter.ViewReviewAdapter;
import com.cw.balukibazaar.Adapter.ViewShopsAdapter;
import com.cw.balukibazaar.ModelClass.ViewProfileReview;
import com.cw.balukibazaar.R;

import java.util.List;

public class ReviewsFragment extends Fragment {

    RecyclerView recyclerView;
    List<ViewProfileReview> review;
    private ViewReviewAdapter latestAdapter;

    public ReviewsFragment(List<ViewProfileReview> review) {
        this.review = review;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v = inflater.inflate(R.layout.fragment_reviews, container, false);
       InitView(v);
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1, GridLayoutManager.VERTICAL, false));
        recyclerView.setHasFixedSize(true);
        latestAdapter = new ViewReviewAdapter(getActivity(),review);
        recyclerView.setAdapter(latestAdapter);
       return v;
    }

    private void InitView(View v) {
        recyclerView = v.findViewById(R.id.recyclerView);
    }
}