package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.ViewShopBundleAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.ShopBundleData;
import com.cw.balukibazaar.ModelClass.ViewProfileResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.io.Serializable;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewShopBundleActivity extends AppCompatActivity {

    ImageView img_back;
    RecyclerView recyclerView;
    private ViewShopBundleAdapter latestAdapter;
      public  List<ViewProfileShop> transferShopDataListMain;
    String seller_id,user_id,totaldiscount_priceMain,total_priceMain;
    Context context;
    private JsonPlaceHolderApi mAPIService;
    TextView txt_itemcount,txt_totalprice,txt_total_disprice,txt_request;
    String itemcount="",discount_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_shop_bundle);
        InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                user_id = intent.getStringExtra("user_id");
                seller_id = intent.getStringExtra("seller_id");
                if(Utils.isInternetConnected(context)) {

                    try {
                        sendPost(user_id,seller_id);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        Click();

    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        txt_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("item count >>>>>>>>>>"+itemcount);
                if (itemcount.equals("") || itemcount.equals("0"))
                {
                    CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select_product));
                }
                else {
                    Intent intent = new Intent(context,ShopBundleOrderActivity.class);
                    intent.putExtra("shopdata", (Serializable) transferShopDataListMain);
                    intent.putExtra("totalproce",total_priceMain);
                    intent.putExtra("totaldiscount",totaldiscount_priceMain);
                    intent.putExtra("itemcount",itemcount);
                    intent.putExtra("seller_id",seller_id);
                    intent.putExtra("discount_id",discount_id);
                    startActivity(intent);
                }
            }
        });
    }

    private void InitView() {
        context = ViewShopBundleActivity.this;
        mAPIService = ApiUtils.getAPIService();
        img_back = findViewById(R.id.img_back);
        recyclerView = findViewById(R.id.recyclerView);
        txt_itemcount = findViewById(R.id.txt_itemcount);
        txt_totalprice = findViewById(R.id.txt_totalprice);
        txt_total_disprice = findViewById(R.id.txt_total_disprice);
        txt_request = findViewById(R.id.txt_request);
    }
    public void sendPost(String user_id,String seller_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.getprofiledata(user_id,seller_id).enqueue(new Callback<ViewProfileResponse>() {
            @Override
            public void onResponse(Call<ViewProfileResponse> call, Response<ViewProfileResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        for (int i=0;i<response.body().getData().getShop().size();i++)
                        {
                            ViewProfileShop viewProfileShop = new ViewProfileShop();
                            viewProfileShop.setSelected(false);
                        }
                        recyclerView.setLayoutManager(new GridLayoutManager(context, 2, GridLayoutManager.VERTICAL, false));
                        recyclerView.setHasFixedSize(true);
                        latestAdapter = new ViewShopBundleAdapter(context,response.body().getData().getShop(),response.body().getData(), new ShopBundleData() {
                            @Override
                            public void getshopbundledata(String item_count, String total_price, String totaldiscount_price, List<ViewProfileShop> transferShopDataList) {

                                totaldiscount_priceMain=totaldiscount_price;
                                total_priceMain = total_price;
                                transferShopDataListMain = transferShopDataList;
                                itemcount = item_count;
                                txt_itemcount.setText(item_count+" Items");
                                txt_totalprice.setText("€ "+total_price);
                                txt_total_disprice.setText("€ "+totaldiscount_price);

                                discount_id = response.body().getData().getDisId();
                            }
                        });
                        recyclerView.setAdapter(latestAdapter);

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewProfileResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

}