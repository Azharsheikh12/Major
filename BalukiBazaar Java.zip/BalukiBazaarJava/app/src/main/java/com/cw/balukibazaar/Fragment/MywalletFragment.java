package com.cw.balukibazaar.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Adapter.MyWalletAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.MonthNameMain;
import com.cw.balukibazaar.ModelClass.MonthSubMain;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import java.util.ArrayList;


public class MywalletFragment extends Fragment {

    ImageView iv_back,img_notification;
    RecyclerView listevent;
    ArrayList<MonthSubMain> monthSubMains ;
    ArrayList<MonthNameMain> monthNameMains ;
   MyWalletAdapter adaptercon;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    TextView txt_ava_amt,txt_pen_amt;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
      View v = inflater.inflate(R.layout.fragment_mywallet, container, false);
      InitView(v);
      Click();

        if(Utils.isInternetConnected(getActivity())) {

           // sendPost();
        }
        else {
            CustomAlertdialog.createDialog(getActivity(),getString(R.string.no_internet));
        }

      monthNameMains = new ArrayList<>();
      monthSubMains = new ArrayList<>();
      monthNameMains.clear();
      monthSubMains.clear();
      for (int i=0;i<4;i++)
      {
          for (int j=0;j<2;j++)
          {
              MonthSubMain monthSubMain = new MonthSubMain("Bank Account transfer","Bank Account","60.00","21/11/2020");
              monthSubMains.add(monthSubMain);
          }
          MonthNameMain monthNameMain = new MonthNameMain(false,"November",monthSubMains);
          monthNameMains.add(monthNameMain);
      }




        return v;
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                getActivity().finish();
                getActivity().onBackPressed();

            }
        });
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    private void InitView(View v) {
        sessionManager = new SessionManager(getActivity());
        mAPIService = ApiUtils.getAPIService();
        iv_back = v.findViewById(R.id.iv_back);
        listevent = v.findViewById(R.id.listevent);
        txt_ava_amt = v.findViewById(R.id.txt_ava_amt);
        txt_pen_amt = v.findViewById(R.id.txt_pen_amt);
        img_notification = v.findViewById(R.id.img_notification);

        adaptercon = new MyWalletAdapter(getActivity(),monthNameMains);
        listevent.setHasFixedSize(true);
        listevent.setLayoutManager(new LinearLayoutManager(getActivity()));
        listevent.setAdapter(adaptercon);

    }

    /*public  class MyListAdapter extends RecyclerView.Adapter<MyListAdapter.ViewHolder>{
        List<GetWalletTransactionData> eventMainModelClasses;

        // RecyclerView recyclerView;
        public MyListAdapter(List<GetWalletTransactionData> listdata) {
            this.eventMainModelClasses = listdata;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem= layoutInflater.inflate(R.layout.custome_creditlist_row, parent, false);
            ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ViewHolder  holder, int position) {
            final GetWalletTransactionData myListData = eventMainModelClasses.get(position);

            try{
                List<GetWalletTransaction> data= eventMainModelClasses.get(position).getTransaction();
                holder.txt_monname.setText(eventMainModelClasses.get(position).getDate());

                boolean status = eventMainModelClasses.get(position).isclick;

                if (status)
                {
                    holder.nonlistview.setVisibility(View.VISIBLE);
                    holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_up_arrow_black));
                }
                else {
                    holder.nonlistview.setVisibility(View.GONE);
                    holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_down_arrow_black));

                }

                holder.img_arrow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean status = eventMainModelClasses.get(position).isclick;
                        if (status)
                        {
//                            holder.nonlistview.setVisibility(View.VISIBLE);
//                            holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_up_arrow_black));
                            eventMainModelClasses.get(position).setIsclick(false);
                            notifyDataSetChanged();
                        }
                        else {
//                            holder.nonlistview.setVisibility(View.GONE);
//                            holder.img_arrow.setBackground(getResources().getDrawable(R.drawable.ic_down_arrow_black));
                            eventMainModelClasses.get(position).setIsclick(true);
                            notifyDataSetChanged();
                        }


                    }
                });


                adaptersubcon = new MysubListAdapter(data);
                holder.nonlistview.setHasFixedSize(true);
                holder.nonlistview.setLayoutManager(new LinearLayoutManager(getActivity()));
                holder.nonlistview.setAdapter(adaptersubcon);


            }catch (Exception e){
                e.printStackTrace();
            }


        }


        @Override
        public int getItemCount() {

            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {

            RecyclerView nonlistview;
            TextView txt_monname,txt_status;
            ImageView img_arrow;
            public ViewHolder(View itemView) {
                super(itemView);
                nonlistview = itemView.findViewById(R.id.nonlistview);
                img_arrow = itemView.findViewById(R.id.img_arrow);
                txt_monname = (TextView) itemView.findViewById(R.id.txt_monname);
                txt_status = (TextView) itemView.findViewById(R.id.txt_status);
            }
        }
    }


    public  class MysubListAdapter extends RecyclerView.Adapter<MysubListAdapter.ViewHolder>{
        List<GetWalletTransaction> eventMainModelClasses;

        // RecyclerView recyclerView;
        public MysubListAdapter(List<GetWalletTransaction> listdata) {
            this.eventMainModelClasses = listdata;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem= layoutInflater.inflate(R.layout.row_contestsublist_upcoimg, parent, false);
            ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            GetWalletTransaction myListData = eventMainModelClasses.get(position);

            try{

                holder.txt_date.setText(eventMainModelClasses.get(position).getDate());
//                holder.txt_proname.setText(eventMainModelClasses.get(position).getProname());
                holder.txt_title.setText(eventMainModelClasses.get(position).getOrderId());
                holder.txt_proprice.setText("€ "+eventMainModelClasses.get(position).getAmount());


            }catch (Exception e){
                e.printStackTrace();
            }

        }
        @Override
        public int getItemCount() {

            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {
            TextView txt_title,txt_proname,txt_proprice,txt_date;
            public ViewHolder(View itemView) {
                super(itemView);
                txt_title = (TextView) itemView.findViewById(R.id.txt_title);
                txt_proname = (TextView) itemView.findViewById(R.id.txt_proname);
                txt_proprice = (TextView) itemView.findViewById(R.id.txt_proprice);
                txt_date = (TextView) itemView.findViewById(R.id.txt_date);

            }
        }
    }

    public void sendPost() {
        Customprogress.showPopupProgressSpinner(getActivity(),true);

        mAPIService.getwallet(sessionManager.getSavedLoginToken()).enqueue(new Callback<GetWalletResponse>() {
            @Override
            public void onResponse(Call<GetWalletResponse> call, Response<GetWalletResponse> response) {

                Customprogress.showPopupProgressSpinner(getActivity(),false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status==true)
                    {

                        for (int i=0;i<response.body().getData().getTransactionData().size();i++)
                        {
                            response.body().getData().getTransactionData().get(i).setIsclick(false);
                        }

                        txt_ava_amt.setText("€ "+response.body().getData().getAvailableBalance());
                        txt_pen_amt.setText("€ "+response.body().getData().getPending_balance());

                        adaptercon = new MyListAdapter(response.body().getData().getTransactionData());
                        listevent.setHasFixedSize(true);
                        listevent.setLayoutManager(new LinearLayoutManager(getActivity()));
                        listevent.setAdapter(adaptercon);

                    }
                    else
                    {
                        Toast.makeText(getActivity(), ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<GetWalletResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(getActivity(),false);
                Log.e("TAG", ""+t.getMessage().toString());
            }

        });
    }*/


}