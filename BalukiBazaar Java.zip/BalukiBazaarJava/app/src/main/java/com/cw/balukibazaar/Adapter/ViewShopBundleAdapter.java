package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.ShopProductDetailActivity;
import com.cw.balukibazaar.Interface.ShopBundleData;
import com.cw.balukibazaar.ModelClass.ViewProfileData;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ViewShopBundleAdapter extends RecyclerView.Adapter<ViewShopBundleAdapter.ViewHolder> {
    private List<ViewProfileShop> stList;
    private List<ViewProfileShop> TransferShopDataList;
    private Context context;
    ViewProfileData viewProfileData;
    ShopBundleData shopBundleData;
    int itemcount=0;
    Double totalprice=0.00;
    Double totaldiscountprice=0.00;
    public ViewShopBundleAdapter(Context context, List<ViewProfileShop> students, ViewProfileData viewProfileData, ShopBundleData shopBundleData) {
        this.stList = students;
        this.context = context;
        this.viewProfileData = viewProfileData;
        this.shopBundleData = shopBundleData;

        TransferShopDataList = new ArrayList<>();

    }
    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_shopbundle_item, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        viewHolder.txt_price.setText("€ "+stList.get(position).getPrice());
        viewHolder.txt_proname.setText(stList.get(position).getName());
        viewHolder.txt_sellername.setText(viewProfileData.getSellername());

        Picasso.get().load(Allurls.ImageURL +stList.get(position).getImage()).error(R.drawable.progress_animation).placeholder( R.drawable.progress_animation ).into(viewHolder.img_product);
        Picasso.get().load(Allurls.ImageURL +viewProfileData.getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(viewHolder.img_seller);

        String s_fav  =stList.get(position).getIsFavorite();
        //0 means no favourite and 1 means favourite
        if (s_fav.equals("0")) {
            viewHolder.img_fav.setBackground(context.getResources().getDrawable(R.drawable.ic_heartnotfill));
        } else {
            viewHolder.img_fav.setBackground(context.getResources().getDrawable(R.drawable.ic_heartcolorfill));
        }

        if (stList.get(position).isSelected())
        {
            viewHolder.btn_add.setText(context.getResources().getString(R.string.remove));
            viewHolder.btn_add.setBackground(context.getResources().getDrawable(R.drawable.shape_gray_light));
        }
        else {
            viewHolder.btn_add.setText(context.getResources().getString(R.string.add));
            viewHolder.btn_add.setBackground(context.getResources().getDrawable(R.drawable.shape_yellow));
        }

        viewHolder.ll_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* Intent intent = new Intent(context, ShopProductDetailActivity.class);
                intent.putExtra("pro_id",stList.get(position).getId());
                context.startActivity(intent);*/
            }
        });



        viewHolder.btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (stList.get(position).isSelected())
                {

                    TransferShopDataList.remove(stList.get(position));
                    itemcount = itemcount-1;
                    totalprice = totalprice-Double.parseDouble(stList.get(position).getPrice());
                    totaldiscountprice = (totalprice / 100) * Double.parseDouble(viewProfileData.getDisPercent());
                    stList.get(position).setSelected(false);
                    viewHolder.btn_add.setText(context.getResources().getString(R.string.add));
                    viewHolder.btn_add.setBackground(context.getResources().getDrawable(R.drawable.shape_yellow));
                    shopBundleData.getshopbundledata(itemcount+"",totalprice+"",totaldiscountprice+"",TransferShopDataList);
                }
                else {
                    TransferShopDataList.add(stList.get(position));
                    stList.get(position).setSelected(true);
                    viewHolder.btn_add.setText(context.getResources().getString(R.string.remove));
                    viewHolder.btn_add.setBackground(context.getResources().getDrawable(R.drawable.shape_gray_light));
                    itemcount = itemcount+1;
                    totalprice = totalprice+Double.parseDouble(stList.get(position).getPrice());
                    totaldiscountprice = (totalprice / 100.0f) * Double.parseDouble(viewProfileData.getDisPercent());
                    shopBundleData.getshopbundledata(itemcount+"",totalprice+"",totaldiscountprice+"",TransferShopDataList);


                }


            }
        });

    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_sellername,txt_proname,txt_price,btn_add;
        RoundRectCornerImageView img_product;
        CircleImageView img_seller;
        ImageView img_fav;
        LinearLayout ll_item;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_sellername = itemLayoutView.findViewById(R.id.txt_sellername);
            txt_proname = itemLayoutView.findViewById(R.id.txt_proname);
            txt_price = itemLayoutView.findViewById(R.id.txt_price);
            btn_add = itemLayoutView.findViewById(R.id.btn_add);
            img_product = itemLayoutView.findViewById(R.id.img_product);
            img_seller = itemLayoutView.findViewById(R.id.img_seller);
            img_fav = itemLayoutView.findViewById(R.id.img_fav);
            ll_item = itemLayoutView.findViewById(R.id.ll_item);

        }

    }

    public List<ViewProfileShop> getStudentist() {
        return stList;
    }
}

