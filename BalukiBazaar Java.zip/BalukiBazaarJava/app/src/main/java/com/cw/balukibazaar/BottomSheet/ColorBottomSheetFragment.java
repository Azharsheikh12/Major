package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.ColorFilter;
import com.cw.balukibazaar.ModelClass.GlobalColorData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.List;


public class ColorBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    ImageView iv_close,iv_back;
    RecyclerView recycler_size;
    List<GlobalColorData> categoriesList;
    CategorySubAdapter MyListAdapter;
    Context context;
    SessionManager sessionManager;
    RelativeLayout rl_main;
    ArrayList<String> color_list =new  ArrayList();
    ColorFilter colorFilter;
    public ColorBottomSheetFragment(Context context, List<GlobalColorData> categoriesList, ColorFilter colorFilter) {
        this.categoriesList = categoriesList;
        this.context = context;
        this.colorFilter = colorFilter;
    }


    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_color, container, false);
        findIds(view);
        if(sessionManager.getColorList() !=null){
            if(sessionManager.getColorList().size() >0){
                color_list= sessionManager.getColorList();
            }
        }
        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_size.setHasFixedSize(true);
        recycler_size.setLayoutManager(new LinearLayoutManager(context));
        recycler_size.setAdapter(MyListAdapter);
        return view;

    }

    public void findIds(View v) {
        sessionManager =new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_size = v.findViewById(R.id.recycler_size);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                color_list = new  ArrayList();
                sessionManager.saveColorList(color_list);
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                dismissAllowingStateLoss();
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<GlobalColorData> eventMainModelClasses;
        private Context context;
        // RecyclerView recyclerView;
        public CategorySubAdapter(Context context, List<GlobalColorData> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_color_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final GlobalColorData myListData = eventMainModelClasses.get(position);

            holder.layout_color.setBackgroundColor(Color.parseColor(myListData.getCode()));
            holder.txt_colorname.setText(myListData.getName());
           /* if(color_list!=null){
                if(color_list.contains(myListData.getId().toString()))
                holder.cb_color.setChecked(true);
            }*/
            holder.cb_color.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        if(!color_list.equals(myListData.getId())){
                            color_list.add(myListData.getId());
                            sessionManager.saveColorList(color_list);
                            String colorid ="";
                            for (int i=0;i<color_list.size();i++){
                                colorid +=color_list.get(i)+",";
                            }
                            colorFilter.getColorid(colorid);
                            Log.e("ColorBottomSheet"," isChecked111 "+color_list.size());
                            Log.e("ColorBottomSheet"," isChecked111 SM "+sessionManager.getColorList().size());
                        }

                    }else{
                        if(color_list.equals(myListData.getId())){
                            color_list.remove(color_list.indexOf(myListData.getId()));
                            sessionManager.saveColorList(color_list);
                            String colorid ="";
                            for (int i=0;i<color_list.size();i++){
                                colorid +=color_list.get(i)+",";
                            }
                            colorFilter.getColorid(colorid);
                            Log.e("ColorBottomSheet"," isChecked000 "+color_list.size());
                            Log.e("ColorBottomSheet"," isChecked000 SM "+sessionManager.getColorList().size());
                        }
                    }
                }
            });

        }

        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {
            TextView txt_colorname;
            LinearLayout layout_color;
            CheckBox cb_color;
            public ViewHolder(View itemView) {
                super(itemView);

                txt_colorname = itemView.findViewById(R.id.txt_colorname);
                layout_color = itemView.findViewById(R.id.layout_color);
                cb_color = itemView.findViewById(R.id.cb_color);
            }
        }
    }


}