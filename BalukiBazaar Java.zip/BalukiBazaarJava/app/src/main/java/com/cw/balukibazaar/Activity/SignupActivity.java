package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.SignupResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {
    EditText edt_name,edt_email,edt_password,edt_username;
    ImageView iv_back;
    TextView btn_sign_up,tv_login;
    Activity activity;
    String s_name,s_email,s_password,s_sellername;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        InitView();
        System.out.println("Firebase token>>>>>>>>>> "+ FirebaseInstanceId.getInstance().getToken());
        sessionManager.setSavedFcmtoken(FirebaseInstanceId.getInstance().getToken());

        //Device Id
        String m_androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        System.out.println("Device Id >>>>>>>>>> "+ m_androidId);
        sessionManager.setSavedDeviceid(m_androidId);
        Click();
    }

    private void Click() {
        btn_sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                s_name = edt_name.getText().toString().trim();
                s_email = edt_email.getText().toString().trim();
                s_password = edt_password.getText().toString().trim();
                s_sellername = edt_username.getText().toString().trim();

                if (s_sellername.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,getResources().getString(R.string.Please_enter_user_name));
                }
               else if (s_name.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,"Please enter full name !");
                }
                else if (s_email.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,"Please enter email address !");
                }
                else if (!isValidEmail(s_email))
                {
                    CustomAlertdialog.createDialog(activity,"Please enter valid email address !");
                }
                else if (s_password.isEmpty())
                {
                    CustomAlertdialog.createDialog(activity,"Please enter password !");
                }
                else if (s_password.length()<6)
                {
                    CustomAlertdialog.createDialog(activity,"Password size is small, at least 6 characters minimum !");
                }
                else {
                    if(Utils.isInternetConnected(activity)) {

                        try {
                            sendPost(s_sellername,s_name,s_email, s_password);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                    }
                }
            }
        });
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        tv_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity,LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    private boolean isValidEmail(CharSequence email) {
        if (!TextUtils.isEmpty(email)) {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
        return false;
    }

    private void InitView() {
        activity = SignupActivity.this;
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(activity);
        edt_name = findViewById(R.id.edt_name);
        edt_email = findViewById(R.id.edt_email);
        edt_password = findViewById(R.id.edt_password);
        iv_back = findViewById(R.id.iv_back);
        btn_sign_up = findViewById(R.id.btn_sign_up);
        tv_login = findViewById(R.id.tv_login);
        edt_username = findViewById(R.id.edt_username);
    }
    public void sendPost(String s_sellername,String name,String email, String password) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);


        mAPIService.signup(name,email,sessionManager.getSavedStringFcmtoken(),password,s_sellername).enqueue(new Callback<SignupResponse>() {
            @Override
            public void onResponse(Call<SignupResponse> call, Response<SignupResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        String User_id = response.body().getData().getId();

                        sessionManager.setSavedUserid(User_id);
                        sessionManager.setUserLoggedIn(true);
                        sessionManager.setSavedUserName(response.body().getData().getName());

                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(activity, DashboardActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("about","0");
                        startActivity(intent);
                        finish();

                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<SignupResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", "Unable to submit post to API.");
            }
        });
    }
}