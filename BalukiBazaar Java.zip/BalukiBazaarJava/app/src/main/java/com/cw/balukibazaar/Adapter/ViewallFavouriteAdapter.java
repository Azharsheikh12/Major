package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.ModelClass.favourate.FavouriteData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ViewallFavouriteAdapter extends RecyclerView.Adapter<ViewallFavouriteAdapter.ViewHolder> {

    private Context context;
    List<FavouriteData> data;
    RemoveFavourite favourite;

    public ViewallFavouriteAdapter(Context context, List<FavouriteData> data,RemoveFavourite favourite) {
        this.context = context;
        this.data = data;
        this.favourite = favourite;
    }

    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_things_items, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);


        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
        FavouriteData listData = data.get(position);
        viewHolder.txt_sellername.setText(listData.getSellerdata().getName());
        viewHolder.txt_proname.setText(listData.getName());
        viewHolder.txt_price.setText("€ " + listData.getPrice());
        Picasso.get().load(Allurls.ImageURL + listData.getImage())
                .error(R.drawable.progress_animation)
                .placeholder(R.drawable.progress_animation)
                .into(viewHolder.img_product);

        Picasso.get().load(Allurls.ImageURL + listData.getSellerdata().getProfile())
                .error(R.drawable.progress_animation)
                .placeholder(R.drawable.progress_animation)
                .into(viewHolder.img_seller);

        //0 means no favourite and 1 means favourite

        if (listData.getIsFavorite().equals("0")){
            viewHolder.img_fav.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_heartnotfill));
        }else {
            viewHolder.img_fav.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_heartcolorfill));

        }

        viewHolder.img_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                favourite.getproduct_id(listData.getProductId());
            }
        });

    }

    // Return the size arraylist
    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_sellername, txt_proname, txt_price;
        public LinearLayout ll_item;
        public ImageView iv_item, img_seller,img_fav;
        RoundRectCornerImageView img_product;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_sellername = itemLayoutView.findViewById(R.id.txt_sellername);
            txt_proname = itemLayoutView.findViewById(R.id.txt_proname);
            txt_price = itemLayoutView.findViewById(R.id.txt_price);
            img_seller = itemLayoutView.findViewById(R.id.img_seller);
            img_product = itemLayoutView.findViewById(R.id.img_product);
            img_fav = itemLayoutView.findViewById(R.id.img_fav);


        }

    }

    // method to access in activity after updating selection
    public List<FavouriteData> getStudentist() {
        return data;
    }

}

