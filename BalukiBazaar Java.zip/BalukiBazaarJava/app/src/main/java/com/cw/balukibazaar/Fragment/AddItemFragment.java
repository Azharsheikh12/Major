package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.os.Bundle;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.BottomSheet.BrandBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.CategoryBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.ColorBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.ConditionBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.PriceBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.SizeBottomSheetFragment;
import com.cw.balukibazaar.Interface.BrandFilter;
import com.cw.balukibazaar.Interface.CategoryFilter;
import com.cw.balukibazaar.Interface.ColorFilter;
import com.cw.balukibazaar.Interface.ConditionFilter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.SizeFilter;
import com.cw.balukibazaar.ModelClass.AddProductResponse;
import com.cw.balukibazaar.ModelClass.GlobalBrandData;
import com.cw.balukibazaar.ModelClass.GlobalBrandResponse;
import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.ModelClass.GlobalCategoryResponse;
import com.cw.balukibazaar.ModelClass.GlobalColorData;
import com.cw.balukibazaar.ModelClass.GlobalColorResponse;
import com.cw.balukibazaar.ModelClass.GlobalConditionData;
import com.cw.balukibazaar.ModelClass.GlobalConditionResponse;
import com.cw.balukibazaar.ModelClass.GlobalSizeData;
import com.cw.balukibazaar.ModelClass.GlobalSizeResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import in.myinnos.awesomeimagepicker.activities.AlbumSelectActivity;
import in.myinnos.awesomeimagepicker.helpers.ConstantsCustomGallery;
import in.myinnos.awesomeimagepicker.models.Image;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddItemFragment extends Fragment {

    LinearLayout layout_upimg,rl_catalogue,rl_size,rl_color,rl_brand,rl_condition,rl_price;
    TextView txt_savedra,txt_listitem;
    //------------------------file code====================================
    String encodeimg1, cartkey;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    File uploadFileI;
    RecyclerView grid;
    ArrayList<String> files = new ArrayList<>();
    //    CustomGrid adapter;
    ImagesAdapter adapter;
    int gallery_val =10;
    //------------------------file code====================================
    EditText edt_title,edt_desc;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;

    ArrayList<String> clearlist = new ArrayList<>();
    String s_title,s_desc;
    String color_list_content,size_list_content,cateid;
    private List<GlobalCategoryData> categoriesList;
    private List<GlobalSizeData> sizeList;
    private List<GlobalColorData> colorList;
    private List<GlobalBrandData> brandList;
    private List<GlobalConditionData> conditionList;
    Context context;
    ImageView img_notification;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add_item, container, false);
        InitView(v);
        sessionManager.saveColorList(clearlist);
        sessionManager.saveSizeList(clearlist);

        if(Utils.isInternetConnected(context)) {

            sendPostcategory();
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }
        try {
            files.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
        grid.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager =new GridLayoutManager(getActivity(), 3);
        grid.setLayoutManager(layoutManager);
        Click();
        return v;
    }
    private void Click() {

        layout_upimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });

        rl_catalogue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CategoryBottomSheetFragment filterBottomSheetFragment = new CategoryBottomSheetFragment(getContext(),categoriesList, new CategoryFilter() {
                    @Override
                    public void getCateegoryid(String cateid) {
                    }
                });
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        rl_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sessionManager.saveSizeList(clearlist);
                SizeBottomSheetFragment filterBottomSheetFragment = new SizeBottomSheetFragment(getContext(),sizeList, new SizeFilter() {
                    @Override
                    public void getSizeid(String cateid) {
                    }
                });
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });

        rl_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.saveColorList(clearlist);
                ColorBottomSheetFragment filterBottomSheetFragment = new ColorBottomSheetFragment(getContext(),colorList, new ColorFilter() {
                    @Override
                    public void getColorid(String cateid) {
                    }
                });
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });

        rl_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BrandBottomSheetFragment filterBottomSheetFragment = new BrandBottomSheetFragment(getContext(),brandList, new BrandFilter() {
                    @Override
                    public void getBrandid(String cateid) {
                    }
                });
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        rl_condition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConditionBottomSheetFragment filterBottomSheetFragment = new ConditionBottomSheetFragment(getContext(),conditionList, new ConditionFilter() {
                    @Override
                    public void getConditionid(String cateid) {
                    }
                });
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });
        rl_price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PriceBottomSheetFragment filterBottomSheetFragment = new PriceBottomSheetFragment(getContext());
                filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });


        txt_savedra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_title = edt_title.getText().toString().trim();
                s_desc = edt_desc.getText().toString().trim();

                if (files.size()==0) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_select_images));
                } else if (s_title.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_title));
                } else if (s_desc.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_description));
                } else if(sessionManager.getSavedCateId().equals(0)){
                    CustomAlertdialog.createDialog(context, "Please select category !");
                }else if(sessionManager.getSizeList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select size !");
                }else if(sessionManager.getColorList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select color !");
                }else if(sessionManager.getBrand().equals("0")){
                    CustomAlertdialog.createDialog(context, "Please select brand !");
                }else if(sessionManager.getCondition().equals("0")){
                    CustomAlertdialog.createDialog(context, "Please select condition !");
                }else if(sessionManager.getPrice().equals("")|| sessionManager.getPrice().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select price !");
                }else{
                    uploadMultiFile("0");
                }
            }
        });

        txt_listitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_title = edt_title.getText().toString().trim();
                s_desc = edt_desc.getText().toString().trim();

                if (files.size()==0) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_select_images));
                } else if (s_title.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_title));
                } else if (s_desc.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_description));
                } else if(sessionManager.getSavedCateId().equals(0)){
                    CustomAlertdialog.createDialog(context, "Please select category !");
                }else if(sessionManager.getSizeList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select size !");
                }else if(sessionManager.getColorList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select color !");
                }else if(sessionManager.getBrand().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select brand !");
                }else if(sessionManager.getCondition().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select condition !");
                }else if(sessionManager.getPrice().equals("")|| sessionManager.getPrice().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select price !");
                }else{
                    uploadMultiFile("1");
                }
            }
        });
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }
    private void InitView(View v) {
        context = getActivity();
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(context);
        layout_upimg = v.findViewById(R.id.layout_upimg);
        grid = v.findViewById(R.id.grid);
        edt_title = v.findViewById(R.id.edt_title);
        edt_desc = v.findViewById(R.id.edt_desc);
        rl_catalogue = v.findViewById(R.id.rl_catalogue);
        rl_size = v.findViewById(R.id.rl_size);
        rl_color = v.findViewById(R.id.rl_color);
        rl_brand = v.findViewById(R.id.rl_brand);
        rl_condition = v.findViewById(R.id.rl_condition);
        rl_price = v.findViewById(R.id.rl_price);
        txt_savedra = v.findViewById(R.id.txt_savedra);
        txt_listitem = v.findViewById(R.id.txt_listitem);
        img_notification = v.findViewById(R.id.img_notification);
    }

    private void selectImage() {


        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Upload Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";

                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                    } else {
                        if(files!=null){
                            if(files.size()==10){
                                Toast.makeText(context,"Can select a maximum of 10 images", Toast.LENGTH_SHORT).show();
                            }else{
                                cameraIntent();
                            }
                        }else{
                            cameraIntent();
                        }
                    }


                }
                else if (items[item].equals("Choose from Library"))
                {
                    userChoosenTask = "Choose from Library";

                    if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                    } else {
                        if(files!=null){
                            if(files.size()>0){
                                gallery_val= 10-files.size();
                            }
                        }
                        Intent intent = new Intent(context, AlbumSelectActivity.class);
                        intent.putExtra(ConstantsCustomGallery.INTENT_EXTRA_LIMIT, gallery_val); // set limit for image selection
                        startActivityForResult(intent, ConstantsCustomGallery.REQUEST_CODE);
                    }


                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();

    }
    private void cameraIntent() {
        try {

            System.out.println("CAMERA OPEN 22");
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        System.out.println("Request Code >>>>>>>"+requestCode);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(context, AlbumSelectActivity.class);
                    intent.putExtra(ConstantsCustomGallery.INTENT_EXTRA_LIMIT, gallery_val); // set limit for image selection
                    startActivityForResult(intent, ConstantsCustomGallery.REQUEST_CODE);

                } else {
//                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            case 2:
            {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    cameraIntent();

                } else {
//                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        System.out.println("request code >>>>>>>>>"+requestCode);
        if (requestCode == ConstantsCustomGallery.REQUEST_CODE && data != null) {
            ArrayList<Image> images = data.getParcelableArrayListExtra(ConstantsCustomGallery.INTENT_EXTRA_IMAGES);

            for(int i=0;i<images.size();i++){
                Uri uri = Uri.fromFile(new File(images.get(i).path));
                encodeimg1 = getRealPathFromURI(uri);
                files.add(encodeimg1);
            }
            adapter = new ImagesAdapter(context,  files) ;
            grid.setAdapter(adapter);
        }
        if (requestCode == 2 && null !=data) {

            onCaptureImageResultProfile(data);
        }

    }
    private void onCaptureImageResultProfile(Intent data) {
        try {

            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);

            File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");

            FileOutputStream fo;
            try {
                destination.createNewFile();
                fo = new FileOutputStream(destination);
                fo.write(bytes.toByteArray());
                fo.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Uri tempUri = getImageUri(context,thumbnail);

            // CALL THIS METHOD TO GET THE ACTUAL PATH
            //   File finalFile = new File(getRealPathFromURI(tempUri));

            System.out.println("data.getData() " + data.getData());
            encodeimg1= getRealPathFromURI(tempUri);

            files.add(encodeimg1);

            adapter = new ImagesAdapter(context, files);
            grid.setAdapter(adapter);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        String path = null;
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            Long tsLong = System.currentTimeMillis()/1000;
            path = MediaStore.Images.Media.insertImage(context.getContentResolver(), inImage, ""+tsLong, null);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return Uri.parse(path);
    }
    private String getRealPathFromURI(Uri contentURI)
    {
        String result;


        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getActivity().getContentResolver().query(contentURI, projection, null, null, null);
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = 0;
            idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }

        return result;

    }
    public void getImageFilePath(Uri uri) {

        File file = new File(uri.getPath());
        String[] filePath = file.getPath().split(":");
        String image_id = filePath[filePath.length - 1];
        Cursor cursor = getActivity().getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, MediaStore.Images.Media._ID + " = ? ", new String[]{image_id}, null);
        if (cursor != null) {
            cursor.moveToFirst();
            String imagePath = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            files.add(imagePath);
            cursor.close();

            adapter = new ImagesAdapter(getActivity(), files);
            grid.setAdapter(adapter);

        }
    }
    public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.ViewHolder> {
        private List<String> data;
        private Context context;

        public ImagesAdapter(Context context, List<String> students) {
            this.data = students;
            this.context = context;

        }

        // Create new views
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
            View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_single, parent, false);

            ViewHolder viewHolder = new ViewHolder(itemLayoutView);
//            ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(context));

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ViewHolder viewHolder, final int position) {
            Bitmap bmp = BitmapFactory.decodeFile(files.get(position));
            viewHolder.grid_image.setImageBitmap(bmp);
            viewHolder.imgcross.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println("position >>>>>>>>>>>"+position);
                    files.remove(position);
                    System.out.println("web list >>>>>>>>>>>"+files);
//                        web.notifyAll();

                    adapter = new ImagesAdapter(getActivity(), files);
                    grid.setAdapter(adapter);
                    adapter.notifyDataSetChanged();
                }
            });


        }

        // Return the size arraylist
        @Override
        public int getItemCount() {
            return data.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            public ImageView imgcross;
            public CircleImageView grid_image;


            public ViewHolder(View itemLayoutView) {
                super(itemLayoutView);

                imgcross = itemLayoutView.findViewById(R.id.imgcross);
                grid_image = itemLayoutView.findViewById(R.id.grid_image);
            }
        }
        // method to access in activity after updating selection
        public List<String> getStudentist() {
            return data;
        }

    }

    public void sendPostcategory()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcategorylist().enqueue(new Callback<GlobalCategoryResponse>() {
            @Override
            public void onResponse(Call<GlobalCategoryResponse> call, Response<GlobalCategoryResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostsize();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        categoriesList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalCategoryResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostsize()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getsizelist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalSizeResponse>() {
            @Override
            public void onResponse(Call<GlobalSizeResponse> call, Response<GlobalSizeResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostcolor();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        sizeList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalSizeResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcolor()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcolorlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalColorResponse>() {
            @Override
            public void onResponse(Call<GlobalColorResponse> call, Response<GlobalColorResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostbrand();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        colorList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalColorResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostbrand()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getbrandlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalBrandResponse>() {
            @Override
            public void onResponse(Call<GlobalBrandResponse> call, Response<GlobalBrandResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostcondition();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        brandList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalBrandResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcondition()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getconditionlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalConditionResponse>() {
            @Override
            public void onResponse(Call<GlobalConditionResponse> call, Response<GlobalConditionResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        conditionList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalConditionResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }

    private void uploadMultiFile(String itemvalue) {

        try {
            color_list_content = "";
            Log.i("color_list_ size >",""+sessionManager.getColorList().size());
            Log.i("size_list_ size >",""+sessionManager.getSizeList().size());
            Log.i("Brand >",""+sessionManager.getBrand());
            Log.i("condition_id >",""+sessionManager.getCondition());
            Log.i("price >",""+sessionManager.getPrice());
            for (int i=0;i<sessionManager.getColorList().size();i++) {
                color_list_content += sessionManager.getColorList().get(i) + ",";
            }

            size_list_content = "";
            for (int i=0;i< sessionManager.getSizeList().size();i++) {
                size_list_content += sessionManager.getSizeList().get(i) + ",";
            }

            Log.d("size_list_content >>>",""+size_list_content);
            Log.d("color_list_content >>>",""+color_list_content);

            Customprogress.showPopupProgressSpinner(context,true);

          /*  MultipartBody.Builder builder = new MultipartBody.Builder();
            builder.setType(MultipartBody.FORM);*/

            HashMap<String, RequestBody> data = new HashMap<>();
            data.put("user_id", createRequestBody(sessionManager.getSavedUserid()));
            data.put("name", createRequestBody(s_title));
            data.put("description", createRequestBody(s_desc));
            data.put("category_id", createRequestBody(sessionManager.getSavedCateId()));
            data.put("size", createRequestBody(size_list_content.substring(0, size_list_content.length() - 1)));
            data.put("color", createRequestBody(color_list_content.substring(0, color_list_content.length() - 1)));
            data.put("brand_id", createRequestBody(sessionManager.getBrand()));
            data.put("condition_id", createRequestBody(sessionManager.getCondition()));
            data.put("price", createRequestBody(sessionManager.getPrice()));
            data.put("in_draft", createRequestBody(itemvalue));
            data.put("action", createRequestBody("Add"));

           /* builder.addFormDataPart("user_id", sessionManager.getSavedUserid());
            builder.addFormDataPart("name", s_title);
            builder.addFormDataPart("description", s_desc);
            builder.addFormDataPart("category_id", sessionManager.getSavedCateId().toString());
            builder.addFormDataPart("size", size_list_content.substring(0, size_list_content.length() - 1));
            builder.addFormDataPart("color",  color_list_content.substring(0, color_list_content.length() - 1));
            builder.addFormDataPart("brand_id",sessionManager.getBrand().toString());
            builder.addFormDataPart("condition_id", sessionManager.getCondition().toString());
            builder.addFormDataPart("price", sessionManager.getPrice().toString());
            builder.addFormDataPart("in_draft", itemvalue);
            builder.addFormDataPart("action", "Add");
*/
            List<MultipartBody.Part> partList = new ArrayList<>();
            for (int i = 0; i < files.size(); i++) {
                File file = new File(files.get(i));
                RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
                MultipartBody.Part part = MultipartBody.Part.createFormData("images[]",file.getName(),requestBody);
                partList.add(part);
            }

            Call<AddProductResponse> call = mAPIService.add_product(data,partList);
            call.enqueue(new Callback<AddProductResponse>() {
                @Override
                public void onResponse(Call<AddProductResponse> call, Response<AddProductResponse> response) {

                    Customprogress.showPopupProgressSpinner(context,false);

                    if(response.isSuccessful()) {
                        Customprogress.showPopupProgressSpinner(context, false);
                         boolean status = response.body().getStatus();
                        if (status == true) {
                            Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_LONG).show();
                            ClearData();

                        }
                        else{
                            Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }
                @Override
                public void onFailure(Call<AddProductResponse> call, Throwable t) {

                    Customprogress.showPopupProgressSpinner(context,false);

                    Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();

                    Log.d("TAG >>>>>>>>>>>>", "Error " + t.getMessage());
                }
            });

        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    private void ClearData(){
        files.clear();
        adapter.notifyDataSetChanged();
        edt_desc.setText("");
        edt_title.setText("");
        sessionManager.setSavedCateId("");
        sessionManager.saveSizeList(clearlist);
        sessionManager.saveColorList(clearlist);
        sessionManager.saveBrand("");
        sessionManager.saveCondition("");
        sessionManager.savePrice("");
    }

    public RequestBody createRequestBody(@NonNull String s) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), s);
    }

}