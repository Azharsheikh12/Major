package com.cw.balukibazaar.Interface;

public interface ProductImagesDelete {
    void getProductImageId(String image_id);

}
