package com.cw.balukibazaar.Interface;

import com.cw.balukibazaar.ModelClass.ViewProfileShop;

import java.util.List;

public interface ProductFeaturesData {
    void getproductfeaturesdata(Integer item_count, String product_ids, double itemprice, List<ViewProfileShop> adddataList);
}
