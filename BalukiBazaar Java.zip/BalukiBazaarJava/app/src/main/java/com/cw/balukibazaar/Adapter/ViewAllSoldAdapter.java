package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Fragment.SoldItemsFragment;
import com.cw.balukibazaar.ModelClass.MyOrderData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.Convertyymmddtoddmmyy;

import java.util.List;


public class ViewAllSoldAdapter extends RecyclerView.Adapter<ViewAllSoldAdapter.ViewHolder> {
    private List<MyOrderData> data;
    private Context context;
    Fragment fragment = null;
    public ViewAllSoldAdapter(Context context, List<MyOrderData> data) {
        this.context = context;
        this.data = data;

    }

    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_purachased, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

        MyOrderData listData = data.get(position);
        viewHolder.txt_itemname.setText(data.get(position).getOrderId());
        viewHolder.txt_price.setText("€ "+data.get(position).getTotalAmount());
        viewHolder.txt_date.setText(Convertyymmddtoddmmyy.dateconvert(data.get(position).getCreatedAt()));

        viewHolder.layoutcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("data", listData);
                bundle.putString("totalamt",data.get(position).getTotalAmount());
                bundle.putString("discountamt",data.get(position).getDiscountAmount());
                fragment = new SoldItemsFragment();
                fragment.setArguments(bundle);
                ((AppCompatActivity)context).getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack("cxsc")
                        .commit();
            }
        });
    }
    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_itemname,txt_subtitle,txt_price,txt_date;
        public LinearLayout layoutcard;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_itemname = itemLayoutView.findViewById(R.id.txt_itemname);
            txt_subtitle = itemLayoutView.findViewById(R.id.txt_subtitle);
            txt_price = itemLayoutView.findViewById(R.id.txt_price);
            txt_date = itemLayoutView.findViewById(R.id.txt_date);
            layoutcard = itemLayoutView.findViewById(R.id.layoutcard);


        }

    }
    // method to access in activity after updating selection
    public List<MyOrderData> getStudentist() {
        return data;
    }

}

