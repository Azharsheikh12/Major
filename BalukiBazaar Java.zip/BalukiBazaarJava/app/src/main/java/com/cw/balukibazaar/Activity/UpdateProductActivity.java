package com.cw.balukibazaar.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.BottomSheet.EditBrandBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.EditCategoryBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.EditColorBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.EditConditionBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.EditPriceBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.EditSizeBottomSheetFragment;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.AddProductResponse;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.GlobalBrandData;
import com.cw.balukibazaar.ModelClass.GlobalBrandResponse;
import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.ModelClass.GlobalCategoryResponse;
import com.cw.balukibazaar.ModelClass.GlobalColorData;
import com.cw.balukibazaar.ModelClass.GlobalColorResponse;
import com.cw.balukibazaar.ModelClass.GlobalConditionData;
import com.cw.balukibazaar.ModelClass.GlobalConditionResponse;
import com.cw.balukibazaar.ModelClass.GlobalSizeData;
import com.cw.balukibazaar.ModelClass.GlobalSizeResponse;
import com.cw.balukibazaar.ModelClass.ProductDetailColor;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.ModelClass.ProductDetailSize;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import in.myinnos.awesomeimagepicker.activities.AlbumSelectActivity;
import in.myinnos.awesomeimagepicker.helpers.ConstantsCustomGallery;
import in.myinnos.awesomeimagepicker.models.Image;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateProductActivity extends AppCompatActivity {

    String pro_id,user_id;
    Context context;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_back;
    RecyclerView grid;
    ImagesEditAdapter imagesEditAdapter;
    EditText edt_title,edt_desc;
    LinearLayout layout_upimg,rl_catalogue,rl_size,rl_color,rl_brand,rl_condition,rl_price;
    String price,category_id,brand_id,condition_id,s_title,s_desc,in_draft;
    private List<GlobalCategoryData> categoriesList;
    private List<GlobalSizeData> sizeList;
    private List<ProductDetailSize> getsizeList;
    private List<GlobalColorData> colorList;
    private List<ProductDetailColor> getcolorList;
    private List<GlobalBrandData> brandList;
    private List<GlobalConditionData> conditionList;
    List<ProductDetailImage> imageslist;
    //------------------------file code====================================
    String encodeimg1, cartkey;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    private String userChoosenTask;
    File uploadFileI;
    ArrayList<String> files = new ArrayList<>();
    int gallery_val =10;
    //------------------------file code====================================
    TextView txt_savedra,txt_listitem,txt_update;
    SessionManager sessionManager;
    String color_list_content,size_list_content,cateid;
    ArrayList<String> clearlist = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_product);
        InitView();
        sessionManager.saveColorList(clearlist);
        sessionManager.saveSizeList(clearlist);
        Click();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                pro_id = intent.getStringExtra("pro_id");
                user_id = intent.getStringExtra("user_id");
                if(Utils.isInternetConnected(context)) {

                    try {
                        sendPost(user_id,pro_id);
                        sendPostcategory();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                else {
                    CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        rl_catalogue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditCategoryBottomSheetFragment filterBottomSheetFragment = new EditCategoryBottomSheetFragment(context,categoriesList,category_id);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        rl_size.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.saveSizeList(clearlist);
                EditSizeBottomSheetFragment filterBottomSheetFragment = new EditSizeBottomSheetFragment(context,sizeList,getsizeList);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });

        rl_color.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.saveColorList(clearlist);
                EditColorBottomSheetFragment filterBottomSheetFragment = new EditColorBottomSheetFragment(context,colorList,getcolorList);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });

        rl_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditBrandBottomSheetFragment filterBottomSheetFragment = new EditBrandBottomSheetFragment(context,brandList,brand_id);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        rl_condition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditConditionBottomSheetFragment filterBottomSheetFragment = new EditConditionBottomSheetFragment(context,conditionList,condition_id);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        rl_price.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditPriceBottomSheetFragment filterBottomSheetFragment = new EditPriceBottomSheetFragment(context,price);
                filterBottomSheetFragment.show(getSupportFragmentManager(), "add_photo_dialog_fragment");

            }
        });

        layout_upimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImage();
            }
        });

        txt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_title = edt_title.getText().toString().trim();
                s_desc = edt_desc.getText().toString().trim();

                if (imageslist.size()==0) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_select_images));
                } else if (s_title.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_title));
                } else if (s_desc.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_description));
                } else if(sessionManager.getSavedCateId().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select category !");
                }else if(sessionManager.getSizeList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select size !");
                }else if(sessionManager.getColorList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select color !");
                }else if(sessionManager.getBrand().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select brand !");
                }else if(sessionManager.getCondition().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select condition !");
                }else if(sessionManager.getPrice().equals("")|| sessionManager.getPrice().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select price !");
                }else{
                    uploadMultiFile(in_draft);
                }
            }
        });

        txt_savedra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_title = edt_title.getText().toString().trim();
                s_desc = edt_desc.getText().toString().trim();

                if (imageslist.size()==0) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_select_images));
                } else if (s_title.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_title));
                } else if (s_desc.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_description));
                } else if(sessionManager.getSavedCateId().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select category !");
                }else if(sessionManager.getSizeList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select size !");
                }else if(sessionManager.getColorList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select color !");
                }else if(sessionManager.getBrand().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select brand !");
                }else if(sessionManager.getCondition().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select condition !");
                }else if(sessionManager.getPrice().equals("")|| sessionManager.getPrice().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select price !");
                }else{
                    uploadMultiFile("0");
                }
            }
        });

        txt_listitem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_title = edt_title.getText().toString().trim();
                s_desc = edt_desc.getText().toString().trim();

                if (imageslist.size()==0) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_select_images));
                } else if (s_title.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_title));
                } else if (s_desc.isEmpty()) {
                    CustomAlertdialog.createDialog(context, getResources().getString(R.string.Please_enter_description));
                } else if(sessionManager.getSavedCateId().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select category !");
                }else if(sessionManager.getSizeList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select size !");
                }else if(sessionManager.getColorList().size()==0){
                    CustomAlertdialog.createDialog(context, "Please select color !");
                }else if(sessionManager.getBrand().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select brand !");
                }else if(sessionManager.getCondition().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select condition !");
                }else if(sessionManager.getPrice().equals("")|| sessionManager.getPrice().equals("")){
                    CustomAlertdialog.createDialog(context, "Please select price !");
                }else{
                    uploadMultiFile("1");
                }
            }
        });

    }

    private void InitView() {
        context = UpdateProductActivity.this;
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        img_back = findViewById(R.id.img_back);
        grid = findViewById(R.id.grid);
        edt_title = findViewById(R.id.edt_title);
        edt_desc = findViewById(R.id.edt_desc);
        rl_catalogue = findViewById(R.id.rl_catalogue);
        rl_size = findViewById(R.id.rl_size);
        rl_color = findViewById(R.id.rl_color);
        rl_brand = findViewById(R.id.rl_brand);
        rl_condition = findViewById(R.id.rl_condition);
        rl_price = findViewById(R.id.rl_price);
        layout_upimg = findViewById(R.id.layout_upimg);
        txt_savedra = findViewById(R.id.txt_savedra);
        txt_listitem = findViewById(R.id.txt_listitem);
        txt_update = findViewById(R.id.txt_update);
    }
    private void ImageAdapterDataSet(List<ProductDetailImage> imageslist) {
        grid.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager =new GridLayoutManager(context, 3);
        grid.setLayoutManager(layoutManager);
        imagesEditAdapter = new ImagesEditAdapter(context,imageslist, files);
        grid.setAdapter(imagesEditAdapter);
    }
    private void selectImage() {


        final CharSequence[] items = {"Take Photo", "Choose from Library", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Upload Photo!");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {

                if (items[item].equals("Take Photo")) {
                    userChoosenTask = "Take Photo";

                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(UpdateProductActivity.this, new String[]{Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
                    } else {
                        if(files!=null){
                            if(files.size()==10){
                                Toast.makeText(context,"Can select a maximum of 10 images", Toast.LENGTH_SHORT).show();
                            }else{
                                cameraIntent();
                            }
                        }else{
                            cameraIntent();
                        }
                    }


                }
                else if (items[item].equals("Choose from Library"))
                {
                    userChoosenTask = "Choose from Library";

                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(UpdateProductActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                    } else {
                        if(files!=null){
                            if(files.size()>0){
                                gallery_val= 10-files.size();
                            }
                        }
                        Intent intent = new Intent(context, AlbumSelectActivity.class);
                        intent.putExtra(ConstantsCustomGallery.INTENT_EXTRA_LIMIT, gallery_val); // set limit for image selection
                        startActivityForResult(intent, ConstantsCustomGallery.REQUEST_CODE);
                    }


                } else if (items[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();

    }
    private void cameraIntent() {
        try {

            System.out.println("CAMERA OPEN 22");
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(intent, 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        System.out.println("Request Code >>>>>>>"+requestCode);
        switch (requestCode) {
            case 1: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Intent intent = new Intent(context, AlbumSelectActivity.class);
                    intent.putExtra(ConstantsCustomGallery.INTENT_EXTRA_LIMIT, gallery_val); // set limit for image selection
                    startActivityForResult(intent, ConstantsCustomGallery.REQUEST_CODE);

                } else {
//                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }
            case 2:
            {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    cameraIntent();

                } else {
//                    Toast.makeText(getApplicationContext(), "Permission denied", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        System.out.println("request code >>>>>>>>>"+requestCode);
        if (requestCode == ConstantsCustomGallery.REQUEST_CODE && data != null) {
            ArrayList<Image> images = data.getParcelableArrayListExtra(ConstantsCustomGallery.INTENT_EXTRA_IMAGES);

            for(int i=0;i<images.size();i++){
                Uri uri = Uri.fromFile(new File(images.get(i).path));
                encodeimg1 = getRealPathFromURI(uri);
                ProductDetailImage productDetailImage = new ProductDetailImage();
                productDetailImage.setId("");
                productDetailImage.setPath(encodeimg1);
                imageslist.add(productDetailImage);
//                files.add(encodeimg1);
            }
            imagesEditAdapter = new ImagesEditAdapter(context,imageslist  ,files) ;
            grid.setAdapter(imagesEditAdapter);
        }
        if (requestCode == 2 && null !=data) {

            onCaptureImageResultProfile(data);
        }

    }
    private void onCaptureImageResultProfile(Intent data) {
        try {

            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            thumbnail.compress(Bitmap.CompressFormat.JPEG, 100, bytes);

            File destination = new File(Environment.getExternalStorageDirectory(), System.currentTimeMillis() + ".jpg");

            FileOutputStream fo;
            try {
                destination.createNewFile();
                fo = new FileOutputStream(destination);
                fo.write(bytes.toByteArray());
                fo.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Uri tempUri = getImageUri(context,thumbnail);

            // CALL THIS METHOD TO GET THE ACTUAL PATH
            //   File finalFile = new File(getRealPathFromURI(tempUri));

            System.out.println("data.getData() " + data.getData());
            encodeimg1= getRealPathFromURI(tempUri);
            ProductDetailImage productDetailImage = new ProductDetailImage();
            productDetailImage.setId("");
            productDetailImage.setPath(encodeimg1);
            imageslist.add(productDetailImage);
//            files.add(encodeimg1);

            imagesEditAdapter = new ImagesEditAdapter(context, imageslist, files);
            grid.setAdapter(imagesEditAdapter);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        String path = null;
        try {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            Long tsLong = System.currentTimeMillis()/1000;
            path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, ""+tsLong, null);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return Uri.parse(path);
    }
    private String getRealPathFromURI(Uri contentURI)
    {
        String result;

        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentURI, projection, null, null, null);
        if (cursor == null) {
            result = contentURI.getPath();
        } else {
            cursor.moveToFirst();
            int idx = 0;
            idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            result = cursor.getString(idx);
            cursor.close();
        }

        return result;

    }
    public void getImageFilePath(Uri uri) {

        File file = new File(uri.getPath());
        String[] filePath = file.getPath().split(":");
        String image_id = filePath[filePath.length - 1];
        Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, null, MediaStore.Images.Media._ID + " = ? ", new String[]{image_id}, null);
        if (cursor != null) {
            cursor.moveToFirst();
            String imagePath = cursor.getString(cursor.getColumnIndex(MediaStore.Images.Media.DATA));
            files.add(imagePath);
            cursor.close();

            imagesEditAdapter = new ImagesEditAdapter(context,imageslist ,files);
            grid.setAdapter(imagesEditAdapter);

        }
    }
    private void ClearData(){
        files.clear();
        edt_desc.setText("");
        edt_title.setText("");
        sessionManager.setSavedCateId("");
        sessionManager.saveSizeList(clearlist);
        sessionManager.saveColorList(clearlist);
        sessionManager.saveBrand("");
        sessionManager.saveCondition("");
        sessionManager.savePrice("");
    }
    public RequestBody createRequestBody(@NonNull String s) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), s);
    }
    //-----------Services---------
    public void sendPost(String user_id,String pro_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.getproductdetaildata(user_id,pro_id).enqueue(new Callback<ProductDetailResponse>() {
            @Override
            public void onResponse(Call<ProductDetailResponse> call, Response<ProductDetailResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {


                        imageslist = response.body().getData().getImages();
                        ImageAdapterDataSet(response.body().getData().getImages());
                        edt_title.setText(response.body().getData().getName());
                        edt_desc.setText(response.body().getData().getDescription());
                        price = response.body().getData().getPrice();
                        category_id = response.body().getData().getCategoryId();
                        getsizeList = response.body().getData().getSize();
                        getcolorList = response.body().getData().getColor();
                        brand_id = response.body().getData().getBrandId();
                        condition_id = response.body().getData().getConditionId();

                        String provalue = response.body().getData().getInDraft();
                        in_draft = provalue;
                        Log.i("provalue >>>",""+provalue);
                        //provalue = 0 means save draft and provalue = 1 means list item
                        if (provalue.equals("0"))
                        {
                          txt_savedra.setVisibility(View.VISIBLE);
                          txt_listitem.setVisibility(View.VISIBLE);
                          txt_update.setVisibility(View.GONE);
                        }
                        else {

                            txt_savedra.setVisibility(View.GONE);
                            txt_listitem.setVisibility(View.GONE);
                            txt_update.setVisibility(View.VISIBLE);
                        }

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProductDetailResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }
    public void sendPostcategory()  {
//        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcategorylist().enqueue(new Callback<GlobalCategoryResponse>() {
            @Override
            public void onResponse(Call<GlobalCategoryResponse> call, Response<GlobalCategoryResponse> response) {

//                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostsize();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        categoriesList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalCategoryResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostsize()  {
//        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getsizelist(user_id).enqueue(new Callback<GlobalSizeResponse>() {
            @Override
            public void onResponse(Call<GlobalSizeResponse> call, Response<GlobalSizeResponse> response) {

//                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    sendPostcolor();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        sizeList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalSizeResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcolor()  {
//        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcolorlist(user_id).enqueue(new Callback<GlobalColorResponse>() {
            @Override
            public void onResponse(Call<GlobalColorResponse> call, Response<GlobalColorResponse> response) {

//                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    sendPostbrand();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        colorList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalColorResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostbrand()  {
//        Customprogress.showPopupProgressSpinner(activity,true);
        mAPIService.getbrandlist(user_id).enqueue(new Callback<GlobalBrandResponse>() {
            @Override
            public void onResponse(Call<GlobalBrandResponse> call, Response<GlobalBrandResponse> response) {

//                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    sendPostcondition();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        brandList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalBrandResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcondition()  {
//        Customprogress.showPopupProgressSpinner(activity,true);
        mAPIService.getconditionlist(user_id).enqueue(new Callback<GlobalConditionResponse>() {
            @Override
            public void onResponse(Call<GlobalConditionResponse> call, Response<GlobalConditionResponse> response) {

//                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        conditionList = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalConditionResponse> call, Throwable t) {
//                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostProductImageDelete(String imageid)  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.removeproductimage(user_id,pro_id,imageid).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostsize();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        if(Utils.isInternetConnected(context)) {

                            try {
                                sendPost(user_id,pro_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                        }
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    private void uploadMultiFile(String itemvalue) {

        try {
            color_list_content = "";
            Log.i("color_list_ size >",""+sessionManager.getColorList().size());
            Log.i("size_list_ size >",""+sessionManager.getSizeList().size());
            Log.i("Brand >",""+sessionManager.getBrand());
            Log.i("condition_id >",""+sessionManager.getCondition());
            Log.i("price >",""+sessionManager.getPrice());
            for (int i=0;i<sessionManager.getColorList().size();i++) {
                color_list_content += sessionManager.getColorList().get(i) + ",";
            }

            size_list_content = "";
            for (int i=0;i< sessionManager.getSizeList().size();i++) {
                size_list_content += sessionManager.getSizeList().get(i) + ",";
            }

            Log.d("size_list_content >>>",""+size_list_content);
            Log.d("color_list_content >>>",""+color_list_content);

            Customprogress.showPopupProgressSpinner(context,true);

          /*  MultipartBody.Builder builder = new MultipartBody.Builder();
            builder.setType(MultipartBody.FORM);*/

            HashMap<String, RequestBody> data = new HashMap<>();
            data.put("user_id", createRequestBody(sessionManager.getSavedUserid()));
            data.put("name", createRequestBody(s_title));
            data.put("description", createRequestBody(s_desc));
            data.put("category_id", createRequestBody(sessionManager.getSavedCateId()));
            data.put("size", createRequestBody(size_list_content.substring(0, size_list_content.length() - 1)));
            data.put("color", createRequestBody(color_list_content.substring(0, color_list_content.length() - 1)));
            data.put("brand_id", createRequestBody(sessionManager.getBrand()));
            data.put("condition_id", createRequestBody(sessionManager.getCondition()));
            data.put("price", createRequestBody(sessionManager.getPrice()));
            data.put("in_draft", createRequestBody(itemvalue));
            data.put("action", createRequestBody("Update"));
            data.put("product_id", createRequestBody(pro_id));

           /* builder.addFormDataPart("user_id", sessionManager.getSavedUserid());
            builder.addFormDataPart("name", s_title);
            builder.addFormDataPart("description", s_desc);
            builder.addFormDataPart("category_id", sessionManager.getSavedCateId().toString());
            builder.addFormDataPart("size", size_list_content.substring(0, size_list_content.length() - 1));
            builder.addFormDataPart("color",  color_list_content.substring(0, color_list_content.length() - 1));
            builder.addFormDataPart("brand_id",sessionManager.getBrand().toString());
            builder.addFormDataPart("condition_id", sessionManager.getCondition().toString());
            builder.addFormDataPart("price", sessionManager.getPrice().toString());
            builder.addFormDataPart("in_draft", itemvalue);
            builder.addFormDataPart("action", "Add");
*/
            List<MultipartBody.Part> partList = new ArrayList<>();
            for (int i = 0; i < imageslist.size(); i++) {

                if (imageslist.get(i).getId().equals(""))
                {
                    File file = new File(imageslist.get(i).getPath());
                    RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"), file);
                    MultipartBody.Part part = MultipartBody.Part.createFormData("images[]",file.getName(),requestBody);
                    partList.add(part);
                }

            }

            Call<AddProductResponse> call = mAPIService.add_product(data,partList);
            call.enqueue(new Callback<AddProductResponse>() {
                @Override
                public void onResponse(Call<AddProductResponse> call, Response<AddProductResponse> response) {

                    Customprogress.showPopupProgressSpinner(context,false);

                    if(response.isSuccessful()) {
                        Customprogress.showPopupProgressSpinner(context, false);
                        boolean status = response.body().getStatus();
                        if (status == true) {
                            Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_LONG).show();
                          Intent intent  =new Intent(context,DashboardActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra("about","0");
                          startActivity(intent);
                            ClearData();

                        }
                        else{
                            Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }
                @Override
                public void onFailure(Call<AddProductResponse> call, Throwable t) {

                    Customprogress.showPopupProgressSpinner(context,false);

                    Toast.makeText(context, t.getMessage(), Toast.LENGTH_LONG).show();

                    Log.d("TAG >>>>>>>>>>>>", "Error " + t.getMessage());
                }
            });

        }catch (Exception e)
        {
            e.printStackTrace();
        }

    }
    //----------Adapter ------------------
    public class ImagesEditAdapter extends RecyclerView.Adapter<ImagesEditAdapter.ViewHolder> {
        private List<ProductDetailImage> data;
        private Context context;
        private ArrayList<String> files;
        public ImagesEditAdapter(Context context, List<ProductDetailImage> students, ArrayList<String> files) {
            this.data = students;
            this.context = context;
            this.files = files;

        }
        @Override
        public ImagesEditAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.grid_single, parent, false);

            ImagesEditAdapter.ViewHolder viewHolder = new ImagesEditAdapter.ViewHolder(itemLayoutView);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ImagesEditAdapter.ViewHolder viewHolder, final int position) {

           /* if (data.size()!=0)
            {
                for (int i=0;i<data.size();i++)
                {
                    if (position==i)
                    {
                        Picasso.get().load(Allurls.ImageURL+data.get(position).getPath()).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(viewHolder.grid_image);
                    }
                }
            }
            else {
                if (files.size()!=0){
                    for (int i=0;i<files.size();i++)
                    {
                        if (position==i)
                        {
                            Bitmap bmp = BitmapFactory.decodeFile(files.get(position));
                            viewHolder.grid_image.setImageBitmap(bmp);
                        }

                    }

                }
            }*/

           if (data.get(position).getId().equals(""))
           {
               Bitmap bmp = BitmapFactory.decodeFile(data.get(position).getPath());
               viewHolder.grid_image.setImageBitmap(bmp);
              }
           else {
               Picasso.get().load(Allurls.ImageURL+data.get(position).getPath()).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(viewHolder.grid_image);
           }

            viewHolder.imgcross.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

              if (data.get(position).getId().equals(""))
              {
                  imageslist.remove(position);
                  imagesEditAdapter = new ImagesEditAdapter(context,imageslist, files);
                  grid.setAdapter(imagesEditAdapter);
                  imagesEditAdapter.notifyDataSetChanged();

              }
              else {
                  sendPostProductImageDelete(data.get(position).getId());
              }
                }
            });


        }
        @Override
        public int getItemCount() {
            return data.size();
//            return data.size()+files.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public ImageView imgcross;
            public CircleImageView grid_image;

            public ViewHolder(View itemLayoutView) {
                super(itemLayoutView);

                imgcross = itemLayoutView.findViewById(R.id.imgcross);
                grid_image = itemLayoutView.findViewById(R.id.grid_image);
            }
        }
        public List<ProductDetailImage> getStudentist() {
            return data;
        }

    }

}