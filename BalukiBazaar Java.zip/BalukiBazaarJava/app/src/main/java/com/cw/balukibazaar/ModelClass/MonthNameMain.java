package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.ArrayList;

public class MonthNameMain implements Serializable {

   public boolean isclick ;
   public String monthname;
    private ArrayList<MonthSubMain> contestList = null;

    public MonthNameMain(boolean isclick, String monthname, ArrayList<MonthSubMain> contestList) {
        this.isclick = isclick;
        this.monthname = monthname;
        this.contestList = contestList;
    }

    public boolean isIsclick() {
        return isclick;
    }

    public void setIsclick(boolean isclick) {
        this.isclick = isclick;
    }

    public String getMonthname() {
        return monthname;
    }

    public void setMonthname(String monthname) {
        this.monthname = monthname;
    }

    public ArrayList<MonthSubMain> getContestList() {
        return contestList;
    }

    public void setContestList(ArrayList<MonthSubMain> contestList) {
        this.contestList = contestList;
    }
}
