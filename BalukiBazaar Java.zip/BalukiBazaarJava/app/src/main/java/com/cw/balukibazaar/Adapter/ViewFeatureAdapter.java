package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.ProductDetailActivity;
import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.ModelClass.HomeLatest;
import com.cw.balukibazaar.ModelClass.SearchDataFeatured;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Utils.RoundRectCornerImageView;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ViewFeatureAdapter extends RecyclerView.Adapter<ViewFeatureAdapter.ViewHolder> {
    private List<SearchDataFeatured> stList;
    private Context context;
    RemoveFavourite favourite;
    public ViewFeatureAdapter(Context context, List<SearchDataFeatured> students,RemoveFavourite favourite) {
        this.stList = students;
        this.context = context;
        this.favourite = favourite;

    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {

        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_features_items, parent,false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        viewHolder.txt_price.setText("€ "+stList.get(position).getPrice());
        viewHolder.txt_proname.setText(stList.get(position).getName());
        viewHolder.txt_sellername.setText(stList.get(position).getSellerdata().getName());

        Picasso.get().load(Allurls.ImageURL +stList.get(position).getImage()).error(R.drawable.progress_animation).placeholder( R.drawable.progress_animation ).into(viewHolder.img_product);
        Picasso.get().load(Allurls.ImageURL +stList.get(position).getSellerdata().getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(viewHolder.img_seller);

        String s_fav  = stList.get(position).getIsFavorite();
        //0 means no favourite and 1 means favourite
        if (s_fav.equals("0")) {
            viewHolder.img_fav.setBackground(context.getResources().getDrawable(R.drawable.ic_heartnotfill));
        } else {
            viewHolder.img_fav.setBackground(context.getResources().getDrawable(R.drawable.ic_heartcolorfill));
        }

        viewHolder.ll_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ProductDetailActivity.class);
                intent.putExtra("pro_id",stList.get(position).getId());
                context.startActivity(intent);
            }
        });

        viewHolder.img_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                favourite.getproduct_id(stList.get(position).getId());
            }
        });

    }

    @Override
    public int getItemCount() {
        return stList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txt_sellername,txt_proname,txt_price;
        RoundRectCornerImageView img_product;
        CircleImageView img_seller;
        ImageView img_fav;
        LinearLayout ll_item;
        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_sellername = itemLayoutView.findViewById(R.id.txt_sellername);
            txt_proname = itemLayoutView.findViewById(R.id.txt_proname);
            txt_price = itemLayoutView.findViewById(R.id.txt_price);
            img_product = itemLayoutView.findViewById(R.id.img_product);
            img_seller = itemLayoutView.findViewById(R.id.img_seller);
            img_fav = itemLayoutView.findViewById(R.id.img_fav);
            ll_item = itemLayoutView.findViewById(R.id.ll_item);

        }

    }

    public List<SearchDataFeatured> getStudentist() {
        return stList;
    }
}

