package com.cw.balukibazaar.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Adapter.ViewAllSoldAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.MyOrderResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class SoldFragment extends Fragment {

    ImageView iv_back,iv_notification;
    RecyclerView recyclerViewThings;
    Context context;
    ViewAllSoldAdapter mAdapter;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_sold, container, false);
        InitView(v);
        Click();

        if(Utils.isInternetConnected(context)) {

            sendPost();
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }


        return v;
    }
    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        iv_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }

    private void InitView(View v) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        recyclerViewThings = v.findViewById(R.id.recyclerViewThings);
        iv_back = v.findViewById(R.id.iv_back);
        iv_notification = v.findViewById(R.id.iv_notification);
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    public void sendPost() {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.viewmyorderlist(sessionManager.getSavedUserid(),"Sold").enqueue(new Callback<MyOrderResponse>() {
            @Override
            public void onResponse(Call<MyOrderResponse> call, Response<MyOrderResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status==true)
                    {
//                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();

                        recyclerViewThings.setHasFixedSize(true);
                        recyclerViewThings.setLayoutManager(new LinearLayoutManager(context));
                        mAdapter = new ViewAllSoldAdapter(context, response.body().getData());
                        recyclerViewThings.setAdapter(mAdapter);

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<MyOrderResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }

        });
    }

}