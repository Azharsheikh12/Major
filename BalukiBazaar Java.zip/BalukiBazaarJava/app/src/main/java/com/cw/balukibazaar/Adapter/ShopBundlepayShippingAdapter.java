package com.cw.balukibazaar.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.ShippingStatus;
import com.cw.balukibazaar.Interface.ShopBundleShappingData;
import com.cw.balukibazaar.ModelClass.ShippingData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;


public class ShopBundlepayShippingAdapter extends RecyclerView.Adapter<ShopBundlepayShippingAdapter.ViewHolder> {
    private List<ShippingData> data;
    private Context context;
    String action;
    ShopBundleShappingData shopBundleShappingData;
    private int selectedPosition = -1;
    String checkid="";
    public ShopBundlepayShippingAdapter(Context context, List<ShippingData> data, ShopBundleShappingData shopBundleShappingData) {
        this.context = context;
        this.data = data;
        this.shopBundleShappingData = shopBundleShappingData;
    }

    // Create new views
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_bundle_shipping, parent, false);

        ViewHolder viewHolder = new ViewHolder(itemLayoutView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

        ShippingData listdata = data.get(position);

        if (checkid.equalsIgnoreCase(data.get(position).getId())){
            viewHolder.cb_shipping.setChecked(true);
            shopBundleShappingData.getShopbundleshappingdata(data.get(position).getId(),data.get(position).getRate());
        }
        else {
            viewHolder.cb_shipping.setChecked(false);
        }

        viewHolder.txt_name.setText(listdata.getCarrierName());
        Picasso.get().load(Allurls.ImageURL + listdata.getLogo())
                .error(R.drawable.progress_animation)
                .placeholder(R.drawable.img_shipping)
                .into(viewHolder.img_pay);
//        viewHolder.cb_shipping.setChecked(selectedPosition == position);
       /* if(selectedPosition == position){
            viewHolder.cb_shipping.setChecked(true);
            shopBundleShappingData.getShopbundleshappingdata(data.get(position).getId(),data.get(position).getRate());
        }
        else{
            viewHolder.cb_shipping.setChecked(false);

        }*/

        viewHolder.cb_shipping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkid = data.get(position).getId();
                notifyDataSetChanged();
               /* if (viewHolder.cb_shipping.isChecked())
                {
                    if(selectedPosition == position){
                        selectedPosition = position;
                        viewHolder.cb_shipping.setChecked(false);
                    }
                    else{
                        selectedPosition = position;
                        viewHolder.cb_shipping.setChecked(true);
                    }
                }
                else {
                    if(selectedPosition == position){
                        selectedPosition = position;
                        viewHolder.cb_shipping.setChecked(false);
                    }
                    else{
                        selectedPosition = position;
                        viewHolder.cb_shipping.setChecked(true);
                    }
                }*/

            }
        });
    }

    // Return the size arraylist
    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_name;
        public ImageView img_pay;
        public CheckBox cb_shipping;


        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);
            txt_name = itemLayoutView.findViewById(R.id.txt_name);
            img_pay = itemLayoutView.findViewById(R.id.img_pay);
            cb_shipping = itemLayoutView.findViewById(R.id.cb_shipping);
        }

    }


}

