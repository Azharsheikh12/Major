package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Activity.AddFeatureActivity;
import com.cw.balukibazaar.Activity.ViewShopBundleActivity;
import com.cw.balukibazaar.Adapter.MyAdapter;
import com.cw.balukibazaar.Adapter.ViewLatestAdapter;
import com.cw.balukibazaar.Adapter.ViewShopsAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.ViewDiscountListData;
import com.cw.balukibazaar.ModelClass.ViewFeatureInfoData;
import com.cw.balukibazaar.ModelClass.ViewFeatureInfoResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileData;
import com.cw.balukibazaar.ModelClass.ViewProfileResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShopFragment extends Fragment {
    ViewProfileData viewProfileData;
    String seller_id,user_id;
    SessionManager sessionManager;
    Button btn_shop_bundle;
    Context context;
    RecyclerView recyclerViewProducts;
    private ViewShopsAdapter latestAdapter;
    LinearLayout layout_bump_pro;
    ImageView img_info;
    private JsonPlaceHolderApi mAPIService;
    ArrayList<ViewFeatureInfoData> datalist;
    private ViewBannerAdapter mAdapter;
    public ShopFragment(ViewProfileData viewProfileData, String sellerId, String user_id) {
        this.viewProfileData = viewProfileData;
        this.seller_id = sellerId;
        this.user_id = user_id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_shop, container, false);
        InitView(v);
        Click();

        if (sessionManager.getSavedUserid().equals(seller_id))
        {
            btn_shop_bundle.setVisibility(View.GONE);
            layout_bump_pro.setVisibility(View.VISIBLE);
        }
        else {
            layout_bump_pro.setVisibility(View.GONE);
            btn_shop_bundle.setVisibility(View.VISIBLE);
            btn_shop_bundle.setText("Up to "+viewProfileData.getDisPercent()+"% OFF bundles");
        }
        if(Utils.isInternetConnected(context)) {

            try {
                sendPost();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }
        recyclerViewProducts.setLayoutManager(new GridLayoutManager(getActivity(), 2, GridLayoutManager.VERTICAL, false));
        recyclerViewProducts.setHasFixedSize(true);
        latestAdapter = new ViewShopsAdapter(getActivity(),viewProfileData.getShop(),viewProfileData);
        recyclerViewProducts.setAdapter(latestAdapter);

        return v;
    }

    private void Click() {
        btn_shop_bundle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(context, ViewShopBundleActivity.class);
                intent.putExtra("user_id",user_id);
                intent.putExtra("seller_id",seller_id);
                startActivity(intent);
            }
        });

        layout_bump_pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AddFeatureActivity.class);
                intent.putExtra("infodata", datalist);
                intent.putExtra("user_id",user_id);
                intent.putExtra("seller_id",seller_id);
                startActivity(intent);

            }
        });

        img_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createDialogupdate(context,datalist);
            }
        });

    }

    private void InitView(View v) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        btn_shop_bundle = v.findViewById(R.id.btn_shop_bundle);
        recyclerViewProducts = v.findViewById(R.id.recyclerViewProducts);
        layout_bump_pro = v.findViewById(R.id.layout_bump_pro);
        img_info = v.findViewById(R.id.img_info);
    }
    public void sendPost() throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.viewfeatureplan(sessionManager.getSavedUserid()).enqueue(new Callback<ViewFeatureInfoResponse>() {
            @Override
            public void onResponse(Call<ViewFeatureInfoResponse> call, Response<ViewFeatureInfoResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        datalist = response.body().getData();
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ViewFeatureInfoResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }
    private void createDialogupdate(Context context,  List<ViewFeatureInfoData> datalist) {
        final Dialog dialog = new Dialog(context);

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // before
        dialog.setContentView(R.layout.dialog_viewfeatures);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        RecyclerView recycler_features = dialog.findViewById(R.id.recycler_features);
        ImageView img_close = dialog.findViewById(R.id.img_close);

        recycler_features.setHasFixedSize(true);
        recycler_features.setLayoutManager(new LinearLayoutManager(context));
        mAdapter = new ViewBannerAdapter(context, datalist);
        recycler_features.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();

        img_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }
    public class ViewBannerAdapter extends RecyclerView.Adapter<ViewBannerAdapter.ViewHolder> {
        private List<ViewFeatureInfoData> stList;
        private Context context;

        public ViewBannerAdapter(Context context, List<ViewFeatureInfoData> students) {
            this.stList = students;
            this.context = context;

        }
        @Override
        public ViewBannerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_viewfeatures, parent,false);

            ViewBannerAdapter.ViewHolder viewHolder = new ViewBannerAdapter.ViewHolder(itemLayoutView);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ViewBannerAdapter.ViewHolder viewHolder, final int position) {

            viewHolder.txt_itemcount.setText(stList.get(position).getQuantity()+" items");
            viewHolder.txt_itemprice.setText("€ "+stList.get(position).getRate());


        }
        @Override
        public int getItemCount() {
            return stList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            public TextView txt_itemcount,txt_itemprice;


            public ViewHolder(View itemLayoutView) {
                super(itemLayoutView);
                txt_itemcount = itemLayoutView.findViewById(R.id.txt_itemcount);
                txt_itemprice = itemLayoutView.findViewById(R.id.txt_itemprice);
            }
        }
        public List<ViewFeatureInfoData> getStudentist() {
            return stList;
        }

    }
}