package com.cw.balukibazaar.Interface;

public interface SortFilter {
    void getsortname(String name);
}
