package com.cw.balukibazaar.Utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.cw.balukibazaar.ModelClass.ProductDetailData;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class SessionManager {
    private SharedPreferences pref;
    private Editor editor;
    private Context context;
    private int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "login";
    private static final String KEY_USER_NAME = "userName";
    private static final String KEY_TOKEN = "token";
    private static final String KEY_USERID = "userid";
    private static final String KEY_IS_LOGIN = "isLogin";
    private static final String KEY_FCM_TOKEN = "fcmtoken";
    private static final String KEY_DEVICE_ID = "deviceid";
    private static final String KEY_FCM_TOKEN_ID = "fcmtokenid";
    private static final String KEY_USER_MOBILE = "usermobile";
    private static final String KEY_USER_EMAIL = "useremail";
    private static final String KEY_LOGIN_TOKEN = "logintoken";
    private static final String KEY_CATEGORYID = "categoryid";

    private static final String KEY_SIZE = "size";
    private static final String KEY_PRODUCT_LIST = "productlist";
    private static final String KEY_COLOR = "color";
    private static final String KEY_BRAND = "brand";
    private static final String KEY_CONDITION = "condition";
    private static final String KEY_PRICE = "price";


    public void setProductList(ArrayList<ProductDetailData> list){
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(KEY_PRODUCT_LIST, json);
        editor.commit();
        editor.apply();
    }

    public ArrayList<ProductDetailData> getProductList(){
        ArrayList<ProductDetailData> arrayItems = new ArrayList<>();
        String serializedObject = pref.getString(KEY_PRODUCT_LIST, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<ProductDetailData>>(){}.getType();
            arrayItems = gson.fromJson(serializedObject, type);
        }
        return arrayItems;
    }

    public void saveSizeList(ArrayList<String> list){
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(KEY_SIZE, json);
        editor.commit();
        editor.apply();
    }

    public ArrayList<String> getSizeList(){
        ArrayList<String> arrayItems = new ArrayList<>();
        String serializedObject = pref.getString(KEY_SIZE, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<String>>(){}.getType();
            arrayItems = gson.fromJson(serializedObject, type);
        }
        return arrayItems;
    }

    public void saveColorList(ArrayList<String> list){
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString(KEY_COLOR, json);
        editor.commit();
        editor.apply();
    }

    public ArrayList<String> getColorList(){
        ArrayList<String> arrayItems = new ArrayList<>();
        String serializedObject = pref.getString(KEY_COLOR, null);
        if (serializedObject != null) {
            Gson gson = new Gson();
            Type type = new TypeToken<ArrayList<String>>(){}.getType();
            arrayItems = gson.fromJson(serializedObject, type);
        }
        return arrayItems;
    }

    public void saveBrand(String str) {
        editor.putString(KEY_BRAND, str);
        editor.commit();
    }


    public String getBrand() {
        return pref.getString(KEY_BRAND, "");
    }


    public void saveCondition(String str) {
        editor.putString(KEY_CONDITION, str);
        editor.commit();
    }

    public String getCondition() {
        return pref.getString(KEY_CONDITION, "");
    }


    public void savePrice(String str) {
        editor.putString(KEY_PRICE, str);
        editor.commit();
    }

    public String getPrice() {
        return pref.getString(KEY_PRICE, "");
    }

    // Constructor
    @SuppressLint("CommitPrefEdits")
    public SessionManager(Context context) {
        this.context = context;
        pref = this.context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }


    public void setSavedCateId(String userid) {
        editor.putString(KEY_CATEGORYID, userid);
        editor.commit();
    }


    public String getSavedCateId() {
        return pref.getString(KEY_CATEGORYID, "");
    }


    public void setSavedUserMobile(String userid) {
        editor.putString(KEY_USER_MOBILE, userid);
        editor.commit();
    }


    public String getSavedUserMobile() {
        return pref.getString(KEY_USER_MOBILE, "");
    }


    public void setSavedLoginToken(String userid) {
        editor.putString(KEY_LOGIN_TOKEN, userid);
        editor.commit();
    }


    public String getSavedLoginToken() {
        return pref.getString(KEY_LOGIN_TOKEN, "");
    }





    public void setSavedUserEmail(String userid) {
        editor.putString(KEY_USER_EMAIL, userid);
        editor.commit();
    }


    public String getSavedUserEmail() {
        return pref.getString(KEY_USER_EMAIL, "");
    }


    public void setSavedFcmTokenId(Integer userid) {
        editor.putInt(KEY_FCM_TOKEN_ID, userid);
        editor.commit();
    }


    public Integer getSavedFcmTokenId() {
        return pref.getInt(KEY_FCM_TOKEN_ID, 0);
    }



    public void setSavedDeviceid(String userid) {
        editor.putString(KEY_DEVICE_ID, userid);
        editor.commit();
    }


    public String getSavedStringDeviceid() {
        return pref.getString(KEY_DEVICE_ID, "");
    }

    public void setSavedFcmtoken(String userid) {
        editor.putString(KEY_FCM_TOKEN, userid);
        editor.commit();
    }


    public String getSavedStringFcmtoken() {
        return pref.getString(KEY_FCM_TOKEN, "");
    }




    //-----------------------------------USERID-------------------------------------------

    //save user name to SharedPref
    public void setSavedUserid(String userid) {
        editor.putString(KEY_USERID, userid);
        editor.commit();
    }

    //retrieve username frome pref
    public String getSavedUserid() {
        return pref.getString(KEY_USERID,"");
    }


    //-----------------------------------TOKEN-------------------------------------------

    //save user name to SharedPref
    public void setSavedToken(String token) {
        editor.putString(KEY_TOKEN, token);
        editor.commit();
    }

    //retrieve username frome pref
    public String getSavedToken() {
        return pref.getString(KEY_TOKEN, "");
    }



    //-----------------------------------------------------------------------------------







    //save user name to SharedPref
    public void setSavedUserName(String userName) {
        editor.putString(KEY_USER_NAME, userName);
        editor.commit();
    }

    //retrieve username frome pref
    public String getSavedUserName() {
        return pref.getString(KEY_USER_NAME, "");
    }


    public boolean isUserLogin() {
        return pref.getBoolean(KEY_IS_LOGIN, false);
    }

    public void setUserLoggedIn(boolean isLogin) {
        editor.putBoolean(KEY_IS_LOGIN, isLogin);
        editor.commit();
    }

    public void clearSession() {
        editor.clear();
        editor.commit();
    }
}
