package com.cw.balukibazaar.Adapter;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Activity.ProductDetailActivity;
import com.cw.balukibazaar.Fragment.MywalletFragment;
import com.cw.balukibazaar.Fragment.PurchasedItemDetailsFragment;
import com.cw.balukibazaar.ModelClass.MyOrderData;
import com.cw.balukibazaar.ModelClass.MyOrderDetail;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.squareup.picasso.Picasso;

import java.util.List;


public class PurchaseItemSoldDetailsAdapter extends RecyclerView.Adapter<PurchaseItemSoldDetailsAdapter.ViewHolder> {
   List<MyOrderDetail> detail;
    private Context context;
    Fragment fragment = null;

    public PurchaseItemSoldDetailsAdapter(Context context, List<MyOrderDetail> detail) {
        this.context = context;
        this.detail = detail;


    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

//        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_users, null);
        View itemLayoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_items_sold_details, parent, false);
        ViewHolder viewHolder = new ViewHolder(itemLayoutView);
        //ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(context));

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int position) {

        viewHolder.txt_pro_name.setText(detail.get(position).getProductName());
        viewHolder.txt_pro_add.setText(detail.get(position).getPrice());
        Picasso.get().load(Allurls.ImageURL+detail.get(position).getImage()).placeholder(R.drawable.progress_animation).error(R.drawable.progress_animation).into(viewHolder.iv_profile);

        viewHolder.ll_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putSerializable("data", detail.get(position));
                AppCompatActivity activity = (AppCompatActivity) context;
                PurchasedItemDetailsFragment newFragment = new PurchasedItemDetailsFragment();
                newFragment.setArguments(bundle);
                FragmentTransaction transaction =  activity.getSupportFragmentManager().beginTransaction();
                transaction.replace(R.id.fragment_container, newFragment);
                transaction.addToBackStack("add");
                transaction.commit();
            }
        });
    }
    @Override
    public int getItemCount() {
//        return 10;
        return detail.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_pro_add, txt_pro_name;
        public LinearLayout ll_main;
        public ImageView iv_profile;

        public ViewHolder(View itemLayoutView) {
            super(itemLayoutView);

            txt_pro_add = itemLayoutView.findViewById(R.id.txt_pro_add);
            txt_pro_name = itemLayoutView.findViewById(R.id.txt_pro_name);
            iv_profile = itemLayoutView.findViewById(R.id.iv_profile);
            ll_main = itemLayoutView.findViewById(R.id.ll_main);
        }
    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            ((Activity)context).getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

}

