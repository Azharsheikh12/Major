package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.cw.balukibazaar.Activity.ViewInterstedListActivity;
import com.cw.balukibazaar.R;

public class ViewInterstsFragment extends Fragment {
    ImageView iv_back,iv_notification;
    Activity context;
    TextView txt_cate,txt_brand;
    LinearLayout layout_brand,layout_category;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v = inflater.inflate(R.layout.fragment_view_intersts, container, false);
       InitView(v);
       Click();
       return v;
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.onBackPressed();
            }
        });
        layout_category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ViewInterstedListActivity.class);
                intent.putExtra("data",txt_cate.getText().toString().trim());
                startActivity(intent);
            }
        });

        layout_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ViewInterstedListActivity.class);
                intent.putExtra("data",txt_brand.getText().toString().trim());
                startActivity(intent);
            }
        });

        iv_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });

    }

    private void InitView(View v) {
        context = getActivity();
        iv_back = v.findViewById(R.id.iv_back);
        layout_brand = v.findViewById(R.id.layout_brand);
        layout_category = v.findViewById(R.id.layout_category);
        txt_cate = v.findViewById(R.id.txt_cate);
        txt_brand = v.findViewById(R.id.txt_brand);
        iv_notification = v.findViewById(R.id.iv_notification);
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }


}