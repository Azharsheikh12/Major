package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.ViewInterstedBrandAdapter;
import com.cw.balukibazaar.Adapter.ViewInterstedCategoryAdapter;
import com.cw.balukibazaar.Adapter.ViewallFavouriteAdapter;
import com.cw.balukibazaar.Interface.ColorFilter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.ModelClass.AddInterstedResponse;
import com.cw.balukibazaar.ModelClass.GlobalBrandResponse;
import com.cw.balukibazaar.ModelClass.GlobalCategoryResponse;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.ViewInterestedData;
import com.cw.balukibazaar.ModelClass.ViewInterestedDataResponse;
import com.cw.balukibazaar.ModelClass.favourate.FavouriteResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ViewInterstedListActivity extends AppCompatActivity {

    String data,CategoryMain="",type;
    Button btn_submit;
    ImageView iv_back;
    TextView txt_name;
    Context context;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    RecyclerView recyclerViewProducts;
    ViewInterstedCategoryAdapter categoryAdapter;
    ViewInterstedBrandAdapter brandAdapter;
    List<ViewInterestedData> viewInterestedData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_intersted_list);
       InitView();
        try {
            Intent intent = getIntent();
            if (intent!=null){
                data = intent.getStringExtra("data");
                System.out.println("intersted data >>>>>"+data);

                txt_name.setText("View "+data);


                if (data.equals("Category"))
                {
                    type = "Category";
                    viewInterestedData = new ArrayList<>();
                    ViewInterstedList(type);
                }
                else {
                    type = "Brand";
                    viewInterestedData = new ArrayList<>();
                    ViewInterstedList(type);
                }



            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
        Click();
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (CategoryMain.equals("")){
                    CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select));
                }
                else {
                    if (Utils.isInternetConnected(context)) {
                        AddInterestedData(type,CategoryMain);
                    } else {
                        CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                    }
                }
            }
        });
    }

    private void InitView() {
        context = ViewInterstedListActivity.this;
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        iv_back = findViewById(R.id.iv_back);
        txt_name = findViewById(R.id.txt_name);
        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        btn_submit = findViewById(R.id.btn_submit);
    }

    public void ViewCategorylist()
    {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.getcategorylist().enqueue(new Callback<GlobalCategoryResponse>() {
            @Override
            public void onResponse(Call<GlobalCategoryResponse> call, Response<GlobalCategoryResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();
                    if (status == true)
                    {
                        recyclerViewProducts.setHasFixedSize(true);
                        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(context));
                        categoryAdapter = new ViewInterstedCategoryAdapter(context, response.body().getData(), new ColorFilter() {
                            @Override
                            public void getColorid(String cateid)
                            {
                                System.out.println("intersted id >>>>>>>>"+cateid);
                                CategoryMain = method(cateid);
                            }
                        },viewInterestedData);
                        recyclerViewProducts.setAdapter(categoryAdapter);

                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<GlobalCategoryResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", ""+t.getMessage());
            }

        });
    }
    public void ViewBrandlist() {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.getbrandlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalBrandResponse>() {
            @Override
            public void onResponse(Call<GlobalBrandResponse> call, Response<GlobalBrandResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);
                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();
                    if (status == true)
                    {
                        recyclerViewProducts.setHasFixedSize(true);
                        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(context));
                        brandAdapter = new ViewInterstedBrandAdapter(context,response.body().getData(), new ColorFilter() {
                            @Override
                            public void getColorid(String cateid) {
                                System.out.println("intersted id >>>>>>>>"+cateid);
                                CategoryMain = method(cateid);

                            }
                        },viewInterestedData);
                        recyclerViewProducts.setAdapter(brandAdapter);

                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<GlobalBrandResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", ""+t.getMessage());
            }

        });
    }

    public void ViewInterstedList(String type) {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.viewintresteddata(sessionManager.getSavedUserid(),type).enqueue(new Callback<ViewInterestedDataResponse>() {
            @Override
            public void onResponse(Call<ViewInterestedDataResponse> call, Response<ViewInterestedDataResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();
                    if (status == true)
                    {
                        viewInterestedData = response.body().getData();
                        if (type.equals("Category"))
                        {
                            if (Utils.isInternetConnected(context)) {

                                ViewCategorylist();

                            } else {
                                CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                            }
                        }
                        else {
                            if (Utils.isInternetConnected(context)) {
                                ViewBrandlist();

                            } else {
                                CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                            }
                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<ViewInterestedDataResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void AddInterestedData(String type,String dataid)
    {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.addinteresteddata(sessionManager.getSavedUserid(),type,dataid).enqueue(new Callback<AddInterstedResponse>() {
            @Override
            public void onResponse(Call<AddInterstedResponse> call, Response<AddInterstedResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();
                    if (status == true)
                    {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();

                    } else
                        {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<AddInterstedResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", ""+t.getMessage());
            }

        });
    }

    public String method(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }
}