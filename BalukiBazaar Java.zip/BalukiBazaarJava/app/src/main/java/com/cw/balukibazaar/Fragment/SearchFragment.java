package com.cw.balukibazaar.Fragment;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.ViewCategoryAdapter;
import com.cw.balukibazaar.Adapter.ViewFeatureAdapter;
import com.cw.balukibazaar.Adapter.ViewSearchOtherAdapter;
import com.cw.balukibazaar.Adapter.ViewShopBundleAdapter;
import com.cw.balukibazaar.Adapter.ViewThingsWeLoveAdapter;
import com.cw.balukibazaar.BottomSheet.FilterBottomSheetFragment;
import com.cw.balukibazaar.BottomSheet.SortByBottomSheetFragment;
import com.cw.balukibazaar.Interface.CategoryFilter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.MainFilter;
import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.Interface.ShopBundleData;
import com.cw.balukibazaar.Interface.SortFilter;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.HomeDataWeLove;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.SearchDataData;
import com.cw.balukibazaar.ModelClass.SearchDataFeatured;
import com.cw.balukibazaar.ModelClass.SearchDataOther;
import com.cw.balukibazaar.ModelClass.SearchDataResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchFragment extends Fragment {

    RecyclerView recyclerViewProducts,recyclerViewFeature;
    private ViewFeatureAdapter viewFeatureAdapter;
    private ViewSearchOtherAdapter searchOtherAdapter;
    LinearLayoutManager HorizontalLayout;
    List<String> sortList;
    List<String> filterList;
    LinearLayout ll_sort,ll_filter;
    Context context;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_search,img_notic;
    EditText edt_search;
    String s_search,user_id;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_search, container, false);
        InitView(v);
        sortList = new ArrayList<>();
//        sortList.add("Relevance");
        sortList.add("Most Popular");
        sortList.add("Newly listed");

        filterList = new ArrayList<>();
        filterList.add("Category");
        filterList.add("Size");
        filterList.add("Color");
        filterList.add("Brand");
        filterList.add("Price");
        filterList.add("Condition");
        Click();

        if (sessionManager.isUserLogin())
        {
            if(Utils.isInternetConnected(context)) {

                try {
                    user_id = sessionManager.getSavedUserid();
                    sendPostDefault(user_id);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
            }
        }
        else {
            if(Utils.isInternetConnected(context)) {

                try {
                    user_id ="0";
                    sendPostDefault(user_id);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            else {
                CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
            }
        }


        return v;
    }

    private void Click() {
        ll_sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SortByBottomSheetFragment sortByBottomSheetFragment = new SortByBottomSheetFragment(context,sortList, new SortFilter() {
                    @Override
                    public void getsortname(String name) {
                        System.out.println("sort data >>>>>>>>"+name);
                        if (name.equals("")){
                            CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select));
                        }
                        else if (name.equals("Newly listed")){

                            String parameter = "newlist";
                            String value = "new";

                            try {
                                sendPostSort(user_id,parameter,value);
                            }catch (Exception e)
                            {
                                e.printStackTrace();
                            }

                        }
                        else if (name.equals("Most Popular")){

                            String parameter = "popular";
                            String value = "popular";
                            try {
                                sendPostSort(user_id,parameter,value);
                            }catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                });
                sortByBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });
        ll_filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FilterBottomSheetFragment sortByBottomSheetFragment = new FilterBottomSheetFragment(context,filterList, new MainFilter() {
                    @Override
                    public void getMainid(String cateid, String sizeid, String colorid, String brandid, String minprice, String maxprice, String conditionid) {

                        try {
                            sendPostFilter(cateid,method(sizeid),method(colorid),brandid,maxprice,minprice,conditionid);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
                sortByBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
            }
        });
        img_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_search = edt_search.getText().toString().trim();
                if (!s_search.isEmpty()){
                    if (sessionManager.isUserLogin())
                    {
                        if(Utils.isInternetConnected(context)) {

                            try {
                                sendPostSearch(sessionManager.getSavedUserid(),s_search);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                        }
                    }
                    else {
                        if(Utils.isInternetConnected(context)) {

                            try {
                                sendPostSearch("0",s_search);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                        }
                    }
                }
            }
        });
        img_notic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    public String method(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }

    private void InitView(View v) {
        context = getActivity();
        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(context);
        recyclerViewProducts = v.findViewById(R.id.recyclerViewProducts);
        recyclerViewFeature = v.findViewById(R.id.recyclerViewFeature);
        ll_sort = v.findViewById(R.id.ll_sort);
        ll_filter = v.findViewById(R.id.ll_filter);
        img_search = v.findViewById(R.id.img_search);
        edt_search = v.findViewById(R.id.edt_search);
        img_notic = v.findViewById(R.id.img_notic);
    }

    public void sendPostDefault(String user_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.viewsearchdata(user_id,"").enqueue(new Callback<SearchDataResponse>() {
            @Override
            public void onResponse(Call<SearchDataResponse> call, Response<SearchDataResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        ViewFeatureData(response.body().getData().getFeatured());
                        ViewOtherData(response.body().getData().getOthers(),response.body().getData());


                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<SearchDataResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostFilter(String MainCateid,String MainSizeid,String MainColorid,String MainBrandid,String MainMaxprice,String MainMinprice,String MainConditionid) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.filtersearchdata(user_id,MainCateid,MainBrandid,MainSizeid,MainColorid,MainConditionid,MainMinprice,MainMaxprice).enqueue(new Callback<SearchDataResponse>() {
            @Override
            public void onResponse(Call<SearchDataResponse> call, Response<SearchDataResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        ViewFeatureData(response.body().getData().getFeatured());
                        ViewOtherData(response.body().getData().getOthers(),response.body().getData());


                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<SearchDataResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostSearch(String user_id,String search) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.viewsearchdata(user_id,search).enqueue(new Callback<SearchDataResponse>() {
            @Override
            public void onResponse(Call<SearchDataResponse> call, Response<SearchDataResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        edt_search.setText("");
                        ViewFeatureData(response.body().getData().getFeatured());
                        ViewOtherData(response.body().getData().getOthers(),response.body().getData());
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<SearchDataResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostSort(String user_id,String parameter, String value) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);
        HashMap<String, RequestBody> data = new HashMap<>();
        data.put(parameter, createRequestBody(value));
        data.put("user_id", createRequestBody(user_id));
        mAPIService.sortsearchdata(data).enqueue(new Callback<SearchDataResponse>() {
            @Override
            public void onResponse(Call<SearchDataResponse> call, Response<SearchDataResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        ViewFeatureData(response.body().getData().getFeatured());
                        ViewOtherData(response.body().getData().getOthers(),response.body().getData());


                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<SearchDataResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    private void ViewOtherData(List<SearchDataOther> others, SearchDataData data) {

        recyclerViewProducts.setLayoutManager(new GridLayoutManager(context, 2, GridLayoutManager.VERTICAL, false));
        recyclerViewProducts.setHasFixedSize(true);
        searchOtherAdapter = new ViewSearchOtherAdapter(context, others, data, new RemoveFavourite() {
            @Override
            public void getproduct_id(String product_id) {
                sendPostFav(product_id);
            }
        });
        recyclerViewProducts.setAdapter(searchOtherAdapter);

    }

    private void ViewFeatureData(List<SearchDataFeatured> featured) {
        HorizontalLayout = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        recyclerViewFeature.setLayoutManager(HorizontalLayout);
        recyclerViewFeature.setHasFixedSize(true);
        viewFeatureAdapter = new ViewFeatureAdapter(getActivity(), featured, new RemoveFavourite() {
            @Override
            public void getproduct_id(String product_id) {
                sendPostFav(product_id);
            }
        });
        recyclerViewFeature.setAdapter(viewFeatureAdapter);

    }

    public RequestBody createRequestBody(@NonNull String s) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), s);
    }
    public void sendPostFav(String product_id) {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.addremovefavourite(user_id, product_id).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if (Utils.isInternetConnected(context)) {
                            try {
                                sendPostDefault(user_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
//                            favouritelist();
                        } else {
                            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "" + t.getMessage());
            }
        });
    }
}