package com.cw.balukibazaar.Utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Convertyymmddtoddmmyy {

    public static String dateconvert(String date1)
    {
        try {


            DateFormat srcDf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

            // parse the date string into Date object
            Date date = srcDf.parse(date1);

            DateFormat destDf = new SimpleDateFormat("yyyy-MM-dd");

            // format the date into another format
            date1 = destDf.format(date);


        }
        catch (ParseException e) {
            e.printStackTrace();
        }
        return date1;
    }
}
