package com.cw.balukibazaar.Adapter;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.cw.balukibazaar.Fragment.AboutFragment;
import com.cw.balukibazaar.Fragment.ReviewsFragment;
import com.cw.balukibazaar.Fragment.ShopFragment;
import com.cw.balukibazaar.ModelClass.ViewProfileData;

public class MyAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;
    ViewProfileData viewProfileData;
    String seller_id,user_id;

    public MyAdapter(Context context, FragmentManager fm, int totalTabs, ViewProfileData viewProfileData, String sellerId, String user_id) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
        this.viewProfileData = viewProfileData;
        this.seller_id = sellerId;
        this.user_id = user_id;
    }

    // this is for fragment tabs
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                ShopFragment homeFragment = new ShopFragment(viewProfileData,seller_id,user_id);
                return homeFragment;
            case 1:
                ReviewsFragment sportFragment = new ReviewsFragment(viewProfileData.getReview());
                return sportFragment;
            case 2:
                AboutFragment movieFragment = new AboutFragment(viewProfileData.getAbout(),seller_id);
                return movieFragment;
            default:
                return null;
        }
    }
    // this counts total number of tabs
    @Override
    public int getCount() {
        return totalTabs;
    }
}
