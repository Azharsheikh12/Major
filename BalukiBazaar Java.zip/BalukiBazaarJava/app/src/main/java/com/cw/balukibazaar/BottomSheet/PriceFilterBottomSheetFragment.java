package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.cw.balukibazaar.Interface.PriceFilter;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;


public class PriceFilterBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    ImageView iv_close,iv_back;
    EditText edt_max,edt_min;
    Button btn_apply;
    SessionManager sessionManager;
    String str_price;
    Context context;
    LinearLayout rl_main;
    PriceFilter priceFilter;
    public PriceFilterBottomSheetFragment(Context context, PriceFilter priceFilter) {
        this.context = context;
        this.priceFilter = priceFilter;
    }

    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_price_filter, container, false);
        findIds(view);

        return view;

    }
    public void findIds(View v) {
        sessionManager=new  SessionManager(context);
//        sessionManager.savePrice("");
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        btn_apply= v.findViewById(R.id.btn_apply);
        btn_apply.setOnClickListener(this);
        edt_max= v.findViewById(R.id.edt_max);
        edt_min= v.findViewById(R.id.edt_min);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                dismissAllowingStateLoss();
                break;
            case  R.id.btn_apply:
                String minprice = edt_min.getText().toString().trim();
                String maxprice = edt_max.getText().toString().trim();
                priceFilter.getprices(minprice,maxprice);
               dismissAllowingStateLoss();
            break;
        }
    }

}