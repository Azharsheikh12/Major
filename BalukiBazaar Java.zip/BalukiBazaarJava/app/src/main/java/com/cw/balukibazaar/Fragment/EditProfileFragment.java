package com.cw.balukibazaar.Fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.cw.balukibazaar.Activity.DashboardActivity;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.editprofile.EditProfileResponse;
import com.cw.balukibazaar.ModelClass.profileshow.ProfileShowResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.DialogUtility;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.io.File;
import java.util.HashMap;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.cw.balukibazaar.Utils.ManifestPermission.hasPermissions;

/**
 * A simple {@link Fragment} subclass.
 * Use the  factory method to
 * create an instance of this fragment.
 */
public class EditProfileFragment extends Fragment implements View.OnClickListener {

    final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 1;
    int count = 0;
    private String[] PERMISSIONS = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CAMERA
    };
    public static final int PERMISSION_ALL = 101;
    ImageView img_profile,iv_back;
    EditText edt_name, edt_street, edt_country, edt_city, edt_zip_code, edt_about, edt_email;
    TextView txt_update,txt_username;
    Context context;
    String picturePath, name, email, city, country, zipcode, street, about;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_edit_profile, container, false);
        init(view);
        return view;
    }
    private void init(View view) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        edt_name = view.findViewById(R.id.edt_name);
        edt_email = view.findViewById(R.id.edt_email);
        edt_street = view.findViewById(R.id.edt_street);
        edt_city = view.findViewById(R.id.edt_city);
        edt_country = view.findViewById(R.id.edt_country);
        edt_zip_code = view.findViewById(R.id.edt_zip_code);
        edt_about = view.findViewById(R.id.edt_about);
        txt_username = view.findViewById(R.id.txt_username);
        iv_back = view.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);

        txt_update = view.findViewById(R.id.txt_update);
        txt_update.setOnClickListener(this);

        img_profile = view.findViewById(R.id.img_profile);
        img_profile.setOnClickListener(this);

        if (Utils.isInternetConnected(context)) {

            profile();
        } else {
            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
        }

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_profile:
                if (!hasPermissions(context, PERMISSIONS)) {
                    ActivityCompat.requestPermissions(getActivity(), PERMISSIONS, REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
                } else {
                    if (selectImage()) {
                        CropImage.activity().start(getContext(), this);
                    }
                }

                break;

            case R.id.txt_update:
                if (Utils.isInternetConnected(context)) {
                    if (isValid()) {
                        editprofile();
                    }
                } else {
                    CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                }
                break;
            case R.id.iv_back:
                getActivity().onBackPressed();
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean selectImage() {
        boolean isPermission = false;
        if (!hasPermissions(context, PERMISSIONS)) {
            boolean showRationale = shouldShowRequestPermissionRationale(Manifest.permission.CAMERA);
            if (!showRationale) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", context.getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            } else {
                ActivityCompat.requestPermissions(getActivity(), PERMISSIONS, PERMISSION_ALL);
            }
        } else {
            isPermission = true;

        }

        return isPermission;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS) {
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++) {

                    if (permissions[i].equals(Manifest.permission.CAMERA)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            Log.e("msg", "<--accounts granted");
                            count++;
                        } else {
                            DialogUtility.showToast(context, "Permission is required. ");
                        }
                    } else if (permissions[i].equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            Log.e("msg", "<--read phone granted");
                            count++;
                        } else {
                            DialogUtility.showToast(context, "Permission is required...");
                        }
                    } else if (permissions[i].equals(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            Log.e("msg", "<--read phone granted");
                            count++;
                        } else {
                            DialogUtility.showToast(context, "Permission is required...");
                        }
                    }
                }
            }

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            img_profile.setImageURI(result.getUri());
            picturePath = result.getUri().getPath();

        }
    }

    public void profile() {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.getprofile(sessionManager.getSavedUserid(), sessionManager.getSavedUserid()).enqueue(new Callback<ProfileShowResponse>() {
            @Override
            public void onResponse(Call<ProfileShowResponse> call, Response<ProfileShowResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        if (response.body().getStatus()) {
                            ProfileShowResponse profileRes = response.body();
                            edt_name.setText(profileRes.getData().getName());
                            edt_email.setText(profileRes.getData().getEmail());
                            edt_street.setText(profileRes.getData().getStreet());
                            edt_city.setText(profileRes.getData().getCity());
                            edt_country.setText(profileRes.getData().getCountry()+"");
                            edt_zip_code.setText(profileRes.getData().getZipcode());
                            edt_about.setText(profileRes.getData().getAbout());
                            txt_username.setText(profileRes.getData().getSellername());
                            Picasso.get().load(Allurls.ImageURL + profileRes.getData().getProfile())
                                    .error(R.drawable.progress_animation)
                                    .placeholder(R.drawable.progress_animation)
                                    .into(img_profile);

                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProfileShowResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
                Toast.makeText(context, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private boolean isValid() {
        name = edt_name.getText().toString();
        email = edt_email.getText().toString();
        city = edt_city.getText().toString();
        country = edt_country.getText().toString();
        street = edt_street.getText().toString();
        zipcode = edt_zip_code.getText().toString();
        about = edt_about.getText().toString();

        boolean isValid = true;
        if (TextUtils.isEmpty(name)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_name));
            //edt_name.setError("Enter  Name");
            isValid = false;
        } else if (TextUtils.isEmpty(email)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_email));
            isValid = false;
        }else if (!isValidEmail(email)){
            CustomAlertdialog.createDialog(context, getString(R.string.enter_valid_email));
            isValid = false;
        }
        else if (TextUtils.isEmpty(street)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_street));
            isValid = false;
        } else if (TextUtils.isEmpty(city)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_city));
            isValid = false;
        } else if (TextUtils.isEmpty(country)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_country));
            isValid = false;
        } else if (TextUtils.isEmpty(zipcode)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_zipcode));
            isValid = false;
        } else if (TextUtils.isEmpty(about)) {
            CustomAlertdialog.createDialog(context, getString(R.string.enter_about));
            isValid = false;
        }
        return isValid;
    }

    private boolean isValidEmail(CharSequence email) {
        if (!TextUtils.isEmpty(email)) {
            return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }
        return false;
    }
    public void editprofile() {
        Customprogress.showPopupProgressSpinner(context, true);
        HashMap<String, RequestBody> data = new HashMap<>();
        data.put("user_id", createRequestBody(sessionManager.getSavedUserid()));
        data.put("name", createRequestBody(name));
        data.put("sellername", createRequestBody(txt_username.getText().toString().trim()));
        data.put("email", createRequestBody(email));
        data.put("about", createRequestBody(about));
        data.put("country", createRequestBody(country));
        data.put("city", createRequestBody(city));
        data.put("street", createRequestBody(street));
        data.put("zipcode", createRequestBody(zipcode));


        MultipartBody.Part image = null;
        if (picturePath != null && !picturePath.equals("")) {
            File file = new File(picturePath);
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
        }


        mAPIService.updateProfile(data, image).enqueue(new Callback<EditProfileResponse>() {
            @Override
            public void onResponse(Call<EditProfileResponse> call, Response<EditProfileResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();
                    String msg = response.body().getMessage();
                    if (status == true) {
                        Intent edit = new Intent(context, DashboardActivity.class);
                        edit.putExtra("about","0");
                        edit.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(edit);
                        Toast.makeText(context, "" + msg, Toast.LENGTH_LONG).show();

                    } else {
                        Toast.makeText(context, "" + msg, Toast.LENGTH_LONG).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<EditProfileResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
                Toast.makeText(context, "" + t.toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public RequestBody createRequestBody(@NonNull String s) {
        return RequestBody.create(MediaType.parse("multipart/form-data"), s);
    }
}