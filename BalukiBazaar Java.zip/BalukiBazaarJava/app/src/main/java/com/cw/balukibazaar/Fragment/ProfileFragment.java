package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Activity.DashboardActivity;
import com.cw.balukibazaar.Activity.FirstLoginActivity;
import com.cw.balukibazaar.Activity.HelpActivity;
import com.cw.balukibazaar.Activity.PrivacyActivity;
import com.cw.balukibazaar.Activity.ProfileDetailActivity;
import com.cw.balukibazaar.Activity.ShopProfileActivity;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.profileshow.ProfileShowResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {

    TextView txt_logout,txt_signin,txt_welcome;
    SessionManager sessionManager;
    Context context;
    LinearLayout layout_login,rl_profile;
    CircleImageView iv_profile;
    RelativeLayout rel_fav,rel_mywallet,rel_app,rel_email,rl_help,rel_soldoreder,rel_purcha,rl_edit_profile,rel_intersts,rel_discount,rel_shi,rl_privacy;
    Fragment fragment = null;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_notification;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        InitView(v);
        Log.i("User login >>>>",""+sessionManager.isUserLogin());
        if (sessionManager.isUserLogin())
        {

            profile();
//            sendPostUser();
            txt_welcome.setText(sessionManager.getSavedUserName());
            txt_signin.setText(getResources().getString(R.string.see_profile));
            layout_login.setVisibility(View.VISIBLE);
            txt_logout.setVisibility(View.VISIBLE);
            rl_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(context, ShopProfileActivity.class);
                    intent.putExtra("user_id",sessionManager.getSavedUserid());
                    intent.putExtra("seller_id",sessionManager.getSavedUserid());
                    startActivity(intent);
                }
            });

        }
        else {
            iv_profile.setImageDrawable(getResources().getDrawable(R.drawable.app_logo));
            txt_signin.setText(getResources().getString(R.string.signin));
            txt_welcome.setText(getResources().getString(R.string.Welcome_user));
            layout_login.setVisibility(View.GONE);
            txt_logout.setVisibility(View.GONE);
            rl_profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, FirstLoginActivity.class);
                    startActivity(intent);
                }
            });
        }
        Click();
        return v;
    }

    private void Click() {
        txt_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopup();
            }
        });

        rel_fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new MyFavouritesFragment();
                loadFragment(fragment);
            }
        });

        rel_mywallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new MywalletFragment();
                loadFragment(fragment);
            }
        });
        rel_soldoreder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new SoldFragment();
                loadFragment(fragment);
            }
        });
        rel_purcha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new PurchasedFragment();
                loadFragment(fragment);
            }
        });
        rl_edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new EditProfileFragment();
                loadFragment(fragment);
            }
        });
        rel_intersts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new ViewInterstsFragment();
                loadFragment(fragment);
            }
        });

        rel_discount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new DiscountFragment();
                loadFragment(fragment);
            }
        });
        rel_shi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new ShippingFragment();
                loadFragment(fragment);
            }
        });
        rl_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, PrivacyActivity.class);
                startActivity(intent);
            }
        });

        rl_help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, HelpActivity.class);
                startActivity(intent);
            }
        });

        rel_app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new AppNotificationFragment();
               loadFragment(fragment);
            }
        });

        rel_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new AppEmailNotificationFragment();
                loadFragment(fragment);
            }
        });
        img_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }

    private void InitView(View v) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        txt_logout = v.findViewById(R.id.txt_logout);
        layout_login = v.findViewById(R.id.layout_login);
        rl_profile = v.findViewById(R.id.rl_profile);
        iv_profile = v.findViewById(R.id.iv_profile);
        txt_signin = v.findViewById(R.id.txt_signin);
        txt_welcome = v.findViewById(R.id.txt_welcome);
        rel_fav = v.findViewById(R.id.rel_fav);
        rel_mywallet = v.findViewById(R.id.rel_mywallet);
        rel_soldoreder = v.findViewById(R.id.rel_soldoreder);
        rel_purcha = v.findViewById(R.id.rel_purcha);
        rl_edit_profile = v.findViewById(R.id.rl_edit_profile);
        rel_intersts = v.findViewById(R.id.rel_intersts);
        rel_discount = v.findViewById(R.id.rel_discount);
        rel_shi = v.findViewById(R.id.rel_shi);
        rl_privacy = v.findViewById(R.id.rl_privacy);
        rl_help = v.findViewById(R.id.rl_help);
        rel_app = v.findViewById(R.id.rel_app);
        rel_email = v.findViewById(R.id.rel_email);
        img_notification = v.findViewById(R.id.img_notification);
    }

    private void showPopup() {
        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());

        alert.setMessage("Are you sure, you want to logout ?").setPositiveButton(Html.fromHtml("<font color='#000000'>Yes</font>"), new DialogInterface.OnClickListener()                 {

            public void onClick(DialogInterface dialog, int which) {
//                Toast.makeText(getActivity(), ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                FirebaseAuth.getInstance().signOut();
                sessionManager.clearSession();
                Intent intent = new Intent(getActivity(), DashboardActivity.class);
                intent.putExtra("about","0");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                getActivity().finish();


            }
        }).setNegativeButton(Html.fromHtml("<font color='#000000'>No</font>"), null);

        AlertDialog alert1 = alert.create();
        alert1.show();
    }

    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    public void profile() {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.getprofile(sessionManager.getSavedUserid(), sessionManager.getSavedUserid()).enqueue(new Callback<ProfileShowResponse>() {
            @Override
            public void onResponse(Call<ProfileShowResponse> call, Response<ProfileShowResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        if (response.body().getStatus()) {
                            ProfileShowResponse profileRes = response.body();
                            txt_welcome.setText(profileRes.getData().getSellername());
                            Picasso.get().load(Allurls.ImageURL + profileRes.getData().getProfile())
                                    .error(R.drawable.progress_animation)
                                    .placeholder(R.drawable.progress_animation)
                                    .into(iv_profile);

                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProfileShowResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
                Toast.makeText(context, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

}