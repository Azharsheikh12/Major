package com.cw.balukibazaar.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public  class NotificationListAdapter extends RecyclerView.Adapter<NotificationListAdapter.ViewHolder>{
//    List<NotificationData> eventMainModelClasses;

    // RecyclerView recyclerView;
    public NotificationListAdapter(Activity context) {

    }
    @Override
    public NotificationListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.custome_notification_list, parent, false);
        NotificationListAdapter.ViewHolder viewHolder = new NotificationListAdapter.ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(NotificationListAdapter.ViewHolder holder, int position) {


    }


    @Override
    public int getItemCount() {
        return 5;
//        return eventMainModelClasses.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_title,txt_subtitle,txt_date;
        LinearLayout layoutcard;
        public ViewHolder(View itemView) {
            super(itemView);
            this.txt_title = (TextView) itemView.findViewById(R.id.txt_title);
            this.txt_subtitle = (TextView) itemView.findViewById(R.id.txt_subtitle);
            this.txt_date = (TextView) itemView.findViewById(R.id.txt_date);
            this.layoutcard = (LinearLayout) itemView.findViewById(R.id.layoutcard);
        }
    }
}
