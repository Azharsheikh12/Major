package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.MyWalletResponse;
import com.cw.balukibazaar.ModelClass.ViewFeatureInfoResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;

import org.json.JSONException;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FeaturePaymentActivity extends AppCompatActivity {

    ImageView img_back;
    TextView txt_pay;
    Context context;
    private List<ViewProfileShop> adddataListMain;
    RadioButton cb_paypal,cb_wallet,cb_strip;
  String paymentMethod="";
  String product_id="";
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    String walletMain = "";
    double totalamt = 0.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feature_payment);
        initView();

        if(Utils.isInternetConnected(context)) {

            try {
                sendPostViewWallet();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }

        Click();
        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                adddataListMain = (List<ViewProfileShop>) intent.getSerializableExtra("featuredata");

                for (int i=0;i<adddataListMain.size();i++)
                {
                    product_id +=adddataListMain.get(i).getId()+",";

                    totalamt = Double.parseDouble(adddataListMain.get(i).getPrice())+totalamt;
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

      cb_paypal.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              if (cb_paypal.isChecked())
              {
                  cb_wallet.setChecked(false);
                  cb_strip.setChecked(false);
                  cb_paypal.setChecked(true);
                  paymentMethod = "Online";
                  System.out.println("payment method >>>>>>"+paymentMethod);
              }
          }
      });
        cb_wallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb_wallet.isChecked())
                {
                    cb_wallet.setChecked(true);
                    cb_paypal.setChecked(false);
                    cb_strip.setChecked(false);
                    paymentMethod = "Wallet";
                    System.out.println("payment method >>>>>>"+paymentMethod);
                }
            }
        });

        cb_strip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb_strip.isChecked())
                {
                    cb_wallet.setChecked(false);
                    cb_paypal.setChecked(false);
                    cb_strip.setChecked(true);
                    paymentMethod = "Stripe";
                    System.out.println("payment method >>>>>>"+paymentMethod);
                }
            }
        });

        txt_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (paymentMethod.equals("")){
                    CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select_any_payment_options));
                }
                else if (paymentMethod.equals("Wallet"))
                {
                    if (totalamt<=Double.parseDouble(walletMain))
                    {
                      //wallet payment Service call
                        if(Utils.isInternetConnected(context)) {

                        try {
                            sendPost();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
                    }
                    }
                    else {
                      CustomAlertdialog.createDialog(context,getResources().getString(R.string.your_wallet_amount_low));
                    }
                }
                else if (paymentMethod.equals("Stripe")){

                    //stripe payment service call

                }
                else if (paymentMethod.equals("Online"))
                {
                    //paypal payment service call
                }
            }
        });
    }

    private void initView() {
        context = FeaturePaymentActivity.this;
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        img_back = findViewById(R.id.img_back);
        txt_pay = findViewById(R.id.txt_pay);
        cb_paypal = findViewById(R.id.cb_paypal);
        cb_wallet = findViewById(R.id.cb_wallet);
        cb_strip = findViewById(R.id.cb_strip);
    }

    public void sendPost() throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.addfeatureproduct(sessionManager.getSavedUserid(),method(product_id),paymentMethod).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent  = new Intent(context,DashboardActivity.class);
                        intent.putExtra("about","0");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostViewWallet() throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.viewwalletdata(sessionManager.getSavedUserid()).enqueue(new Callback<MyWalletResponse>() {
            @Override
            public void onResponse(Call<MyWalletResponse> call, Response<MyWalletResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        walletMain = response.body().getWallet();
                        System.out.println("wallet data >>>>>>>>"+walletMain);
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<MyWalletResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public String method(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }
}