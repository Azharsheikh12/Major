
package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddOrderParameter implements Serializable {

    @SerializedName("order")
    @Expose
    private AddOrderParaOrder order;
    @SerializedName("product")
    @Expose
    private List<AddOrderParaProduct> product = null;

    public AddOrderParameter(AddOrderParaOrder order, List<AddOrderParaProduct> product) {
        this.order = order;
        this.product = product;
    }

    public AddOrderParaOrder getOrder() {
        return order;
    }

    public void setOrder(AddOrderParaOrder order) {
        this.order = order;
    }

    public List<AddOrderParaProduct> getProduct() {
        return product;
    }

    public void setProduct(List<AddOrderParaProduct> product) {
        this.product = product;
    }

}
