package com.cw.balukibazaar.Server;

public class Allurls {
    public static final String MainURL ="https://balukibazaar.es/baluki/api/R1/";
//    public static final String MainURL ="http://mobidudes.com/asiafiesta/api/H1/";
    public static final String ImageURL ="https://balukibazaar.es/baluki/";
//    public static final String ImageURL ="http://mobidudes.com/asiafiesta/";


}
