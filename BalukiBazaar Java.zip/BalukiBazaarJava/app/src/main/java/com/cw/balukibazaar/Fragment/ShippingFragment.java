package com.cw.balukibazaar.Fragment;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.cw.balukibazaar.Adapter.ShippingAdapter;
import com.cw.balukibazaar.Adapter.ViewallFavouriteAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.RemoveFavourite;
import com.cw.balukibazaar.Interface.ShippingStatus;
import com.cw.balukibazaar.ModelClass.ShippingResponse;
import com.cw.balukibazaar.ModelClass.ShippingStatusResponse;
import com.cw.balukibazaar.ModelClass.favourate.FavouriteResponse;
import com.cw.balukibazaar.ModelClass.profileshow.ProfileShowResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShippingFragment extends Fragment {

    ImageView iv_back,iv_notification;
    RecyclerView rv_shipping;
    Context context;
    ShippingAdapter mAdapter;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    String shipping_id, action;
    TextView tv_name,tv_address;
    Fragment fragment = null;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_shipping, container, false);
        InitView(v);
        Click();
        return v;

       /* thingsModelslist = new ArrayList<>();
        thingsModelslist.clear();
        for (int i = 0; i < 6; i++) {
            purachsed thingsModel = new purachsed("Leather Bags", "Sold completed", "23/11/2020", "50", "");
            thingsModelslist.add(thingsModel);
        }
        rv_shipping.setHasFixedSize(true);
        rv_shipping.setLayoutManager(new LinearLayoutManager(context));
        mAdapter = new ShippingAdapter(context);
        rv_shipping.setAdapter(mAdapter);
        */
    }

    private void Click() {
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().onBackPressed();
            }
        });
        iv_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = new NotificationFragment();
                loadFragment(fragment);
            }
        });
    }
    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {

            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .addToBackStack("gghh")
                    .commit();
            return true;
        }
        return false;
    }

    private void InitView(View v) {
        context = getActivity();
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();
        rv_shipping = v.findViewById(R.id.rv_shipping);
        tv_name = v.findViewById(R.id.tv_name);
        tv_address = v.findViewById(R.id.tv_address);
        iv_back = v.findViewById(R.id.iv_back);
        iv_notification = v.findViewById(R.id.iv_notification);
        if (Utils.isInternetConnected(context)) {
            profile();

        } else {
            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
        }
    }


    public void shippinglist() {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.shippinglist(sessionManager.getSavedUserid(), sessionManager.getSavedUserid(),"dashboard").enqueue(new Callback<ShippingResponse>() {
            @Override
            public void onResponse(Call<ShippingResponse> call, Response<ShippingResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status == true) {
                        rv_shipping.setHasFixedSize(true);
                        rv_shipping.setLayoutManager(new LinearLayoutManager(context));
                        mAdapter = new ShippingAdapter(context, response.body().getData(), new ShippingStatus() {
                            @Override
                            public void getshippingstatus(String shipping_id, String action) {
                                shippingstatus(shipping_id, action);
                            }
                        });
                        rv_shipping.setAdapter(mAdapter);

                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<ShippingResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
            }

        });
    }

    public void shippingstatus(String shipping_id, String action) {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.shippingonoff(sessionManager.getSavedUserid(), shipping_id, action).enqueue(new Callback<ShippingStatusResponse>() {
            @Override
            public void onResponse(Call<ShippingStatusResponse> call, Response<ShippingStatusResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status == true) {
                        shippinglist();

                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<ShippingStatusResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
            }

        });
    }

    public void profile() {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.getprofile(sessionManager.getSavedUserid(), sessionManager.getSavedUserid()).enqueue(new Callback<ProfileShowResponse>() {
            @Override
            public void onResponse(Call<ProfileShowResponse> call, Response<ProfileShowResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);

                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        if (response.body().getStatus()) {
                            shippinglist();
                            ProfileShowResponse profileRes = response.body();
                            tv_name.setText(profileRes.getData().getName());
                            tv_address.setText(profileRes.getData().getCity()+" "+profileRes.getData().getStreet());

                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProfileShowResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
                Toast.makeText(context, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}