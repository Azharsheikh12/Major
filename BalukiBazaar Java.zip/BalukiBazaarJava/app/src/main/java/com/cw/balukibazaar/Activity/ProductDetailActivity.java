package com.cw.balukibazaar.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Adapter.MySliderAdapter;
import com.cw.balukibazaar.Fragment.MoreSellerItemFragment;
import com.cw.balukibazaar.Fragment.SimilarItemFragment;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.HomeResponse;
import com.cw.balukibazaar.ModelClass.ProductDetailData;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.ModelClass.ProductDetailMoreitem;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    RelativeLayout re_moreseller, re_similaritem;
    LinearLayout lin_moreseller_line,li_similaritem_line,ll_favorite,ll_profile;
   Fragment fragment;
   Activity activity;
   SessionManager sessionManager;
   String pro_id,user_id;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_back,img_fav;
    CircleImageView img_seller;
    TextView txt_sellername,txt_likes,tv_iv_count,txt_itemname,tv_item_desc,tv_condition,txt_brand,txt_price,txt_size,txt_colorname;
    ViewPager2 viewPager;
    private static int currentPage = 0;
    private static int NUM_PAGES ;
    MySliderAdapter adapter;
    String fav_value,seller_id;
    Button btn_chat,btn_buy_now;
    ProductDetailData productDetailData;
    ArrayList<ProductDetailData> detailDataArrayList;
    ArrayList<ProductDetailData> ClearDataArrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);
        InitView();
        Click();
        try {
            Intent intent  =getIntent();
            if (intent!=null){
                pro_id = intent.getStringExtra("pro_id");
            }
        }catch (Exception e )
        {
            e.printStackTrace();
        }

        if (sessionManager.isUserLogin())
        {
            user_id = sessionManager.getSavedUserid();
        }
        else {
            user_id = "0";
        }

        if(Utils.isInternetConnected(activity)) {

            try {
                detailDataArrayList = new ArrayList<>();
                ClearDataArrayList = new ArrayList<>();
                sendPost(user_id,pro_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }

        // ------------------default fragment set -------------------
        lin_moreseller_line.setBackgroundColor(getResources().getColor(R.color.yellow));
        li_similaritem_line.setBackgroundColor(getResources().getColor(R.color.black));
        fragment =new MoreSellerItemFragment(user_id,pro_id);
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.contentContainer, fragment )
                .commit();
    }

    private void Click() {
        re_moreseller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lin_moreseller_line.setBackgroundColor(getResources().getColor(R.color.yellow));
                li_similaritem_line.setBackgroundColor(getResources().getColor(R.color.black));
                fragment = new  MoreSellerItemFragment(user_id,pro_id);
                getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.id.contentContainer, fragment)
                        .commit();
            }
        });
        re_similaritem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lin_moreseller_line.setBackgroundColor(getResources().getColor(R.color.black));
                li_similaritem_line.setBackgroundColor(getResources().getColor(R.color.yellow));
                fragment = new SimilarItemFragment(user_id,pro_id);
                getSupportFragmentManager()
                        .beginTransaction()
                        .add(R.id.contentContainer, fragment)
                        .commit();
            }
        });
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        ll_favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (sessionManager.isUserLogin())
                {
                    if(Utils.isInternetConnected(activity)) {

                        try {
                            sendPostFav(fav_value);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    else {
                        CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                    }
                }
                else {
                    Intent intent = new Intent(activity,FirstLoginActivity.class);
                    startActivity(intent);
                }


            }
        });

        btn_chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (sessionManager.isUserLogin())
                {
                    Intent intent = new Intent(activity,MessageActivity.class);
                    intent.putExtra("productdata",productDetailData);
                    intent.putExtra("chat_id","0");
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(activity,FirstLoginActivity.class);
                    startActivity(intent);
                }

            }
        });

        btn_buy_now.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sessionManager.isUserLogin())
                {
                    if (sessionManager.getProductList().size()==0)
                    {
                        sessionManager.setProductList(detailDataArrayList);
                        Intent intent = new Intent(activity,YourOrderActivity.class);
                        intent.putExtra("seller_id",seller_id);
                        intent.putExtra("discount_id",productDetailData.getDis_id());

                        startActivity(intent);
                        System.out.println("sessionManager.getProductList() size >>>>"+sessionManager.getProductList().size());

                    }
                    else if (sessionManager.getProductList().get(0).getSellerdata().getId().equals(productDetailData.getSellerdata().getId()))
                    {
                        ArrayList<ProductDetailData> list = sessionManager.getProductList();
                        list.add(productDetailData);
                        sessionManager.setProductList(list);
                        Intent intent = new Intent(activity,YourOrderActivity.class);
                        intent.putExtra("seller_id",seller_id);
                        intent.putExtra("discount_id",productDetailData.getDis_id());
                        startActivity(intent);
                        System.out.println("sessionManager.getProductList() add "+sessionManager.getProductList().size());

                    }
                    else{
                        sessionManager.setProductList(detailDataArrayList);
                        Intent intent = new Intent(activity,YourOrderActivity.class);
                        intent.putExtra("seller_id",seller_id);
                        intent.putExtra("discount_id",productDetailData.getDis_id());
                        startActivity(intent);
                        System.out.println("sessionManager.getProductList() clear then add new >>>>"+sessionManager.getProductList().size());

                    }
                }
                else {
                    Intent intent = new Intent(activity,FirstLoginActivity.class);
                    startActivity(intent);
                }



            }
        });

        ll_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sessionManager.isUserLogin())
                {
                    Intent intent = new Intent(activity,ShopProfileActivity.class);
                    intent.putExtra("user_id",user_id);
                    intent.putExtra("seller_id",seller_id);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(activity,FirstLoginActivity.class);
                    startActivity(intent);
                }

            }
        });
    }

    private void InitView() {
        activity = ProductDetailActivity.this;
        sessionManager = new SessionManager(activity);
        mAPIService = ApiUtils.getAPIService();
        re_moreseller = findViewById(R.id.re_moreseller);
        re_similaritem = findViewById(R.id.re_similaritem);
        lin_moreseller_line = findViewById(R.id.lin_moreseller_line);
        li_similaritem_line = findViewById(R.id.li_similaritem_line);
        img_back = findViewById(R.id.img_back);
        img_seller = findViewById(R.id.img_seller);
        txt_sellername = findViewById(R.id.txt_sellername);
        viewPager = findViewById(R.id.viewPager);
        tv_iv_count = findViewById(R.id.tv_iv_count);
        txt_itemname = findViewById(R.id.txt_itemname);
        tv_item_desc = findViewById(R.id.tv_item_desc);
        tv_condition = findViewById(R.id.tv_condition);
        txt_brand = findViewById(R.id.txt_brand);
        txt_price = findViewById(R.id.txt_price);
        txt_size = findViewById(R.id.txt_size);
        txt_colorname = findViewById(R.id.txt_colorname);
        txt_likes = findViewById(R.id.txt_likes);
        img_fav = findViewById(R.id.img_fav);
        ll_favorite = findViewById(R.id.ll_favorite);
        btn_chat = findViewById(R.id.btn_chat);
        btn_buy_now = findViewById(R.id.btn_buy_now);
        ll_profile = findViewById(R.id.ll_profile);
    }

    public void sendPost(String user_id,String pro_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.getproductdetaildata(user_id,pro_id).enqueue(new Callback<ProductDetailResponse>() {
            @Override
            public void onResponse(Call<ProductDetailResponse> call, Response<ProductDetailResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        productDetailData = response.body().getData();

                        detailDataArrayList.add(response.body().getData());

                        seller_id = response.body().getData().getSellerdata().getId();

                        Picasso.get().load(Allurls.ImageURL+response.body().getData().getSellerdata().getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(img_seller);
                        txt_sellername.setText(response.body().getData().getSellerdata().getName());
                        SetSliderData(response.body().getData().getImages());
                        txt_itemname.setText(response.body().getData().getName());
                        tv_item_desc.setText(response.body().getData().getDescription());
                        tv_condition.setText(response.body().getData().getConditionname());
                        txt_brand.setText(response.body().getData().getBrandname());
                        txt_price.setText("€ "+response.body().getData().getPrice());

                        String size = "";
                        for (int i=0;i<response.body().getData().getSize().size();i++)
                        {
                            size = size+response.body().getData().getSize().get(i).getSize()+",";
                        }
                        txt_size.setText(RemoveLastStr(size));

                        String colorname ="";
                        for (int i=0;i<response.body().getData().getColor().size();i++)
                        {
                            colorname +=response.body().getData().getColor().get(i).getColor()+",";
                        }
                        txt_colorname.setText(RemoveLastStr(colorname));
                        txt_likes.setText(response.body().getData().getLikes());

                        String s_fav  = response.body().getData().getIs_favorite();
                        Log.i("s_fav >>>>>",""+s_fav);
                        //0 means no favourite and 1 means favourite
                        if (s_fav.equals("0")) {
                            fav_value = "0";
                            img_fav.setBackground(activity.getResources().getDrawable(R.drawable.ic_heartnotfill));
                        } else {
                            fav_value = "1";
                            img_fav.setBackground(activity.getResources().getDrawable(R.drawable.ic_heartcolorfill));
                        }

                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProductDetailResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostFav(String fav_value) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.addremovefavourite(user_id,pro_id).enqueue(new Callback<Add_Remove_Fav_Response>() {
            @Override
            public void onResponse(Call<Add_Remove_Fav_Response> call, Response<Add_Remove_Fav_Response> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        if(Utils.isInternetConnected(activity)) {

                            try {
                                sendPost(user_id,pro_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else {
                            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
                        }
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<Add_Remove_Fav_Response> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public String RemoveLastStr(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }

    public void SetSliderData(List<ProductDetailImage> images)
    {
        try {

//            NUM_PAGES = 3;
            NUM_PAGES = images.size();
            /*if(NUM_PAGES==1){
                tv_iv_count.setText("1/1");
            }*/
            viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
//                    setupCurrentIndicator(position);
                    Log.e("Selected_Page", String.valueOf(position));
                    tv_iv_count.setText("" + String.valueOf(position+1) + "/" + NUM_PAGES);

                }
            });
            final Handler handler = new Handler();
            final Runnable Update = new Runnable() {
                public void run() {
                    if (currentPage == NUM_PAGES) {
                        currentPage = 0;
                    }
                    viewPager.setCurrentItem(currentPage++, true);
                }
            };
           /* Timer swipeTimer = new Timer();
            swipeTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    handler.post(Update);
                }
            }, 3000, 3000);*/


            adapter=new MySliderAdapter(activity,images,viewPager);
            viewPager.setAdapter(adapter);

        }catch (Exception e)
        {
            e.printStackTrace();
        }


    }
}