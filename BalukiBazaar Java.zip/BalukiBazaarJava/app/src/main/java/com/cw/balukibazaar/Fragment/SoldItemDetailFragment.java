package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.cw.balukibazaar.Activity.AddReviewActivity;
import com.cw.balukibazaar.Activity.FirstLoginActivity;
import com.cw.balukibazaar.Activity.MessageActivity;
import com.cw.balukibazaar.Activity.ShopProfileActivity;
import com.cw.balukibazaar.Activity.YourOrderActivity;
import com.cw.balukibazaar.Adapter.MySliderAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.ModelClass.Add_Remove_Fav_Response;
import com.cw.balukibazaar.ModelClass.MyOrderDetail;
import com.cw.balukibazaar.ModelClass.ProductDetailData;
import com.cw.balukibazaar.ModelClass.ProductDetailImage;
import com.cw.balukibazaar.ModelClass.ProductDetailResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SoldItemDetailFragment extends Fragment {
    MyOrderDetail soldData;
    ImageView img_back;
    Activity activity;
    RelativeLayout re_moreseller, re_similaritem;
    LinearLayout lin_moreseller_line,li_similaritem_line,ll_profile;
    Fragment fragment;
    SessionManager sessionManager;
    String pro_id,user_id;
    private JsonPlaceHolderApi mAPIService;
    ImageView img_fav;
    CircleImageView img_seller;
    TextView txt_sellername,btn_review,txt_likes,tv_iv_count,txt_itemname,tv_item_desc,tv_condition,txt_brand,txt_price,txt_size,txt_colorname;
    ViewPager2 viewPager;
    private static int currentPage = 0;
    private static int NUM_PAGES ;
    MySliderAdapter adapter;
    String fav_value,seller_id;
    ProductDetailData productDetailData;
    ArrayList<ProductDetailData> detailDataArrayList;
    ArrayList<ProductDetailData> ClearDataArrayList;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sold_item_detail, container, false);
        InitView(v);
        try {

            soldData = (MyOrderDetail) getArguments().getSerializable("data");
            pro_id = soldData.getProductId();
            System.out.println("item name >>>>>>"+soldData.getProductName());

        }catch (Exception e)
        {
            e.printStackTrace();
        }
        Click();
        if (sessionManager.isUserLogin())
        {
            user_id = sessionManager.getSavedUserid();
        }
        else {
            user_id = "0";
        }

        if(Utils.isInternetConnected(activity)) {

            try {
                detailDataArrayList = new ArrayList<>();
                ClearDataArrayList = new ArrayList<>();
                sendPost(user_id,pro_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        else {
            CustomAlertdialog.createDialog(activity,getString(R.string.no_internet));
        }

        return v;
    }
    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onBackPressed();
            }
        });
        ll_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, ShopProfileActivity.class);
                intent.putExtra("user_id",user_id);
                intent.putExtra("seller_id",seller_id);
                startActivity(intent);
            }
        });

        btn_review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, AddReviewActivity.class);
                intent.putExtra("data",soldData);
                startActivity(intent);

            }
        });
    }

    private void InitView(View v) {
        activity = getActivity();
        sessionManager = new SessionManager(activity);
        mAPIService = ApiUtils.getAPIService();
        re_moreseller = v.findViewById(R.id.re_moreseller);
        re_similaritem = v.findViewById(R.id.re_similaritem);
        lin_moreseller_line = v.findViewById(R.id.lin_moreseller_line);
        li_similaritem_line = v.findViewById(R.id.li_similaritem_line);
        img_back = v.findViewById(R.id.img_back);
        img_seller = v.findViewById(R.id.img_seller);
        txt_sellername = v.findViewById(R.id.txt_sellername);
        viewPager = v.findViewById(R.id.viewPager);
        tv_iv_count = v.findViewById(R.id.tv_iv_count);
        txt_itemname = v.findViewById(R.id.txt_itemname);
        tv_item_desc = v.findViewById(R.id.tv_item_desc);
        tv_condition = v.findViewById(R.id.tv_condition);
        txt_brand = v.findViewById(R.id.txt_brand);
        txt_price = v.findViewById(R.id.txt_price);
        txt_size = v.findViewById(R.id.txt_size);
        txt_colorname = v.findViewById(R.id.txt_colorname);
        txt_likes = v.findViewById(R.id.txt_likes);
        img_fav = v.findViewById(R.id.img_fav);
        ll_profile = v.findViewById(R.id.ll_profile);
        btn_review = v.findViewById(R.id.btn_review);
    }

    public void sendPost(String user_id,String pro_id) throws JSONException {
        Customprogress.showPopupProgressSpinner(activity,true);

        mAPIService.getproductdetaildata(user_id,pro_id).enqueue(new Callback<ProductDetailResponse>() {
            @Override
            public void onResponse(Call<ProductDetailResponse> call, Response<ProductDetailResponse> response) {

                Customprogress.showPopupProgressSpinner(activity,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {

                        productDetailData = response.body().getData();

                        detailDataArrayList.add(response.body().getData());

                        seller_id = response.body().getData().getSellerdata().getId();

                        Picasso.get().load(Allurls.ImageURL+response.body().getData().getSellerdata().getProfile()).error(R.drawable.progress_animation).placeholder(R.drawable.progress_animation).into(img_seller);
                        txt_sellername.setText(response.body().getData().getSellerdata().getName());
                        SetSliderData(response.body().getData().getImages());
                        txt_itemname.setText(response.body().getData().getName());
                        tv_item_desc.setText(response.body().getData().getDescription());
                        tv_condition.setText(response.body().getData().getConditionname());
                        txt_brand.setText(response.body().getData().getBrandname());
                        txt_price.setText("€ "+response.body().getData().getPrice());

                        String size = "";
                        for (int i=0;i<response.body().getData().getSize().size();i++)
                        {
                            size = size+response.body().getData().getSize().get(i).getSize()+",";
                        }
                        txt_size.setText(RemoveLastStr(size));

                        String colorname ="";
                        for (int i=0;i<response.body().getData().getColor().size();i++)
                        {
                            colorname +=response.body().getData().getColor().get(i).getColor()+",";
                        }
                        txt_colorname.setText(RemoveLastStr(colorname));
                        txt_likes.setText(response.body().getData().getLikes());
                    }
                    else
                    {
                        Toast.makeText(activity, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProductDetailResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(activity,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }


    public String RemoveLastStr(String str) {
        if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == ',') {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }

    public void SetSliderData(List<ProductDetailImage> images)
    {
        try {

//            NUM_PAGES = 3;
            NUM_PAGES = images.size();
            /*if(NUM_PAGES==1){
                tv_iv_count.setText("1/1");
            }*/
            viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
//                    setupCurrentIndicator(position);
                    Log.e("Selected_Page", String.valueOf(position));
                    tv_iv_count.setText("" + String.valueOf(position+1) + "/" + NUM_PAGES);

                }
            });
            final Handler handler = new Handler();
            final Runnable Update = new Runnable() {
                public void run() {
                    if (currentPage == NUM_PAGES) {
                        currentPage = 0;
                    }
                    viewPager.setCurrentItem(currentPage++, true);
                }
            };
           /* Timer swipeTimer = new Timer();
            swipeTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    handler.post(Update);
                }
            }, 3000, 3000);*/


            adapter=new MySliderAdapter(activity,images,viewPager);
            viewPager.setAdapter(adapter);

        }catch (Exception e)
        {
            e.printStackTrace();
        }


    }
}