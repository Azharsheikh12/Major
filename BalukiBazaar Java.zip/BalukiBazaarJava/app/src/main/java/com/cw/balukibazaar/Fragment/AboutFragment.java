package com.cw.balukibazaar.Fragment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cw.balukibazaar.Activity.DashboardActivity;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;

public class AboutFragment extends Fragment {

    String about,seller_id;
    TextView txt_edtpro,txt_about;
    SessionManager sessionManager;
    Activity activity;
    public AboutFragment(String about, String seller_id) {
        this.about = about;
        this.seller_id = seller_id;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v= inflater.inflate(R.layout.fragment_about, container, false);
       InitView(v);
        Log.i("user id>>",""+sessionManager.getSavedUserid());
        Log.i("seller id>>",""+seller_id);
       if (sessionManager.getSavedUserid().equals(seller_id))
       {
           txt_edtpro.setVisibility(View.VISIBLE);
           txt_edtpro.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   Intent intent  = new Intent(activity, DashboardActivity.class);
//                   intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                   intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                   intent.putExtra("about","1");
                   startActivity(intent);
//                   getActivity().finish();
               }
           });
       }
       else {
           txt_edtpro.setVisibility(View.GONE);
       }
        txt_about.setText(about);
       return v;
    }

    private void InitView(View v) {
        activity = getActivity();
        sessionManager = new SessionManager(getActivity());
        txt_edtpro = v.findViewById(R.id.txt_edtpro);
        txt_about = v.findViewById(R.id.txt_about);
    }
}