package com.cw.balukibazaar.ModelClass;

import java.io.Serializable;
import java.util.List;

public class HomeDataWeLove {

    private String productName;
    private String description;
    private String seller;
    private String price;
    private String isFavourite;
    private String seller_image;

    public HomeDataWeLove(String productName, String description, String seller, String price, String isFavourite, String seller_image) {
        this.productName = productName;
        this.description = description;
        this.seller = seller;
        this.price = price;
        this.isFavourite = isFavourite;
        this.seller_image = seller_image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSeller() {
        return seller;
    }

    public void setSeller(String seller) {
        this.seller = seller;
    }

    public String getIsFavourite() {
        return isFavourite;
    }

    public void setIsFavourite(String isFavourite) {
        this.isFavourite = isFavourite;
    }

    public String getSeller_image() {
        return seller_image;
    }

    public void setSeller_image(String seller_image) {
        this.seller_image = seller_image;
    }
}
