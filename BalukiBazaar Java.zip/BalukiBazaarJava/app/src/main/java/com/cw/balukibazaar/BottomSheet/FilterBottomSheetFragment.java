package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.Interface.BrandFilter;
import com.cw.balukibazaar.Interface.CategoryFilter;
import com.cw.balukibazaar.Interface.ColorFilter;
import com.cw.balukibazaar.Interface.ConditionFilter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.MainFilter;
import com.cw.balukibazaar.Interface.PriceFilter;
import com.cw.balukibazaar.Interface.SizeFilter;
import com.cw.balukibazaar.ModelClass.GlobalBrandData;
import com.cw.balukibazaar.ModelClass.GlobalBrandResponse;
import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.ModelClass.GlobalCategoryResponse;
import com.cw.balukibazaar.ModelClass.GlobalColorData;
import com.cw.balukibazaar.ModelClass.GlobalColorResponse;
import com.cw.balukibazaar.ModelClass.GlobalConditionData;
import com.cw.balukibazaar.ModelClass.GlobalConditionResponse;
import com.cw.balukibazaar.ModelClass.GlobalSizeData;
import com.cw.balukibazaar.ModelClass.GlobalSizeResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class FilterBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {
    private List<GlobalCategoryData> categoriesListMain;
    private List<GlobalSizeData> sizeListMain;
    private List<GlobalColorData> colorListMain;
    private List<GlobalBrandData> brandListMain;
    private List<GlobalConditionData> conditionListMain;
    SessionManager sessionManager;
    ImageView iv_close,iv_back;
    RecyclerView recycler_category;
    List<String> categoriesList;
    CategorySubAdapter MyListAdapter;
    Context context;
    RelativeLayout rl_main;
    TextView btn_submit;
    private JsonPlaceHolderApi mAPIService;
    String MainCateid="",MainSizeid="",MainColorid="",MainBrandid="",MainMaxprice="",MainMinprice="",MainConditionid="";
    MainFilter mainFilter;
    public FilterBottomSheetFragment(Context context, List<String> categoriesList, MainFilter mainFilter) {
        this.categoriesList = categoriesList;
        this.context = context;
        this.mainFilter = mainFilter;
    }
    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_filter2, container, false);

        findIds(view);

        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_category.setHasFixedSize(true);
        recycler_category.setLayoutManager(new LinearLayoutManager(context));
        recycler_category.setAdapter(MyListAdapter);
        if(Utils.isInternetConnected(context)) {

            sendPostcategory();
        }
        else {
            CustomAlertdialog.createDialog(context,getString(R.string.no_internet));
        }
        return view;

    }

    public void findIds(View v) {

        mAPIService = ApiUtils.getAPIService();
        sessionManager = new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_category = v.findViewById(R.id.recycler_category);
        rl_main = v.findViewById(R.id.rl_main);
        btn_submit = v.findViewById(R.id.btn_submit);
        btn_submit.setOnClickListener(this);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
//                sessionManager.setSavedCateId("");
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
//                sessionManager.setSavedCateId("");
                dismissAllowingStateLoss();
                break;
            case R.id.btn_submit:
                mainFilter.getMainid(MainCateid,MainSizeid,MainColorid,MainBrandid,MainMinprice,MainMaxprice,MainConditionid);
               dismissAllowingStateLoss();
                break;
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<String> eventMainModelClasses;
        private Context context;
        // RecyclerView recyclerView;
        public CategorySubAdapter(Context context, List<String> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_filter_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final String myListData = eventMainModelClasses.get(position);

            holder.txt_title.setText(categoriesList.get(position));

           holder.re_main.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   switch (position){
                       case 0:
                           CategoryBottomSheetFragment filterBottomSheetFragment = new CategoryBottomSheetFragment(getContext(),categoriesListMain, new CategoryFilter() {
                               @Override
                               public void getCateegoryid(String cateid) {
                                   MainCateid = cateid;
                               }
                           });
                           filterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
                           break;
                       case 1:
                           SizeBottomSheetFragment sizeBottomSheetFragment = new SizeBottomSheetFragment(getContext(),sizeListMain, new SizeFilter() {
                               @Override
                               public void getSizeid(String cateid) {

                                   MainSizeid = cateid;
                               }
                           });
                           sizeBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
                           break;
                       case 2:
                           ColorBottomSheetFragment colorBottomSheetFragment= new ColorBottomSheetFragment(getContext(),colorListMain, new ColorFilter() {
                               @Override
                               public void getColorid(String cateid) {

                                   MainColorid = cateid;
                               }
                           });
                           colorBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

                           break;
                       case 3:
                           BrandBottomSheetFragment brandBottomSheetFragment = new BrandBottomSheetFragment(getContext(),brandListMain, new BrandFilter() {
                               @Override
                               public void getBrandid(String cateid) {

                                   MainBrandid = cateid;
                               }
                           });
                           brandBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");
                           break;
                       case 4:
                           PriceFilterBottomSheetFragment priceFilterBottomSheetFragment = new PriceFilterBottomSheetFragment(getContext(), new PriceFilter() {
                               @Override
                               public void getprices(String minimum, String maximum) {

                                   MainMaxprice = maximum;
                                   MainMinprice = minimum;
                               }
                           });
                           priceFilterBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

                           break;
                       case 5:
                           ConditionBottomSheetFragment conditionBottomSheetFragment = new ConditionBottomSheetFragment(getContext(),conditionListMain, new ConditionFilter() {
                               @Override
                               public void getConditionid(String cateid) {

                                   MainConditionid = cateid;
                               }
                           });
                           conditionBottomSheetFragment.show(getActivity().getSupportFragmentManager(), "add_photo_dialog_fragment");

                           break;
                   }
               }
           });

        }
        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {

            TextView txt_title;
            RelativeLayout re_main;
            ImageView iv_tick;
            public ViewHolder(View itemView) {
                super(itemView);

                txt_title = itemView.findViewById(R.id.txt_title);
                re_main = itemView.findViewById(R.id.re_main);
                iv_tick = itemView.findViewById(R.id.iv_tick);
            }
        }
    }


    public void sendPostcategory()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcategorylist().enqueue(new Callback<GlobalCategoryResponse>() {
            @Override
            public void onResponse(Call<GlobalCategoryResponse> call, Response<GlobalCategoryResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostsize();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        categoriesListMain = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalCategoryResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostsize()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getsizelist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalSizeResponse>() {
            @Override
            public void onResponse(Call<GlobalSizeResponse> call, Response<GlobalSizeResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostcolor();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        sizeListMain = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalSizeResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcolor()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getcolorlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalColorResponse>() {
            @Override
            public void onResponse(Call<GlobalColorResponse> call, Response<GlobalColorResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostbrand();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        colorListMain = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalColorResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostbrand()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getbrandlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalBrandResponse>() {
            @Override
            public void onResponse(Call<GlobalBrandResponse> call, Response<GlobalBrandResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    sendPostcondition();
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        brandListMain = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());

                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalBrandResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
    public void sendPostcondition()  {
        Customprogress.showPopupProgressSpinner(context,true);
        mAPIService.getconditionlist(sessionManager.getSavedUserid()).enqueue(new Callback<GlobalConditionResponse>() {
            @Override
            public void onResponse(Call<GlobalConditionResponse> call, Response<GlobalConditionResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        conditionListMain = response.body().getData();
                        Log.d("cate response >>",""+response.body().getData());
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<GlobalConditionResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+ t.getMessage());
            }
        });
    }
}