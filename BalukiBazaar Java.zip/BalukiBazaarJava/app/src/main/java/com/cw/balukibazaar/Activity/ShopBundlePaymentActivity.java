package com.cw.balukibazaar.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.braintreepayments.api.dropin.DropInActivity;
import com.braintreepayments.api.dropin.DropInRequest;
import com.braintreepayments.api.dropin.DropInResult;
import com.cooltechworks.creditcarddesign.CardEditActivity;
import com.cooltechworks.creditcarddesign.CreditCardUtils;
import com.cw.balukibazaar.Adapter.ShippingAdapter;
import com.cw.balukibazaar.Adapter.ShopBundlepayShippingAdapter;
import com.cw.balukibazaar.Interface.JsonPlaceHolderApi;
import com.cw.balukibazaar.Interface.ShippingStatus;
import com.cw.balukibazaar.Interface.ShopBundleShappingData;
import com.cw.balukibazaar.ModelClass.AddOrderParaOrder;
import com.cw.balukibazaar.ModelClass.AddOrderParaProduct;
import com.cw.balukibazaar.ModelClass.AddOrderParameter;
import com.cw.balukibazaar.ModelClass.AddOrderResponse;
import com.cw.balukibazaar.ModelClass.MyWalletResponse;
import com.cw.balukibazaar.ModelClass.ShippingResponse;
import com.cw.balukibazaar.ModelClass.ViewProfileShop;
import com.cw.balukibazaar.ModelClass.WalletPaymentResponse;
import com.cw.balukibazaar.ModelClass.profileshow.ProfileShowResponse;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Server.Allurls;
import com.cw.balukibazaar.Server.ApiUtils;
import com.cw.balukibazaar.Utils.CustomAlertdialog;
import com.cw.balukibazaar.Utils.Customprogress;
import com.cw.balukibazaar.Utils.SessionManager;
import com.cw.balukibazaar.Utils.Utils;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.TextHttpResponseHandler;
import com.squareup.picasso.Picasso;
import com.stripe.android.ApiResultCallback;
import com.stripe.android.Stripe;
import com.stripe.android.model.Card;
import com.stripe.android.model.Token;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ShopBundlePaymentActivity extends AppCompatActivity {

    ImageView img_back;
    RecyclerView rv_shipping;
    Context context;
    ShopBundlepayShippingAdapter mAdapter;
    SessionManager sessionManager;
    private JsonPlaceHolderApi mAPIService;
    EditText edt_street,edt_city,edt_country,edt_zip_code;

    TextView txt_pay;
    public List<ViewProfileShop> transferShopDataListMain;
    CheckBox cb_paypal,cb_wallet,cb_strip;
    String paymentMethod="",customerName,discount_id,totaldiscountamt,shappingidmain="",shappingamtmain="",street,city,country,zipcode,seller_id;
    String walletMain = "";
    Double totalamt;
    //Stripe payment getway
    private final int CREATE_NEW_CARD = 0;
    private static final int BRAINTREE_REQUEST_CODE = 4949;
    private Stripe stripe;
    Card card;
    Token token;
    String order_id,mClientToken;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_bundle_payment);
        InitView();

        try {
            Intent intent = getIntent();
            if (intent!=null)
            {
                transferShopDataListMain = (List<ViewProfileShop>) intent.getSerializableExtra("shopdata");
                totalamt = intent.getDoubleExtra("totalamt",00);
                totaldiscountamt = intent.getStringExtra("totaldiscountamt");
                seller_id = intent.getStringExtra("seller_id");
                discount_id = intent.getStringExtra("discount_id");
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        Click();

    }

    private void Click() {
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        txt_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               street = edt_street.getText().toString().trim();
               city = edt_city.getText().toString().trim();
               country = edt_country.getText().toString().trim();
               zipcode = edt_zip_code.getText().toString().trim();

               if (street.isEmpty())
               {
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.enter_street));
               }
               else if (city.isEmpty())
               {
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.enter_city));
               }
               else if (country.isEmpty())
               {
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.enter_country));
               }
               else if (zipcode.isEmpty())
               {
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.enter_zipcode));
               }
               else if (paymentMethod.equals(""))
               {
                   CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select_any_payment_options));
               }
               else if (shappingidmain.equals("")){
                  CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_select_shipping_option));
               }
               else if (paymentMethod.equals("Wallet")) {
                   System.out.println(">>>>>>>>>"+totalamt);
                   System.out.println(">>>>>>>>>"+walletMain);
                   if (totalamt <= Double.parseDouble(walletMain)) {
                       //wallet payment Service call
                       if (Utils.isInternetConnected(context)) {
                           Addorderdata();

                       } else {
                           CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                       }
                   }
                   else {
                       Toast.makeText(context, "your wallet balance low.\nPlease select other payment option.", Toast.LENGTH_SHORT).show();
                   }
               }
               else {
                   if (Utils.isInternetConnected(context)) {
                       Addorderdata();

                   } else {
                       CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
                   }
               }
            }
        });

        cb_paypal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb_paypal.isChecked())
                {
                    cb_wallet.setChecked(false);
                    cb_strip.setChecked(false);
                    cb_paypal.setChecked(true);
                    paymentMethod = "Online";
                }
            }
        });
        cb_wallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb_wallet.isChecked())
                {
                    cb_wallet.setChecked(true);
                    cb_strip.setChecked(false);
                    cb_paypal.setChecked(false);
                    paymentMethod = "Wallet";
                }
            }
        });

        cb_strip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb_strip.isChecked())
                {
                    cb_wallet.setChecked(false);
                    cb_strip.setChecked(true);
                    cb_paypal.setChecked(false);
                    paymentMethod = "Stripe";
                }
            }
        });
    }

    private void getClientTokenFromServer() {

        AsyncHttpClient client = new AsyncHttpClient();
        client.get("http://med2u.com.au/api/H1/clienttoken", new TextHttpResponseHandler() {
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {

            }

            @Override
            public void onSuccess(int statusCode, Header[] headers, String clientToken) {
                try {
                    JSONObject obj = new JSONObject(clientToken);
                    mClientToken = obj.getString("token");
                    Log.e("Client token: ", clientToken);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

    }

  /*  private void paymentinfoPopup() {
        final Dialog dialog = new Dialog(context);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
// Prevent dialog close on back press button
                if (keyCode == KeyEvent.KEYCODE_BACK) {
// dialog.dismiss();
                }
                return keyCode == KeyEvent.KEYCODE_BACK;
            }
        });
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.dialog_success);
        TextView tv_msg = dialog.findViewById(R.id.tv_msg);
        Button button = dialog.findViewById(R.id.btn_ok);

        tv_msg.setText("Please check your order carefully before submitting your payment as charges may occur for cancellation. Refer to terms and conditions.");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                onBraintreeSubmit();
//makepayment();

            }
        });
        dialog.show();
    }*/

    /* public void makepayment(String paymentNonce) {
         Customprogress.showPopupProgressSpinner(context,true);
 //paymenttype = "normal";
         paymenttype = "braintree";
 //please change payment nonce to live payment nonce before accepting live payments
         String fakenonce = "fake-valid-nonce";

         if (TextUtils.isEmpty(neworder_total)) {
             neworder_total = amount;

         } else {
             amount=neworder_total;
         }
         ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
         Call<PaymentResponse> call = apiInterface.makepayment(sharedPreference.getString(Constant.USER_ID), paymenttype, amount, invoice_id, order_id, fakenonce);
         call.enqueue(new Callback<PaymentResponse>() {
             @Override
             public void onResponse(Call<PaymentResponse> call, Response<PaymentResponse> response) {
                 PaymentResponse paymentResponse = response.body();
                  if (paymentResponse.getStatus().equals(true)) {
             paymentSuccessPopup();

         } else {
             Toast.makeText(context, "Payment Status Expired", Toast.LENGTH_SHORT).show();
         }
             }

             @Override
             public void onFailure(Call<PaymentResponse> call, Throwable t) {
                 progressLoader.dismiss();
                 Toast.makeText(context, t.toString(), Toast.LENGTH_SHORT).show();
             }
         });
     }*/
    public void onBraintreeSubmit() {
        DropInRequest dropInRequest = new DropInRequest().clientToken(mClientToken);
        startActivityForResult(dropInRequest.getIntent(context), BRAINTREE_REQUEST_CODE);
    }

    private void paymentSuccessPopup() {
        final Dialog dialog = new Dialog(context);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
// Prevent dialog close on back press button
                if (keyCode == KeyEvent.KEYCODE_BACK) {
// dialog.dismiss();
                }
                return keyCode == KeyEvent.KEYCODE_BACK;
            }
        });
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        dialog.setContentView(R.layout.dialog_success);
        TextView tv_msg = dialog.findViewById(R.id.tv_msg);
        Button button = dialog.findViewById(R.id.btn_ok);

        tv_msg.setText("Your Payment Has Been Done Successfully");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                onBackPressed();
                finish();

            }
        });
        dialog.show();
    }

    private void InitView() {

        context = ShopBundlePaymentActivity.this;
        sessionManager = new SessionManager(context);
        mAPIService = ApiUtils.getAPIService();


//        PaymentConfiguration.init(getApplicationContext(), "pk_test_51HG10vFt7j55xMYbzQQFVld6qTmDJN8jIpKv0aAE0vP0vycO5XVVpIZ8ZSbH4XLUNW10drf1g8dJKthBkiJilFWs00lPrn2GRO"); // Get your key here: https://stripe.com/docs/keys#obtain-api-keys

        stripe = new Stripe(context, "pk_test_51HG10vFt7j55xMYbzQQFVld6qTmDJN8jIpKv0aAE0vP0vycO5XVVpIZ8ZSbH4XLUNW10drf1g8dJKthBkiJilFWs00lPrn2GRO");
//        stripe = new Stripe(context, "pk_test_Ug9XLblBJkDAaGaD51iSqUJ2");

        getClientTokenFromServer();

        img_back = findViewById(R.id.img_back);
        rv_shipping = findViewById(R.id.rv_shipping);
        edt_street = findViewById(R.id.edt_street);
        edt_city = findViewById(R.id.edt_city);
        edt_country = findViewById(R.id.edt_country);
        edt_zip_code = findViewById(R.id.edt_zip_code);
        txt_pay  = findViewById(R.id.txt_pay);
        cb_paypal = findViewById(R.id.cb_paypal);
        cb_wallet = findViewById(R.id.cb_wallet);
        cb_strip = findViewById(R.id.cb_strip);
        if (Utils.isInternetConnected(context)) {
            shippinglist();

        } else {
            CustomAlertdialog.createDialog(context, getString(R.string.no_internet));
        }
    }

    public void shippinglist() {
        Customprogress.showPopupProgressSpinner(context, true);

        mAPIService.shippinglist(sessionManager.getSavedUserid(), sessionManager.getSavedUserid(),"order").enqueue(new Callback<ShippingResponse>() {
            @Override
            public void onResponse(Call<ShippingResponse> call, Response<ShippingResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);
                profile();
                if (response.isSuccessful()) {

                    boolean status = response.body().getStatus();

                    String msg = response.body().getMessage();
                    if (status == true) {
                        rv_shipping.setHasFixedSize(true);
                        rv_shipping.setLayoutManager(new LinearLayoutManager(context));
                        mAdapter = new ShopBundlepayShippingAdapter(context, response.body().getData(), new ShopBundleShappingData() {
                            @Override
                            public void getShopbundleshappingdata(String shapping_id, String shappingamt) {
                                shappingidmain = shapping_id;
                                shappingamtmain = shappingamt;
                                System.out.println("shipping id >>>>>>>"+shapping_id);
                                System.out.println("shipping amt >>>>>>>"+shappingamt);
                            }
                        });
                        rv_shipping.setAdapter(mAdapter);

                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }

            }

            @Override
            public void onFailure(Call<ShippingResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
            }

        });
    }

    public void profile() {
        Customprogress.showPopupProgressSpinner(context, true);
        mAPIService.getprofile(sessionManager.getSavedUserid(), sessionManager.getSavedUserid()).enqueue(new Callback<ProfileShowResponse>() {
            @Override
            public void onResponse(Call<ProfileShowResponse> call, Response<ProfileShowResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);
                try {
                    sendPostViewWallet();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status == true) {
                        if (response.body().getStatus()) {
                            ProfileShowResponse profileRes = response.body();
                            edt_street.setText(profileRes.getData().getStreet());
                            edt_city.setText(profileRes.getData().getCity());
                            edt_country.setText(profileRes.getData().getCountry()+"");
                            edt_zip_code.setText(profileRes.getData().getZipcode());

                            customerName = response.body().getData().getSellername();

                        }
                    } else {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<ProfileShowResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", "Unable to submit post to API.");
                Toast.makeText(context, "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void Addorderdata() {
        Customprogress.showPopupProgressSpinner(context, true);

        AddOrderParaOrder addOrderParaOrder = new AddOrderParaOrder(sessionManager.getSavedUserid(),seller_id,shappingidmain,discount_id,totaldiscountamt,customerName,totalamt+"",paymentMethod,shappingamtmain,street,country,city,zipcode);
        List<AddOrderParaProduct> product = new ArrayList<>();
        for (int i=0;i<transferShopDataListMain.size();i++)
        {
            AddOrderParaProduct addOrderParaProduct = new AddOrderParaProduct(transferShopDataListMain.get(i).getId(),"1",transferShopDataListMain.get(i).getPrice());
            product.add(addOrderParaProduct);
        }
        AddOrderParameter addOrderParameter = new AddOrderParameter(addOrderParaOrder,product);

        mAPIService.addorderproduct(addOrderParameter).enqueue(new Callback<AddOrderResponse>() {
            @Override
            public void onResponse(Call<AddOrderResponse> call, Response<AddOrderResponse> response) {

                Customprogress.showPopupProgressSpinner(context, false);
//                profile();
                if (response.isSuccessful()) {

                    boolean status = response.body().getStatus();

                    if (status == true)
                    {
                        String paymentmode =response.body().getData().getPaymentMethod();
                       order_id =response.body().getData().getId();
                        System.out.println("order id >>>>>>>>>"+order_id);

                        if (paymentmode.equals("Wallet"))
                        {
                            try {
                                sendPostWalletPayment(paymentmode,order_id);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        else if (paymentmode.equals("Stripe")){

                            order_id =response.body().getData().getId();
                            System.out.println("order id >>>>>>>>>"+order_id);
                            Intent intent = new Intent(context, CardEditActivity.class);
                            startActivityForResult(intent, CREATE_NEW_CARD);
                        }
                        else if (paymentmode.equals("Online"))
                        {
                            onBraintreeSubmit();
//                            Toast.makeText(context, "Paypal Payment", Toast.LENGTH_SHORT).show();
                        }

                    } else
                        {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<AddOrderResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context, false);
                Log.e("TAG", ""+t.getMessage());
            }

        });
    }

    public void sendPostViewWallet() throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.viewwalletdata(sessionManager.getSavedUserid()).enqueue(new Callback<MyWalletResponse>() {
            @Override
            public void onResponse(Call<MyWalletResponse> call, Response<MyWalletResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        walletMain = response.body().getWallet();
                        System.out.println("wallet data >>>>>>>>"+walletMain);
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<MyWalletResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void sendPostWalletPayment(String paymentmode,String orderid) throws JSONException {
        Customprogress.showPopupProgressSpinner(context,true);

        mAPIService.walletpayment(sessionManager.getSavedUserid(),orderid,"aaa",paymentmode).enqueue(new Callback<WalletPaymentResponse>() {
            @Override
            public void onResponse(Call<WalletPaymentResponse> call, Response<WalletPaymentResponse> response) {

                Customprogress.showPopupProgressSpinner(context,false);

                if(response.isSuccessful()) {
                    boolean status = response.body().getStatus();

                    if (status==true)
                    {
                        Toast.makeText(context, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(context,DashboardActivity.class);
                        intent.putExtra("about","0");
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(context, ""+response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onFailure(Call<WalletPaymentResponse> call, Throwable t) {
                Customprogress.showPopupProgressSpinner(context,false);
                Log.e("TAG", ""+t.getMessage());
            }
        });
    }

    public void onActivityResult(int reqCode, int resultCode, Intent data) {

        super.onActivityResult(reqCode, resultCode, data);
        System.out.println("resultCode data >>>>>>>"+resultCode);
        if (resultCode == RESULT_OK) {
//            Debug.printToast("Result Code is OK", getApplicationContext());

            if (reqCode == CREATE_NEW_CARD) {
                System.out.println("Card data >>>>>>>"+data.toString());
                if (data.toString()!=null)
                {
                    String name = data.getStringExtra(CreditCardUtils.EXTRA_CARD_HOLDER_NAME);
                    String cardNumber = data.getStringExtra(CreditCardUtils.EXTRA_CARD_NUMBER);
                    String expiry = data.getStringExtra(CreditCardUtils.EXTRA_CARD_EXPIRY);
                    String cvv = data.getStringExtra(CreditCardUtils.EXTRA_CARD_CVV);

                    if (cardNumber.isEmpty())
                    {
                        CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_enter_card_number));
                    }
                    else if (expiry.isEmpty())
                    {
                        CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_enter_card_expiry));
                    }
                    else if (cvv.isEmpty())
                    {
                        CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_enter_card_cvv));
                    }
                    else if (name.isEmpty())
                    {
                        CustomAlertdialog.createDialog(context,getResources().getString(R.string.Please_enter_name_on_card));
                    }
                    else {
                        System.out.println("Card number >>>>>>>"+cardNumber);
                        System.out.println("Card cvv >>>>>>>"+cvv);
                        System.out.println("Card holder name >>>>>>>"+name);
                        System.out.println("Card expiry >>>>>>>"+expiry);

                        String[] date = expiry.split("/");
                        Log.d("date", date[0]);
                        Log.d("date1", date[1]);
                        onAddCard(cardNumber, Integer.parseInt(date[0]), Integer.parseInt(date[1]), cvv);



                    }
                }
                else {
                    CustomAlertdialog.createDialog(context,getResources().getString(R.string.Something_wrong));
                }
            }
        }
        if (reqCode == BRAINTREE_REQUEST_CODE) {
            Log.d(String.valueOf(resultCode), "resultcode");
            if (RESULT_OK == resultCode) {
                DropInResult result = data.getParcelableExtra(DropInResult.EXTRA_DROP_IN_RESULT);
                String paymentNonce = result.getPaymentMethodNonce().getNonce();
//                makepayment(paymentNonce);
            } else if (resultCode == Activity.RESULT_CANCELED) {
                Log.d("User cancelled payment", "cancel");
            } else {
                Exception error = (Exception) data.getSerializableExtra(DropInActivity.EXTRA_ERROR);
                Log.d(" error exception", "" + error);
            }
        }

    }

    public void onAddCard(String cardNumber, int cardExpMonth, int cardExpYear, String cardCVC) {
        card = Card.create(
                cardNumber,
                cardExpMonth,
                cardExpYear,
                cardCVC
        );
        card.validateNumber();
        card.validateCVC();
        payment();
    }

    private void payment() {

//        progressLoader.show();
        Customprogress.showPopupProgressSpinner(context,true);
        if (!card.validateCard()) {
            Toast.makeText(context, "Invalid Card", Toast.LENGTH_LONG).show();
//            progressLoader.dismiss();
            Customprogress.showPopupProgressSpinner(context,false);
        } else {
            stripe.createToken(card, new ApiResultCallback<Token>() {
                @Override
                public void onSuccess(@NonNull Token result) {
                    // Send the token identifier to the server
                    Customprogress.showPopupProgressSpinner(context,false);
                    token = result;
                    sendServer();
                }
                @Override
                public void onError(@NonNull Exception e) {
                    e.printStackTrace();
                    Customprogress.showPopupProgressSpinner(context,false);
                    Toast.makeText(context, ""+e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    private void sendServer() {
        Customprogress.showPopupProgressSpinner(context,true);

        JsonPlaceHolderApi apiInterface = ApiUtils.getAPIService();
        Call<WalletPaymentResponse> call = apiInterface.walletpayment(sessionManager.getSavedUserid(),order_id,"tok_visa","Stripe");
        call.enqueue(new Callback<WalletPaymentResponse>() {
            @Override
            public void onResponse(Call<WalletPaymentResponse> call, final Response<WalletPaymentResponse> response) {
                Customprogress.showPopupProgressSpinner(context,false);
                if (response.body().getStatus()) {
                    Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
//                    successpopup();
                    Intent intent = new Intent(context,DashboardActivity.class);
                    intent.putExtra("about","0");
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    Toast.makeText(context, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<WalletPaymentResponse> call, Throwable t) {
//                progressLoader.dismiss();
                Customprogress.showPopupProgressSpinner(context,false);
                Toast.makeText(context, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

}