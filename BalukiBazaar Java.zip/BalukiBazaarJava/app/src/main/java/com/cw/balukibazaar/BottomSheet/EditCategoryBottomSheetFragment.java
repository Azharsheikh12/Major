package com.cw.balukibazaar.BottomSheet;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.cw.balukibazaar.ModelClass.GlobalCategoryData;
import com.cw.balukibazaar.R;
import com.cw.balukibazaar.Utils.SessionManager;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.List;


public class EditCategoryBottomSheetFragment extends BottomSheetDialogFragment implements View.OnClickListener {

    SessionManager sessionManager;
    ImageView iv_close,iv_back;
    RecyclerView recycler_category;
    RelativeLayout rl_main;
    List<GlobalCategoryData> categoriesList;
    CategorySubAdapter MyListAdapter;
    Context context;
    String category_id;
    private int prevSelection = -1;
    public EditCategoryBottomSheetFragment(Context context, List<GlobalCategoryData> categoriesList, String category_id) {
        this.context = context;
        this.categoriesList = categoriesList;
        this.category_id = category_id;
    }


    @Override
    public int getTheme() {
        return R.style.BottomSheetDialogTheme;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        return new BottomSheetDialog(requireContext(),getTheme());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.bottom_sheet_categoryedit, container, false);

        findIds(view);
        MyListAdapter = new CategorySubAdapter(context,categoriesList);
        recycler_category.setHasFixedSize(true);
        recycler_category.setLayoutManager(new LinearLayoutManager(context));
        recycler_category.setAdapter(MyListAdapter);
        return view;

    }

    public void findIds(View v) {
        sessionManager = new SessionManager(context);
        iv_close = v.findViewById(R.id.iv_close);
        iv_close.setOnClickListener(this);
        iv_back = v.findViewById(R.id.iv_back);
        iv_back.setOnClickListener(this);
        recycler_category = v.findViewById(R.id.recycler_category);
        rl_main = v.findViewById(R.id.rl_main);

        Display display = getActivity().getWindowManager().getDefaultDisplay();
        int width = (display.getWidth() );
        int height = (display.getHeight() );
        rl_main.getLayoutParams().height = height/2;
        rl_main.getLayoutParams().width =width;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.iv_close:
                sessionManager.setSavedCateId(category_id);
                dismissAllowingStateLoss();
                break;
            case R.id.iv_back:
                sessionManager.setSavedCateId(category_id);
                dismissAllowingStateLoss();
        }
    }

    public  class CategorySubAdapter extends RecyclerView.Adapter<CategorySubAdapter.ViewHolder>{
        List<GlobalCategoryData> eventMainModelClasses;
        private Context context;
        public CategorySubAdapter(Context context, List<GlobalCategoryData> listdata) {
            this.eventMainModelClasses = listdata;
            this.context = context;
        }
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View listItem = layoutInflater.from(parent.getContext()).inflate(R.layout.row_cate_edit_single, parent, false);

          ViewHolder viewHolder = new ViewHolder(listItem);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            final GlobalCategoryData myListData = eventMainModelClasses.get(position);

            holder.txt_title.setText(categoriesList.get(position).getName());

            if (category_id.equals(categoriesList.get(position).getId()))
            {
                holder.cb_candition.setChecked(true);
                System.out.println("category id >>>>>>>"+category_id);
                sessionManager.setSavedCateId(category_id);
            }
            else {
                holder.cb_candition.setChecked(false);

            }

            holder.cb_candition.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

//                    sessionManager.setSavedCateId(categoriesList.get(position).getId());
//                    Log.i("cate id >",""+sessionManager.getSavedCateId());
                    category_id = myListData.getId();
                    dismissAllowingStateLoss();
                    notifyDataSetChanged();
                }
            });
        }
        @Override
        public int getItemCount() {
            return eventMainModelClasses.size();
        }

        public  class ViewHolder extends RecyclerView.ViewHolder {

            TextView txt_title;

            RelativeLayout re_main;
            CheckBox cb_candition;
            public ViewHolder(View itemView) {
                super(itemView);

                txt_title = itemView.findViewById(R.id.txt_title);
                re_main = itemView.findViewById(R.id.re_main);
                cb_candition = itemView.findViewById(R.id.cb_candition);
            }
        }
    }


}